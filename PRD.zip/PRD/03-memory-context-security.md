# Section 3: Memory, Context Engine & Security

> **Product:** Blufio — Rust + Shell Agent Platform  
> **Document:** PRD Section 3 of 5  
> **Version:** 2.0  
> **Date:** 2026-02-28  
> **Status:** Draft  
> **Changes from v1.8:** Plugin architecture & progressive disclosure — progressive skill disclosure in context assembly, EmbeddingAdapter trait with plugin-based embedding models, PII detection via plugin system, AuthAdapter trait with pluggable authentication.  
> **Changes from v1.7:** PII detection internationalization with configurable pattern packs (Pixie #22), Argon2id Pi-specific parameters for resource-constrained devices (Pixie #24), WASM vs Script tier security/DX reconciliation (Pixie #3), vault key loss recovery workflow (Pixie #31), RFC vs ADR decision matrix (Pixie #21), log sampling at high concurrency (Pixie #25).  
> **Changes from v1.6:** Prompt injection warning prominence (Loonie #18), vault env var production warning (Loonie #19), audit witness compliance mode (Loonie #20), external scraping cost tracking (Loonie #22), AGPL boundary diagram (Loonie #2), CLA/IP employer template as real file (Loonie #3).  
> **Changes from v1.5:** Multilingual embedding model option (C7), pricing file override (C3), external attachment encryption (C33), embedding download opt-out (C8), RUSTSEC advisory response SLA (C32), FDE detection implementation (C11).  
> **Changes from v1.4:** Vault key secure path as default (C2), SQLCipher CBC/GCM acknowledgment (C4), LLM provider data retention (H1), DPIA template contents (H2), memory reindex atomic switchover (M1), archive cap vs 'never lost' fix (M2), importance-weighted LRU eviction (M3), relevance classifier false negative safety net (M4), revocation list integrity (M5), vault rotate --force security (M6), vault key versioning/forward secrecy (M7), temporal decay for important memories (M10), audit external witness required (H5), skill signing trust bootstrap (H6), SSD secure deletion (L7), PII redaction logging (L5), tiktoken tokenizer mismatch (L1).  
> **Changes from v1.3:** Embedding model abstraction via EmbeddingProvider trait (Pixie #7), embedding model load failure degraded mode (Pixie #24), archive vacuum + row cap interaction clarification (Pixie #23), hook data minimization (Pixie #15).  
> **Changes from v1.2:** Prompt injection Phase 1-2 limitation warning (Loonie #5d), Ed25519 revocation timing fix (Loonie #5e), vault rotate safety confirmation (Loonie #5b), hook security prominence (Loonie #5a).  
> **Changes from v1.1:** Added archive row cap and vacuum command (Crusher #13), skill registry license policy (Crusher #15), audit log sealing specifics (Crusher #25).  
> **Changes from v1.0:** Addressed Jinx review feedback — corrected search weights, honest embedding dependency story, removed unverifiable claims (contradiction detection, cache baselines, NER), added caveats to cost/token projections, clarified compliance scope, specified classifier tuning parameters, acknowledged env var limitations.

---

## Table of Contents

1. [Memory System](#1-memory-system)
2. [Context Engine](#2-context-engine)
3. [Compaction](#3-compaction)
4. [Credential Vault](#4-credential-vault)
5. [Security Architecture](#5-security-architecture)
6. [WASM Sandboxing](#6-wasm-sandboxing)
7. [Privacy & Compliance](#7-privacy--compliance)
8. [Stability & Memory Safety](#8-stability--memory-safety)

---

## 1. Memory System

### 1.1 Overview

Blufio's memory system is the agent's durable knowledge store — bridging the LLM's ephemeral context window with persistent long-term recall. Unlike OpenClaw's file-only approach (inject the entire `MEMORY.md` every turn), Blufio provides hybrid retrieval with semantic and keyword search, returning only the most relevant memories per query.

**Design principles:**
- Files on disk are the canonical source; the index is derived, never authoritative
- Minimal external runtime dependencies. The default embedding model (~80 MB) is downloaded on first run, cached locally at `$BLUFIO_DATA/models/`. A fallback URL and SHA-256 checksum verification ensure availability and integrity if the primary Hugging Face URL changes
- Hybrid retrieval combining keyword and semantic search
- Bounded growth with LRU eviction — the index never grows unboundedly

### 1.2 Storage Layer — SQLite + sqlite-vec + FTS5

All memory data lives in a single SQLite database using three complementary access patterns:

| Component | Purpose | Access Pattern |
|-----------|---------|---------------|
| Core table (`memories`) | Structured metadata, content, timestamps | Standard SQL queries |
| FTS5 virtual table | BM25 full-text keyword search with Porter stemming | `MATCH` queries, ranked by BM25 |
| sqlite-vec virtual table | HNSW approximate nearest-neighbor vector search | Cosine similarity over embeddings |

**Schema (core table):**

```sql
CREATE TABLE memories (
    id          TEXT PRIMARY KEY DEFAULT (hex(randomblob(16))),
    session_id  TEXT NOT NULL,
    kind        TEXT NOT NULL CHECK (kind IN ('message', 'file', 'snippet', 'summary', 'fact')),
    content     TEXT NOT NULL,
    source_path TEXT,
    importance  REAL NOT NULL DEFAULT 0.5,
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now')),
    accessed_at TEXT,
    access_count INTEGER NOT NULL DEFAULT 0,
    embedding   BLOB,
    token_count INTEGER
);

-- FTS5 for keyword search
CREATE VIRTUAL TABLE memories_fts USING fts5(
    content, source_path, kind,
    content=memories, content_rowid=rowid,
    tokenize='porter unicode61'
);

-- sqlite-vec for vector search (dimension matches configured embedding model)
CREATE VIRTUAL TABLE memories_vec USING vec0(
    id TEXT PRIMARY KEY,
    embedding float[384] distance_metric=cosine
);
```

**Bounded index:** The memory store enforces a configurable maximum entry count (default: 10,000). Eviction uses a weighted score combining recency and importance: `eviction_score = recency_weight * (1.0 / days_since_access) + importance_weight * importance`. Default weights: recency 0.6, importance 0.4. High-importance memories (≥1.5) are protected from eviction until the store exceeds 150% capacity. Operators can pin critical memories via `@pin` annotation, which exempts them from eviction entirely. TTL expiry (default: 90 days without access) provides additional cleanup.

### 1.3 Embedding Pipeline

The embedding pipeline abstracts over models via an `EmbeddingProvider` trait. Default: all-MiniLM-L6-v2 (384-dim, ~5ms/query, good baseline). For multilingual deployments, the recommended model is `paraphrase-multilingual-MiniLM-L12-v2` (384-dim, supports 50+ languages). English-only deployments should use the default `all-MiniLM-L6-v2` for better English performance at lower latency. The config specifies the model: `[embedding] model = 'paraphrase-multilingual-MiniLM-L12-v2'`. The install script asks the operator's primary language and pre-selects the appropriate model. `blufio doctor` warns if a non-English locale is detected with the English-only model. The model is swappable via config: `[embedding] model = 'e5-small-v2'` or `model = 'nomic-embed-text-v1.5'`. Supported local models are listed in the docs with quality/speed tradeoffs. Remote embedding APIs (OpenAI, Cohere, Voyage) are supported via `[embedding] provider = 'openai'`. When switching models, `blufio memory reindex` rebuilds the vector index. The architecture does not hardcode any specific model. During reindex, Blufio maintains dual indexes: the old (serving queries) and the new (being built). Queries use the old index until reindex completes, then an atomic swap replaces the old with the new. No mixed-model vectors, no search downtime. `blufio memory reindex --status` shows progress.

The embedding model is accessed via the `EmbeddingAdapter` trait. The built-in adapter uses ONNX Runtime with `all-MiniLM-L6-v2`. Operators can install alternative embedding plugins: `blufio plugin install embedding-openai` for OpenAI's `text-embedding-3-small`, `blufio plugin install embedding-cohere` for Cohere, or `blufio plugin install embedding-multilingual` for `paraphrase-multilingual-MiniLM-L12-v2`. Switching embeddings requires re-indexing: `blufio memory reindex --embedding <adapter-name>`. The adapter trait abstracts dimensions, batching, and normalization.

The local backend uses [Candle](https://github.com/huggingface/candle), Hugging Face's Rust ML framework, to run embedding models natively. The default model produces 384-dimensional vectors at ~5ms per query on CPU (after initial model load, which takes 1-2 seconds on first query) — fast enough to embed on every memory write and search on every query without perceptible latency in steady state.

```toml
# blufio.toml
[memory.embeddings]
backend = "local"                              # "local" | "api"
model = "all-MiniLM-L6-v2"                    # Swappable: "e5-small-v2", "nomic-embed-text-v1.5", etc.
provider = "local"                             # "local" | "openai" | "cohere" | "voyage"
model_path = "$BLUFIO_DATA/models/"
model_sha256 = "<pinned-checksum>"             # Verified on download
similarity_threshold = 0.72
```

For installations where higher retrieval quality justifies the cost and latency, a remote API provider can be configured as primary with local as fallback.

**Degraded mode:** If the embedding model fails to load (corrupted file, missing download, unsupported architecture), Blufio starts in degraded mode: memory search falls back to keyword-only (BM25) with a prominent operator warning. `blufio doctor` flags this as a critical issue. The system remains functional — semantic search is unavailable but keyword search, context injection, and all other features work normally. The operator can fix the model and run `blufio memory reindex` without restart.

**Embedding download opt-out:** `blufio serve --no-embedding` starts without downloading or loading the embedding model. Memory search falls back to BM25 keyword-only. `BLUFIO_SKIP_MODEL_DOWNLOAD=1` env var has the same effect. For air-gapped deployments, the model is included in the `blufio bundle`. For metered connections, `blufio download-model` allows downloading the model separately on an unmetered connection, then copying it to the target machine.

### 1.4 Hybrid Retrieval Pipeline

Neither keyword search nor vector search alone is sufficient for agent memory. Blufio combines both with temporal decay and diversity re-ranking:

**Pipeline stages:**

1. **BM25 keyword search** — FTS5 returns top-20 candidates ranked by term frequency
2. **Vector similarity search** — sqlite-vec returns top-20 candidates by cosine similarity to query embedding
3. **Score fusion** — Reciprocal Rank Fusion (RRF) merges both result sets
4. **Temporal decay** — Recent memories score higher: `decay = 0.95 ^ (days_since_access)`. Memories with importance ≥ 1.5 use a reduced decay rate: `decay = 0.99 ^ days` (vs 0.95 for normal). Memories with `@pin` annotation have zero decay. This ensures strategic decisions accessed quarterly retain relevance in search results.
5. **Importance boost** — User-marked or high-importance entries get a multiplier
6. **MMR diversity re-ranking** — Maximal Marginal Relevance prevents redundant results

**Final score formula:**

```
score = (w_bm25 × bm25_rank + w_vec × vec_rank + w_recency × recency_rank) × importance_boost
```

Default weights: `w_bm25 = 0.35`, `w_vec = 0.50`, `w_recency = 0.15` (sum = 1.0). Importance range `[0.5, 2.0]`.

**Specification:** The search pipeline returns the **top-K results** (default K=5, configurable 1–20) per query, injecting only relevant memories into context rather than the entire memory store.

### 1.5 File Watcher & Auto Re-indexing

Blufio watches workspace memory files (`memory/*.md`, `MEMORY.md`) using `notify` (inotify on Linux, FSEvents on macOS). When a file changes:

1. Debounce: 500ms window to batch rapid edits
2. Re-read file, compute SHA-256 hash
3. If hash differs from stored version: re-embed, update FTS5 index, update core table
4. If file deleted: mark memory entries as `source_deleted`, eligible for accelerated eviction

### 1.6 Memory Consistency Validator

A periodic background task (configurable, default: daily) detects and reports:

- **Near-duplicates** — entries with embedding cosine similarity > 0.92 → recommend merge
- **Stale entries** — not accessed in 30+ days → recommend archive
- **Potential duplicates** — Flags entries with high embedding similarity (>0.92 cosine) that may represent redundant or conflicting information. Actual contradiction detection requires LLM-based verification and is not automated — embeddings capture topical similarity, not logical agreement.

```bash
blufio memory validate
# Output:
# ✅ 847 entries checked
# ⚠️  3 near-duplicate pairs found (similarity > 0.92)
# ⚠️  12 stale entries (>30 days without access)
# ℹ️  Run `blufio memory clean` to apply recommendations
```

---

## 2. Context Engine

### 2.1 Problem Statement

OpenClaw injects all workspace files (`AGENTS.md`, `SOUL.md`, `USER.md`, `TOOLS.md`, `MEMORY.md`, `HEARTBEAT.md`) plus all tool schemas into every API turn. This costs **14,000–21,000 tokens per turn** before the user's message or conversation history begins. On a 200K context window, that's tolerable. On a 32K window, it's 56% overhead — leaving barely enough room for conversation.

Blufio's context engine reduces this to **2,500–9,800 tokens per turn** depending on query complexity — a 40–84% reduction. **Caveat:** Reduction percentages are relative to a baseline of injecting all context every turn. Systems that already implement selective injection will see smaller gains.

### 2.2 Three-Zone Architecture

Every prompt is assembled from three zones with distinct lifecycle and caching properties:

```
┌─────────────────────────────────────────────────┐
│  ZONE 1: STATIC PREFIX                          │
│  ├── System identity / role prompt               │
│  ├── SOUL.md (personality, rarely changes)       │
│  └── Core behavioral rules                       │
│  Budget: 3,000 tokens max                        │
│  Cache: Always in prompt cache prefix            │
│  TTL: ∞ (changes only on config update)          │
├─────────────────────────────────────────────────┤
│  ZONE 2: CONDITIONAL (session-stable)            │
│  ├── TOOLS.md (if tool-use likely)               │
│  ├── MEMORY.md entries (if recall needed)        │
│  ├── USER.md (if personalization needed)         │
│  └── Tool schemas (only predicted ones)          │
│  Budget: 8,000 tokens max                        │
│  Cache: Appended after static prefix             │
│  TTL: Per-session, re-evaluated each turn        │
├─────────────────────────────────────────────────┤
│  ZONE 3: DYNAMIC (per-turn)                      │
│  ├── Conversation history                        │
│  ├── Active file contents / tool results         │
│  └── Compaction summaries                        │
│  Budget: Remainder (typically 80,000+ tokens)    │
│  Cache: Not cached (changes every turn)          │
│  TTL: Per-turn                                   │
└─────────────────────────────────────────────────┘
```

### Progressive Skill Disclosure in Context Assembly

Skills use progressive disclosure to minimize token overhead. The context engine handles this in the static zone:

**What's injected every turn (~500 tokens for 50 skills):**
```xml
<available_skills>
  <skill>
    <name>web-search</name>
    <description>Search the web and extract content from URLs. Use when user asks to look something up, research a topic, or fetch a webpage.</description>
    <location>~/.blufio/skills/web-search/SKILL.md</location>
  </skill>
  <skill>
    <name>github</name>
    <description>GitHub operations via gh CLI: issues, PRs, CI runs, code review. Use when checking PR status, creating issues, or querying the GitHub API.</description>
    <location>~/.blufio/skills/github/SKILL.md</location>
  </skill>
  <!-- ... -->
</available_skills>
```

**Agent instruction (injected once in system prompt):**
"Before replying: scan <available_skills> descriptions. If exactly one skill clearly applies, read its SKILL.md, then follow it. If multiple could apply, choose the most specific one. If none apply, don't read any. Never read more than one skill upfront."

**What happens at runtime:**
1. Agent sees skill names + descriptions (~10 tokens each)
2. Agent decides "this looks like a GitHub task" → issues a file read for `~/.blufio/skills/github/SKILL.md`
3. SKILL.md content (~2,000-5,000 tokens) is loaded into context for that turn only
4. Subsequent turns in the same session can reference the loaded skill without re-reading

**Token savings:**
| Approach | 50 skills, simple query | 50 skills, skill-matched query |
|----------|------------------------|-------------------------------|
| Inject all skill definitions | ~100,000 tokens | ~100,000 tokens |
| Progressive disclosure | ~500 tokens | ~3,000-5,500 tokens |
| Savings | 99.5% | 94-97% |

This is how Claude Code handles its 50+ skills — Blufio adopts the same pattern because it works.

**Skill file structure (each skill directory):**
```
~/.blufio/skills/<skill-name>/
├── SKILL.md          # Full instructions, loaded on demand
├── skill.toml        # Manifest (capabilities, metadata)
├── handler.py        # Script tier handler (or handler.wasm)
└── README.md         # Optional documentation
```

The `description` in `<available_skills>` comes from the `description` field in `skill.toml`. Skill authors write a one-line description optimized for agent matching — this is the primary discovery surface.

**Key property:** Zones are assembled in order (Static → Conditional → Dynamic). The static zone **never changes** within a deployment, so the prompt cache prefix is always valid. The conditional zone changes infrequently (only when the relevance classifier changes its selection), extending the cache prefix on most turns.

**Target:** 80–90% cache hit rate within active conversations where the provider cache is warm (typically within the provider's TTL window, e.g., 5 minutes for Anthropic). Cache hit rate drops to near zero after idle periods exceeding the provider's TTL.

### 2.3 Relevance Classifier

A lightweight, local pattern-based classifier decides which conditional-zone blocks to include on each turn. No LLM call is required for classification.

**Classification inputs:**
- User message text (keyword and pattern matching)
- Recent tool calls in the conversation
- Historical block utility (which blocks actually led to tool use)

**Default rules (examples):**

| Block | Trigger Patterns | Base Relevance |
|-------|-----------------|----------------|
| `memory` | "remember", "last time", "previously", "we discussed" | 0.20 |
| `tools_notes` | Tool names, "ssh", "camera", "deploy" | 0.30 |
| `user_prefs` | "preference", "format", "style" | 0.15 |

**Relevance threshold:** 0.25 (configurable). Blocks scoring below this threshold are excluded from the turn's context.

**Self-tuning:** The classifier tracks historical usage — blocks that are included but never lead to tool calls or meaningful responses have their scores penalized over time:
- **Decay rate:** 0.95× per 100 turns for blocks included but unused
- **Floor score:** 0.1 — blocks are never fully excluded by the classifier alone
- **Manual overrides:** `[context.always_include]` and `[context.never_include]` in config take precedence over self-tuning
- **Reset:** `blufio context reset-scores` restores all blocks to default relevance

**Safety net for false negatives:** The classifier has a 'safety net' mechanism: if the model's response includes a tool call or explicit reference to a context block that was excluded, the system automatically includes that block on the next turn and adjusts the classifier score upward. This self-correction catches false negatives within one turn. Additionally, operators can force-include blocks via `[context.always_include]` for critical context.

### 2.4 Token Budgeting

Blufio enforces hard token limits per zone using native token counting via `tiktoken-rs` (~10 million tokens/second, ~1.6ms for a 16K-token prompt). Token counting uses tiktoken-rs (OpenAI tokenizers) as the default. For Anthropic models, token counts may differ by 5-15%. A per-provider tokenizer override is configurable: `[providers.anthropic.tokenizer] = 'claude'` (uses Anthropic's published tokenizer). Until provider-specific tokenizers are implemented, a 10% safety margin is applied to all token budgets.

```toml
[context.budget]
total = 100_000          # Max total prompt tokens
static_max = 3_000       # Zone 1 ceiling
conditional_max = 8_000  # Zone 2 ceiling
reserved_for_output = 9_000  # Leave room for model response
# Zone 3 gets the remainder: total - static - conditional - reserved
```

**Priority system:** Each context block has a priority (0 = must-include, 255 = optional). When a zone exceeds its budget, lowest-priority blocks are dropped first. Priority-0 blocks are always included even if they exceed the zone budget.

### 2.5 Lazy Tool Schema Loading

OpenClaw sends all ~15 tool schemas (~8,000–10,000 tokens) on every turn. Most turns use 0–2 tools.

**Blufio's two-phase approach:**

1. **Compact tool index (~200 tokens):** Sent every turn — tool names with one-line descriptions
2. **On-demand schema expansion:** Full schemas injected only for tools the model is predicted to use (based on the relevance classifier) or explicitly requests via a `tool_help` meta-call

**Fallback:** If the model attempts to call a tool without its full schema loaded, the runtime intercepts, injects the schema, and re-prompts. This adds one round-trip but only on the first use of each tool per session.

**Savings:** Tool schema tokens reduced from ~10,000 to ~200 on non-tool turns (98% reduction).

### 2.6 Prompt Caching Strategy

Blufio inserts `cache_control` breakpoints at zone boundaries when sending to Anthropic's API:

- **Breakpoint 1:** End of Zone 1 (Static) — always cached
- **Breakpoint 2:** End of Zone 2 (Conditional) — cached when stable between turns

The `CacheAligner` tracks zone content hashes between turns to predict and measure cache hit rates. When Zone 2 content changes (e.g., different conditional blocks selected), only the Zone 1 prefix hits cache. When Zone 2 is stable (most turns), both zones hit cache.

### 2.7 Expected Impact

| Scenario | OpenClaw (tokens/turn) | Blufio (tokens/turn) | Reduction |
|----------|----------------------|---------------------|-----------|
| Simple query ("what's 2+2?") | 16,000 | 2,500 | **84%** |
| Memory recall ("what did we discuss?") | 16,000 | 5,500 | **66%** |
| Tool use ("read file X") | 16,000 | 4,200 | **74%** |
| Complex multi-tool | 16,000 | 9,800 | **39%** |
| **Weighted average** | **16,000** | **4,800** | **70%** |

**Monthly cost projection** (100 turns/day, Claude Sonnet): OpenClaw with caching: ~$57.60/mo → Blufio with caching: ~$9.07/mo (**$48.53/mo savings**).

> **⚠️ Note:** These projections are illustrative. Actual savings depend on usage patterns, model selection, and cache hit rates. Users with 10–30 turns/day see proportionally lower absolute savings. The OpenClaw baseline assumes all context injected every turn — operators who already optimize context selectively will see a smaller delta.

---

## 3. Compaction

### 3.1 Overview

When conversation history approaches the model's context window limit, compaction summarizes older messages into compact entries, freeing token budget for new turns. Blufio's compaction system addresses three critical failures in OpenClaw: unverified memory flush, no quality scoring, and catastrophic all-or-nothing compaction.

### 3.2 Trigger Mechanics

Compaction triggers when estimated token usage crosses a configurable threshold:

| Threshold | Default | Action |
|-----------|---------|--------|
| Soft limit | 80% of context window | Warning logged, pruning applied |
| Hard limit | 90% of context window | Compaction triggered |

**Pruning** (zero-cost, pre-compaction): Old tool outputs are truncated to summaries before compaction is invoked. This recovers 20–40% of token budget without any LLM call.

### 3.3 Pre-Compaction Memory Flush with Verification

Before compaction destroys old messages, Blufio gives the model a chance to persist important context. Unlike OpenClaw, the flush is **hash-verified**:

1. Model produces memory entries to save
2. Entries are written to storage
3. **Entries are read back and SHA-256 hash is compared to the original**
4. Only if verification passes does compaction proceed

**Failure handling:**
- **Total flush failure:** Compaction is **aborted**. Old messages are retained. No data loss.
- **Partial failure:** Failed entries' source messages are retained in context (not compacted away). Successful entries proceed normally.
- **Retries:** Up to 3 write-read-verify cycles per entry before declaring failure.

This eliminates the data loss scenario where OpenClaw's flush fails silently and compaction destroys un-persisted context.

### 3.4 Incremental Compaction (LSM-Tree Inspired)

Instead of a single catastrophic compaction event, Blufio uses rolling windows inspired by LSM-tree compaction levels:

| Level | Messages | Token Budget | Summary Style |
|-------|----------|-------------|---------------|
| **L0** (raw) | Last 20 turns | 40,000 | Verbatim — full messages |
| **L1** (light) | Turns 21–60 | 10,000 | Key points with context preserved |
| **L2** (heavy) | Turns 61–200 | 3,000 | Entities, decisions, action items only |
| **L3** (archive) | Turns 200+ | 500 (retrieval hint) | Cold storage, retrievable on demand |

As messages age, they "sink" through levels, getting progressively more compressed. Small, frequent compactions replace the large spike in latency and cost that OpenClaw experiences.

**Token recovery targets:**
- L0 → L1: 60–75% token reduction (key points only)
- L1 → L2: 70–85% reduction (structured extraction only)
- L2 → L3: 85–95% reduction (archived, placeholder in context)

### 3.5 Compaction Quality Scoring

Every compaction summary is scored before it replaces the original messages:

**Scoring dimensions:**

| Dimension | Weight | Measurement |
|-----------|--------|-------------|
| Entity retention | 0.35 | Fraction of detected entities (file paths, URLs, emails, versions, dates) preserved. Detection uses regex + capitalization heuristics, not full NER. Critical entities can be pinned via `@pin` annotations to guarantee preservation. |
| Decision retention | 0.25 | Fraction of decision markers ("decided", "chose", "because") preserved |
| Action item retention | 0.25 | Fraction of action markers ("will do", "TODO", "need to") preserved |
| Numerical retention | 0.15 | Fraction of significant numbers preserved |

**Quality gates:**
- Score ≥ 0.6: Compaction proceeds
- Score 0.4–0.6: Retry with explicit instruction to preserve more detail
- Score < 0.4 (after retry): Compaction aborted, old messages retained

**Targets:** Entity retention ≥ 85%, decision retention ≥ 80%.

### 3.6 Compaction Archive (Cold Storage)

When messages are compacted beyond L2, the originals are archived to SQLite with full content preserved. No message is ever permanently lost.

```sql
CREATE TABLE archive_batches (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    message_count INTEGER NOT NULL,
    quality_score REAL,
    summary       TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE archive_messages (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_id  INTEGER NOT NULL REFERENCES archive_batches(id),
    sequence  INTEGER NOT NULL,
    role      TEXT NOT NULL,
    content   TEXT,
    tool_calls TEXT,
    created_at TEXT
);
```

**Retrieval:** Users can recall archived context via `blufio recall --query "deployment strategy"` which performs keyword + semantic search over the archive.

**Retention:** Archives auto-purge after a configurable retention period (default: 90 days).

**Bounded archive growth:** Pre-compaction raw messages are archived as a recovery mechanism, not permanent storage. The 100K row cap and 90-day TTL mean archived messages are eventually purged. The compacted summaries (L1-L3) are the permanent record — these are never capped or purged. Operators who need full raw message retention should configure `[archive.max_rows] = 0` (unlimited) and manage storage externally. The 90-day TTL and 100K row cap are independent limits applied to the `archive_messages` table only. Compacted messages (L1-L3 summaries) are NOT archived — they replace the originals in the active `messages` table. Only raw pre-compaction messages go to the archive. When the row cap is reached, the oldest archived rows are deleted regardless of age. The auto-purge timer runs daily; the row cap is enforced on every archive write. `blufio memory archive vacuum` manually triggers cleanup.

---

## 4. Credential Vault

### 4.1 Problem Statement

OpenClaw stores all API keys in `auth-profiles.json` in **plaintext**. Any process, skill, or compromised tool can read them. The Moltbook breach (discovered by Wiz) exposed 1.5 million API keys from a completely unauthenticated database.

### 4.2 Encrypted Vault Design

Blufio stores all credentials in an AES-256-GCM encrypted vault. The vault is the **only** component that can decrypt credentials — skills, plugins, and even the LLM context never see raw tokens.

**Encryption specification:**

| Parameter | Value |
|-----------|-------|
| Cipher | AES-256-GCM |
| Key derivation | Argon2id |
| KDF memory | 64 MB (`m_cost = 65536`) |
| KDF iterations | 3 (`t_cost = 3`) |
| KDF parallelism | 4 (`p = 4`) |
| Key length | 256 bits (32 bytes) |

On resource-constrained devices (detected via available memory <2GB), Argon2id parameters are reduced: m_cost = 32MB, t_cost = 4, p_cost = 1. This still provides strong KDF protection while avoiding OOM on Pi 3. `blufio doctor` reports the active parameters and whether they were auto-adjusted. Manual override: `[vault.argon2_m_cost]` in config.

| Nonce | 96 bits (12 bytes), random per encryption |
| Authentication | GCM tag (128 bits) — provides authenticated encryption |

**Vault file format:**

```json
{
  "version": 1,
  "algorithm": "aes-256-gcm",
  "kdf": "argon2id",
  "kdf_params": { "memory_kib": 65536, "iterations": 3, "parallelism": 4 },
  "salt": "<hex>",
  "nonce": "<hex>",
  "ciphertext": "<hex>",
  "tag": "<hex>"
}
```

### 4.3 Key Sources

| Platform | Key Source | Notes |
|----------|-----------|-------|
| macOS | Keychain Services | Unlocked by user login |
| Linux | Secret Service API (GNOME Keyring / KDE Wallet) | Falls back to passphrase |
| Headless/Docker | `BLUFIO_VAULT_KEY` env var or passphrase file | For automated deployments (see limitations below) |
| Enterprise | AWS KMS / GCP KMS / HashiCorp Vault | PKCS#11 for HSM |

> **⚠️ Vault key security:** The env var path (`BLUFIO_VAULT_KEY`) is acceptable for development only. For production Docker deployments, the install script scaffolds a tmpfs-backed secret mount by default: `docker run -v /dev/shm/blufio-secrets:/run/secrets:ro`. The Docker Compose template uses Docker secrets natively. For systemd, `LoadCredentialEncrypted=` is the documented default, not an alternative. The env var path requires explicit opt-in via `[vault.key_source] = 'env'` with a `blufio doctor` warning.
>
> The binary prints a loud startup warning when `BLUFIO_VAULT_KEY` is set AND the bind address is not localhost: `WARNING: Vault key is sourced from environment variable. This is insecure for production. Use LoadCredentialEncrypted (systemd) or Docker secrets. See docs.blufio.dev/security/vault`. The warning is also emitted by `blufio doctor` as a critical finding.

### 4.4 Access Pattern — Runtime Injection

Skills and plugins never receive raw credential values. Instead, the Blufio runtime injects credentials at the HTTP transport layer:

1. Skill declares `needs_auth: "anthropic"` in its manifest
2. Runtime retrieves the credential from the vault
3. Runtime injects `Authorization: Bearer <token>` into the outgoing HTTP request
4. Skill receives the response but never sees the token

This means a compromised skill cannot exfiltrate credentials — it physically never has access to them.

### 4.5 Key Rotation

```bash
blufio vault rotate --credential anthropic
# Rotates via provider API if supported, generates new key, re-encrypts

blufio vault rotate --all --reason "suspected compromise"
# Emergency rotation of all credentials
```

`blufio vault rotate --all` requires interactive confirmation: 'This will revoke ALL credentials. Type ROTATE-ALL to confirm.' The --force flag bypasses confirmation for scripted use but logs a prominent warning. `--force` rotation logs an audit event with severity CRITICAL and source IP/process info. In multi-user environments, `--force` requires a separate authorization token (`BLUFIO_ROTATE_TOKEN`) that is distinct from the main vault key, limiting blast radius if shell access is compromised. Single-credential rotation (`blufio vault rotate --key <name>`) does not require extra confirmation.

**Rotation tracking:** Each credential stores `created_at`, `rotated_at`, and `max_age_days`. The CLI warns when credentials approach their maximum age. Rotation events are logged to the audit trail.

Vault key loss: if the systemd credential or macOS Keychain entry is lost and no backup exists, all encrypted data is unrecoverable. This is by design (no backdoor). Mitigation: (a) `blufio vault export-key --encrypted` creates an encrypted backup of the vault key (operator provides a passphrase). (b) `blufio doctor` warns if no key backup exists. (c) Documentation strongly recommends storing the encrypted key backup in a separate location (password manager, hardware token, printed QR code in a safe). No escrow or recovery mechanism exists — this is an explicit security decision.

**Key versioning and forward secrecy:** The vault supports key versioning: each credential is encrypted with the active key version. When keys are rotated via `blufio vault rekey`, new writes use the new key; old data retains the old key version tag. `blufio vault rekey --reencrypt-all` re-encrypts historical data with the new key, after which the old key can be destroyed. This provides forward secrecy for vault snapshots — destroying an old key makes old backups undecryptable.

### 4.6 Migration from OpenClaw

```bash
blufio vault migrate --from ~/.openclaw/auth-profiles.json
# Reads plaintext JSON, encrypts each credential, writes to vault
# Backs up original file, warns user to delete it
```

---

## 5. Security Architecture

### 5.1 Secure-by-Default Philosophy

Blufio ships locked down. Every security feature is **enabled by default**; operators must explicitly opt out. This inverts OpenClaw's "insecure by default" pattern.

**17 secure defaults (vs. OpenClaw):**

| # | Setting | Blufio Default | OpenClaw Default |
|---|---------|---------------|-----------------|
| 1 | Bind address | `127.0.0.1` | `0.0.0.0` |
| 2 | Authentication | Required (token auto-generated) | None |
| 3 | Credential storage | AES-256-GCM vault | Plaintext JSON |
| 4 | Session isolation | Per-peer | Shared (`main`) |
| 5 | Exec security | Allowlist mode | Full (everything allowed) |
| 6 | Exec approval | On-miss (approve unlisted) | Off |
| 7 | Skill sandboxing | WASM (wasmtime) | None |
| 8 | Skill signing | Ed25519 required | No signing |
| 9 | Rate limiting | Enabled (10 msg/min/sender) | Disabled |
| 10 | Daily cost cap | $15.00 hard limit | Unlimited |
| 11 | Monthly cost cap | $200.00 hard limit | Unlimited |
| 12 | Content sanitization | Enabled | Disabled |
| 13 | Injection defense | Block mode | Detect-only |
| 14 | Credential redaction in logs | Enabled | Disabled |
| 15 | TLS (when exposed) | Required | Disabled |
| 16 | Loop detection | Enabled | Disabled |
| 17 | SSRF private IP blocking | Enabled | Disabled |

**Startup guard:** Blufio refuses to start if bound to a non-localhost address without an auth token configured.

Authentication is adapter-based. The built-in adapter uses Ed25519 device keypairs. Operators can install auth plugins for integration with existing infrastructure: `blufio plugin install auth-oidc` (OpenID Connect), `blufio plugin install auth-ldap`, or implement custom auth via the `AuthAdapter` trait. All auth adapters must implement: `authenticate(credentials) -> Result<Identity>`, `authorize(identity, action) -> Result<()>`, `refresh(identity) -> Result<Identity>`.

### 5.2 SSRF Prevention

All outbound HTTP requests from tools (`web_fetch`, skill HTTP calls) pass through a URL validation layer:

1. **Private IP blocking** — Rejects `10.x.x.x`, `172.16-31.x.x`, `192.168.x.x`, `127.x.x.x`, `169.254.x.x`, IPv6 equivalents
2. **DNS rebinding guard** — Resolves hostname, checks resolved IP against block list (prevents `evil.com` → `127.0.0.1`)
3. **Cloud metadata blocking** — Rejects `169.254.169.254` and cloud-provider metadata endpoints
4. **Redirect chain validation** — Maximum 3 hops; each hop re-validated against the block list
5. **URL extraction from exec** — Detects and blocks URLs extracted by the LLM from exec output that target internal resources

### 5.3 Input Sanitization & Prompt Injection Defense

A five-layer defense pipeline protects against prompt injection. **L1–L2 ship in Phase 1. L3–L5 are Phase 3+.**

```
Input ──► [L1: Classifier] ──► [L2: Sanitizer] ──► [L3: Boundary] ──► LLM
                                                                        │
Output ◄── [L5: Action Confirm] ◄── [L4: Output Validator] ◄────── LLM
```

| Layer | Function | Mechanism | Phase |
|-------|----------|-----------|-------|
| **L1: Classifier** | Detect injection attempts | Pattern matching for "ignore previous", system impersonation, zero-width chars. Per-source thresholds. | Phase 1 |
| **L2: Sanitizer** | Strip dangerous content | Remove `display:none` HTML, HTML comments, zero-width characters (U+200B–U+200F, U+2060–U+206F, U+FEFF). Truncate at 50KB. | Phase 1 |
| **L3: Boundary** | Isolate external content | Session-unique HMAC-SHA256 boundary tokens wrapping external data with "DATA ONLY" instructions | Phase 3 |
| **L4: Output Validator** | Block credential leaks | Regex detection of known key formats (`ghp_*`, `sk-*`, `AKIA*`, Telegram bot tokens). Block suspiciously long URLs (>500 chars) as exfiltration attempts. | Phase 3 |
| **L5: Action Confirm** | Human-in-the-loop for risky actions | Require user confirmation for `exec` commands triggered after external content was fetched. 120-second timeout → auto-block. | Phase 3+ |

> ⚠️ **Phase 1-2 Limitation:** Blufio ships with only L1 (role separation) and L2 (output filtering) injection defenses. Operators deploying in public-facing or untrusted-input contexts should implement additional application-level safeguards until L3-L5 ship in Phase 3. This limitation must be documented prominently in the operator guide.
>
> This warning MUST appear in: (a) the operator quickstart guide, (b) the `blufio serve` startup output when public-facing bind is detected, (c) the README security section. Text: '⚠️ Blufio Phase 1-2 has basic prompt injection defenses only (pattern matching + sanitizer). Do not expose to untrusted users until L3-L5 defenses ship in Phase 3.'

### 5.4 Rate Limiting

Token bucket rate limiting at three levels:

| Level | Default Limit | Scope |
|-------|--------------|-------|
| Per-sender | 10 messages/min, 5 exec/min, 10 web_fetch/min | Individual user |
| Per-tool | 30 tool calls/min global | All users combined |
| Global | 20 LLM calls/min | Entire gateway |

**Loop detection:** If the same tool is called 20+ times in a single turn, or cost exceeds $1.00/minute, the session is killed automatically.

**Cost budgets:**
- Daily soft limit: $5.00 (warning)
- Daily hard limit: $15.00 (blocked)
- Monthly hard limit: $200.00 (blocked)

An `external_api` cost category tracks spending on external APIs (Bright Data, scraping services, third-party tools). Skills and hooks report costs via `blufio costs report --category external_api --amount 0.05 --description 'Bright Data scrape'`. This enables operators to see total AI infrastructure spend, not just LLM costs.

**Pricing file override:** LLM provider pricing is overridable without upgrading the binary. `~/.blufio/pricing.toml` contains per-model token costs that override the built-in defaults. Format: `[anthropic.'claude-sonnet-4-20250514'] input_per_1k = 0.003, output_per_1k = 0.015`. `blufio costs validate-pricing` checks the override file for format errors. Built-in pricing is updated with each release but operators on older versions can track pricing changes independently.

### 5.5 TLS Enforcement

When the gateway is exposed beyond localhost (bind ≠ `127.0.0.1`), Blufio strongly recommends TLS and logs a warning every startup if not configured. The gateway supports automatic TLS via:

- User-provided certificate + key
- ACME/Let's Encrypt (for public deployments)
- Tailscale MagicDNS (recommended for remote access)

### 5.6 Kill Switch & Incident Response

```bash
blufio kill-switch
# Immediately: suspend all sessions, cancel in-flight LLM calls, freeze message queue

blufio kill-switch --resume
# Resume normal operation

blufio sessions revoke --all
# Revoke all sessions, clear conversation context

blufio vault rotate --all --reason "suspected compromise"
# Emergency credential rotation
```

**Audit log sealing:** `blufio audit seal` freezes the audit log with a terminal hash, preventing post-incident tampering.

### 5.7 Hook Security

> ⚠️ **Security:** Hook scripts receive session context including user messages and tool parameters on stdin. The install script sets `/var/log/blufio/` permissions to `0750` (owner: blufio, group: blufio) by default. A dedicated 'Hook Security' page in the operator docs covers: safe logging practices, secret handling in hooks, and common footguns. Hooks that log to world-readable locations are flagged by `blufio doctor`.

**Data minimization:** Hooks declare their data requirements in the hook config: `[hooks.pre_send] data = ['response_text', 'session_id']`. The hook runtime strips all undeclared fields from the stdin payload before passing to the script. Hooks that declare `data = ['*']` receive the full context but require explicit opt-in and trigger a `blufio doctor` warning. This minimizes the blast radius of buggy or compromised hooks.

### 5.8 Ed25519 Key Revocation

Skill signing uses Ed25519 keys with the following trust and revocation model:

- **Local revocation list:** `$BLUFIO_DATA/revoked-keys.json` — operators can immediately revoke trust for compromised author keys via `blufio skill revoke-key <fingerprint>`
- **Static revocation file:** A static hosted revocation file (updated daily, no server-side logic) ships alongside the skill registry in Phase 3 — not deferred to Phase 4. Skills are being published from Phase 3 onwards, so revocation infrastructure must be available from day one of the registry. The full centralized revocation feed with real-time push is Phase 4. The Phase 3 static revocation file at `keys.blufio.dev/revoked.json` is Ed25519-signed by the project's release key. Clients verify the signature before applying the revocation list. A compromised CDN serving an unsigned or empty list is detected and rejected — the client falls back to its local revocation list.
- **Centralized revocation feed:** Phase 4 — an HTTPS endpoint serving a signed revocation list with real-time push notifications. Operators can opt out for air-gapped deployments.
- **On-load check:** Every skill load checks the local revocation list. Skills signed by revoked keys are rejected even if previously installed.

### 5.9 RUSTSEC Advisory Response SLA

RUSTSEC advisory response policy (documented in SECURITY.md): Critical severity — patch within 24 hours, release within 48 hours. High — patch within 72 hours, release within 1 week. Medium — addressed in the next scheduled release. Low — evaluated for relevance, addressed as resources allow.

---

## 6. WASM Sandboxing

### 6.1 Overview

Every third-party skill in Blufio runs inside a [wasmtime](https://wasmtime.dev/) WebAssembly sandbox. Skills compile to `.wasm` modules and execute with explicit capability grants — they physically cannot access resources not declared in their manifest.

### 6.2 Isolation Guarantees

| Property | Guarantee |
|----------|-----------|
| Memory isolation | Each skill has its own linear memory; cannot access host memory |
| No filesystem access | Unless explicitly granted via capability manifest |
| No network access | Unless explicitly granted with domain allowlists |
| No credential access | Never — credentials are injected by the runtime at the HTTP layer |
| CPU time limits | Fuel metering prevents infinite loops |
| Memory limits | Configurable per-skill (default: 64 MB) |

### 6.3 Performance Characteristics

WASM sandbox overhead varies by workload:

- **Compute-bound tasks:** ~1.5× native execution time
- **I/O-heavy tasks** (network calls, filesystem operations): 3–5× native due to serialization overhead crossing the host-guest boundary on each host function call

Skills with frequent I/O calls (e.g., many small HTTP requests) will see the higher end of overhead. Batch operations where possible.

### 6.4 Capability Manifest

Every skill declares its required capabilities in `skill-manifest.toml`:

```toml
[skill]
name = "smart-home-controller"
version = "2.1.0"
author = "verified-publisher"

[capabilities.network]
outbound = ["api.home-assistant.io:443", "*.local:8123"]

[capabilities.filesystem]
read = ["$SKILL_DIR/**"]
write = ["$SKILL_DIR/data/**"]

[capabilities.tools]
allowed = ["web_fetch"]
web_fetch_domains = ["api.home-assistant.io"]

[capabilities.resources]
max_cpu_fuel = 1_000_000_000
max_memory_mb = 64
max_exec_calls_per_minute = 0    # No exec access
max_web_fetch_per_minute = 30
```

**Implicit deny:** Any capability not declared is denied. A skill that declares no `network` section has zero network access. A skill that declares no `filesystem` section cannot read or write any files.

### 6.5 Skill Code Signing

All published skills must be signed with the author's Ed25519 key:

1. **Author signs** — `blufio skill sign ./my-skill --key ~/.blufio/signing-key`
2. **Registry verifies** — signature checked at publish time
3. **User verifies** — signature checked at install time
4. **Runtime re-verifies** — signature checked on every load (including revocation list check, see §5.7)

**Trust bootstrap:** The Blufio binary embeds the project's root signing key. The official registry's key is signed by the root key (certificate chain). Third-party authors register their keys with the registry, which counter-signs them. Users trust the registry's counter-signature, not individual author keys directly. This provides a lightweight PKI without requiring a full CA infrastructure.

**Registry license policy:** All skills published to the registry must declare their license in the manifest. The registry warns operators when a skill uses a license with unusual distribution requirements (e.g., copyleft). AGPL-licensed skills are flagged with a prominent warning. Skills without a declared license are rejected.

An `AGPL_BOUNDARY.md` file ships in the repo root with a text diagram: `[MIT core: blufio-*] ←no dependency→ [AGPL: adapters/signal/]`. The CI lint (`scripts/check-agpl-boundary.sh`) greps for `use presage::` or `presage =` outside `adapters/signal/` and errors loudly with a link to AGPL_BOUNDARY.md explaining why.

The employer authorization template ships as `docs/employer-authorization-template.md` — a real file in the repo, not just a mention. Contains: company name, employee name, scope of authorized contributions, signature line, and a note that this is not legal advice.

**Trust levels:**

| Level | Policy | Sandbox |
|-------|--------|---------|
| **Verified** (key in trusted keyring) | Auto-install updates | Native plugin (optional) |
| **Community** (signed, key not trusted) | Install with user approval | WASM sandbox (mandatory) |
| **Unsigned** | Rejected | N/A — installation blocked |

Security/DX tradeoff acknowledged: Script tier (subprocess) is the recommended starting point for most skill authors — fast I/O, familiar languages, no compilation step. WASM tier provides sandboxing for untrusted/third-party skills from the registry. The registry REQUIRES WASM for published skills. Locally-installed skills may use Script tier at the operator's discretion. This means: operator-authored skills run unsandboxed (trusted code), community skills run sandboxed (untrusted code). The PRD does not claim all skills are sandboxed — it claims all *third-party registry* skills are sandboxed.

**Installation prompt:**

```
📦 Installing "Smart Home Controller" v2.1.0
   Author: verified-publisher (✅ Signed)

   Capabilities requested:
   ├─ 🌐 Network: api.home-assistant.io, *.local
   ├─ 📁 Read: own directory only
   ├─ 📝 Write: own data directory only
   └─ ⚡ Resources: 64MB RAM, no exec, no host filesystem

   🔒 This skill CANNOT:
   ├─ Access your credentials or API keys
   ├─ Read files outside its own directory
   ├─ Execute shell commands
   └─ Contact any server except Home Assistant

   [Install] [Review manifest] [Cancel]
```

### 6.6 Runtime Behavioral Monitoring

Even sandboxed skills are monitored at runtime:

- Network request rate anomaly detection (100x above baseline → kill)
- Outbound data pattern matching (API key formats → kill + alert)
- Resource consumption tracking (approaching fuel/memory limit → warn)
- All capability broker decisions logged to audit trail

---

## 7. Privacy & Compliance

### 7.1 Problem Statement

OpenClaw has **zero privacy, data governance, or regulatory compliance features**. All user data — session transcripts, memory files, authentication tokens, media files — is stored in plaintext with no encryption, no retention policies, no deletion mechanisms, and no audit trail. Any deployment processing EU resident data faces GDPR liability.

### 7.2 Data Classification

Every field in Blufio's database schema has a classification level:

| Level | Label | Examples | Retention Default |
|-------|-------|---------|-------------------|
| 1 | **Public** | Agent name, tool list, API version | No limit |
| 2 | **Internal** | Session IDs, timestamps, turn counts | 1 year |
| 3 | **Confidential** | User messages, conversation content, preferences | 90 days |
| 4 | **Restricted** | API keys, auth tokens, health data, financial data | 7 days (tokens), audit-specific |

Classifications are enforced at the data access layer — a skill with classification level 2 cannot query level 3 or 4 columns.

### 7.3 PII Redaction (Full-Stack)

Blufio implements PII redaction at two levels:

**Persist-level redaction:** Before storing data, a regex-based PII scanner detects and optionally redacts:

| Pattern | Category | Redaction |
|---------|----------|-----------|
| `\S+@\S+\.\S+` | Email | `[EMAIL]` |
| `\b\d{3}[-.]?\d{3}[-.]?\d{4}\b` | Phone (US) | `[PHONE]` |
| `\b\d{3}-\d{2}-\d{4}\b` | SSN | `[SSN]` |

PII detection ships with configurable pattern packs. Default: US patterns (SSN, phone, email). Phase 1 also includes EU patterns: Swedish personnummer, German Sozialversicherungsnummer, UK National Insurance, IBAN, EU phone formats. Pattern packs are TOML files in `~/.blufio/pii-patterns/` — operators add custom patterns. `blufio doctor` checks locale and warns if no matching pattern pack is configured.

PII detection patterns are loaded via the plugin system. The core ships with US + EU patterns. Additional pattern packs are plugins: `blufio plugin install pii-nordic`, `blufio plugin install pii-apac`. Custom patterns: create a `pii-custom/` plugin with a `patterns.toml` file. This replaces the previous `~/.blufio/pii-patterns/` directory approach with proper plugin lifecycle (versioning, updates, registry).

| `\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b` | Credit card | `[CARD]` |
| `ghp_[a-zA-Z0-9]{36}` | GitHub PAT | `[CREDENTIAL]` |
| `sk-[a-zA-Z0-9]{48}` | OpenAI key | `[CREDENTIAL]` |
| `AKIA[0-9A-Z]{16}` | AWS access key | `[CREDENTIAL]` |

**Display-level redaction:** Credential patterns are scrubbed from all log output, error messages, and dashboard views.

**PII redaction audit logging:** Every PII redaction event is logged to the audit trail: `{event: 'pii_redacted', field: 'user_message', pattern: 'email', session_id: '...', timestamp: '...'}`. No actual PII values are logged — only the pattern type and location. This provides GDPR Article 5(2) accountability evidence.

**LLM-level minimization:** Before sending context to LLM providers, configurable PII stripping replaces identifiers with placeholders. The substitution mapping is held in memory only during the active request and never persisted to disk. The LLM sees `[EMAIL]` instead of `user@example.com`. Placeholders are rehydrated in the response before displaying to the user. If the LLM independently generates placeholder-like tokens (e.g., `[EMAIL]` in a new context not from substitution), they pass through unchanged — no accidental data injection occurs.

### 7.4 Data Retention Policies

```toml
[privacy.retention]
sessions_days = 90          # Conversation transcripts
media_days = 30             # Images, audio, documents
auth_tokens_days = 7        # OAuth access tokens
tool_output_days = 60       # Cached tool results
audit_logs_days = 730       # 2 years (compliance)
memory_files_days = -1      # Never auto-delete (user manages)
```

A daily background task enforces retention policies automatically. For Restricted (level 4) data, Blufio overwrites with zeros before deletion and runs `VACUUM` to reclaim SQLite free pages. On SSDs, zero-overwrite does not guarantee physical erasure due to wear leveling. The recommended approach is full-disk encryption (LUKS/FileVault/BitLocker) so deletion of the encryption key renders all data unrecoverable. `blufio doctor` checks for full-disk encryption and warns if the data directory is on an unencrypted filesystem. FDE detection: Linux checks `/proc/mounts` for `dm-crypt`/LUKS indicators on the data directory's mount point. macOS checks `fdesetup status`. The check is best-effort — false negatives are possible on unusual configurations. When FDE status cannot be determined, `blufio doctor` reports 'unknown' with a recommendation to verify manually.

### 7.5 Right to Erasure (GDPR Article 17)

```bash
blufio privacy delete --user user@example.com --confirm
```

This command:
1. Deletes all messages from the user
2. Deletes sessions where the user was the only participant
3. Redacts the user's messages in multi-participant sessions (→ `[erased]`)
4. Deletes the user's uploaded media files
5. Scrubs memory files for references to the user
6. Re-runs compaction on affected sessions
7. Logs the erasure in the audit trail
8. Generates a third-party notification list (LLM providers, MCP servers)

> **⚠️ Compliance scope:** This command assists GDPR Article 17 compliance but does not guarantee complete erasure. Indirect references, compacted summaries, and data already sent to third-party LLM providers may retain traces. Organizational processes and human review remain necessary for full compliance. `blufio privacy verify-deletion` checks for direct references but cannot detect indirect or contextual mentions.

> **⚠️ LLM provider data retention:** Data sent to LLM providers cannot be deleted by Blufio. Operators must: (a) select zero-retention API tiers where available (Anthropic offers this), (b) execute provider-side deletion requests per their DPA, (c) document this limitation in their DPIA. `blufio privacy forget` logs which providers received the user's data and provides direct links to each provider's deletion request form. The 'GDPR & LLM Providers' operator guide covers this in detail.

### 7.6 Encryption at Rest

All SQLite databases are encrypted using SQLCipher Community Edition (BSD license), which links against OpenSSL/BoringSSL for cryptographic primitives:

| Parameter | Value |
|-----------|-------|
| Cipher | AES-256-CBC (SQLCipher) |
| KDF iterations | 256,000 (PBKDF2-HMAC-SHA512) |
| Page size | 4,096 bytes |
| HMAC algorithm | HMAC-SHA512 |

Key rotation: `blufio privacy rotate-key` re-encrypts the database in-place using `PRAGMA rekey` without downtime.

**External attachment encryption:** External attachment files are encrypted with AES-256-GCM using a key derived from the vault master key and the session ID (`attachment_key = HKDF(vault_key, session_id, 'attachment')`). File names are hashed to prevent metadata leakage. `blufio doctor` warns if unencrypted external attachments are detected.

SQLCipher Community Edition uses AES-256-CBC + HMAC-SHA512 (encrypt-then-MAC), not AEAD. This is a weaker construction than the vault's AES-256-GCM. The HMAC provides authentication but CBC mode has known malleability concerns if HMAC verification is timing-dependent. Mitigation: SQLCipher performs constant-time HMAC comparison. For operators requiring AEAD at the database level, SQLCipher Commercial (which supports GCM) or application-level encryption over standard SQLite are alternatives. The PRD recommends SQLCipher Community as the default trade-off between security and licensing (BSD vs commercial).

### 7.7 EU AI Act Transparency

Blufio generates transparency disclosures configurable per channel:

```
ℹ️ This is an AI assistant powered by Claude Opus 4. Human oversight is available.
```

The disclosure can be sent automatically at the start of each new conversation or displayed in the agent's profile.

> **⚠️ Scope:** This is a starting point for EU AI Act compliance. Full compliance for high-risk AI systems (if applicable) requires additional organizational measures including risk assessments, human oversight procedures, and conformity assessments that are beyond the scope of software tooling alone.

### 7.8 Audit Trail

Every data access and modification is logged to a tamper-evident, hash-chained audit log:

```sql
CREATE TABLE audit_log (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp      TEXT NOT NULL DEFAULT (datetime('now')),
    event_type     TEXT NOT NULL,
    actor          TEXT NOT NULL,
    resource       TEXT,
    classification INTEGER,
    payload        TEXT,          -- JSON
    previous_hash  BLOB NOT NULL, -- SHA-256 of previous record
    record_hash    BLOB NOT NULL  -- SHA-256 of this record
);
```

**Verification:** `blufio audit verify` walks the hash chain and reports any gaps or inconsistencies. Enterprise deployments can forward audit logs to external SIEM systems.

**Audit log sealing:** `blufio audit seal` creates a cryptographic checkpoint: a SHA-256 hash chain entry covering all audit records since the last seal. The sealed hash is written to the audit log itself and to an external witness. For compliance-grade audit trails, at least one external witness is required (not optional). The default config ships with `[audit.witness] = 'syslog'`. Operators can add: append-only remote endpoint, blockchain anchor, or cloud audit log (AWS CloudTrail, GCP Audit Log). `blufio doctor` warns if no external witness is configured. Records can be appended after sealing — each new seal covers all records since the previous one. `blufio audit verify` validates the hash chain integrity from the first seal to present.

When `[compliance.mode] = 'gdpr'` (or any compliance mode) is enabled, `blufio doctor` treats missing external audit witness as an ERROR, not a warning. `blufio serve` refuses to start in compliance mode without at least one external witness configured. This is a hard gate, not advisory.

### 7.9 Compliance CLI

```bash
blufio privacy compliance-check --framework gdpr
blufio privacy compliance-check --framework hipaa
blufio privacy compliance-check --framework ccpa
blufio privacy dpia --output dpia-report.pdf   # GDPR Data Protection Impact Assessment
# The generated DPIA report contains: (a) systematic description of data processing (what data
# Blufio collects, stores, sends to providers), (b) data flow diagram (user → Blufio → LLM
# provider → response → storage), (c) necessity assessment template (operator fills in legal
# basis), (d) risk assessment with pre-populated technical risks and Blufio's mitigations,
# (e) residual risk register. The report is a structured starting point — not a complete DPIA.
# Operators must customize it with organizational context. A disclaimer states this clearly.
blufio privacy export --user <id> --format json  # GDPR Article 15 / CCPA Right to Know
```

> **⚠️ HIPAA:** `blufio privacy compliance-check --framework hipaa` generates an evidence report for technical controls implemented by Blufio (encryption at rest, audit logging, access controls, PII redaction). This does **NOT** constitute HIPAA compliance, which requires Business Associate Agreements (BAAs), workforce training, physical safeguards, and independent auditing. Consult a compliance professional.

---

## 8. Stability & Memory Safety

### 8.1 Problem Statement

OpenClaw's TypeScript gateway suffers from systemic unbounded state growth leading to OOM crashes, session file bloat, and silent data loss. Across 10+ documented GitHub issues, the pattern is consistent: `new Map()` without eviction, append-only JSONL files without rotation, full-file-in-memory transfers without streaming, and zero runtime health monitoring.

### 8.2 How Rust Eliminates These Bug Classes

Blufio is built in Rust, which provides structural guarantees that make OpenClaw's entire class of memory bugs **impossible by design**:

| Rust Property | What It Prevents |
|---------------|-----------------|
| **Ownership model** | Every allocation has exactly one owner. When the owner goes out of scope, memory is freed deterministically. No forgotten cleanup. |
| **No garbage collector** | No GC pauses (50–200ms in Node.js under pressure). No heap fragmentation. No unpredictable memory spikes. |
| **`Send` + `Sync` bounds** | Data race conditions caught at compile time, not at runtime. |
| **`Option<T>`** | Null dereference eliminated — explicit handling required. |
| **Bounded collections** | `BoundedMap<K, V>` with LRU eviction replaces all unbounded `HashMap` usage. |

### 8.3 Bounded Collections as First-Class Abstractions

Blufio provides `BoundedMap<K, V>` as the **only** cache abstraction in its public API. There is no unbounded `HashMap` available to subsystems. This is enforcement by construction, not by code review.

**`BoundedMap` specification:**
- Maximum entry count: configurable per instance
- LRU eviction: when at capacity, least-recently-accessed entry is evicted on insert
- Optional TTL: entries auto-expire after a configurable duration
- Utilization metric: `cache.utilization()` returns current fill ratio

**Application to OpenClaw bugs:**

| OpenClaw Bug | Root Cause | Blufio Prevention |
|---|---|---|
| #5136 Diagnostic Map unbounded | `Map.set()` without eviction | `BoundedMap` max 1,000 entries + 1h TTL |
| #4948 Six caches unbounded | Independent unbounded `Map`s | All caches use `BoundedMap` |
| #13859 Batch status stuck | No invalidation, infinite poll | `BoundedMap` TTL + `PollingGuard` with max iterations |
| #6650 Session JSONL bloat | Append-only, verbatim tool output | SQLite with row limits; tool output sanitized at insert |
| #11769 File transfer OOM | Full file loaded into memory | `tokio::io::copy` streams with 64KB buffer |
| #27323 Unbounded SSE connections | No connection limits | `tokio::sync::Semaphore` (max 20 SSE connections) |
| #9888 Silent persistence failure | No health check | Health monitor detects write failures, auto-restarts |

### 8.4 SQLite Instead of Growing JSONL Files

OpenClaw stores sessions as append-only JSONL files parsed in full on every load. Blufio uses SQLite:

- **Bounded by design** — configurable row limits per session (default: 500 messages)
- **Indexed queries** — fetching last 50 messages is O(log n), not O(n)
- **Atomic writes** — WAL mode ensures crash-safe writes
- **Tool output sanitization at insert time** — max 10KB per tool output, schema keys stripped, long arrays truncated

### 8.5 Streaming File Transfer

OpenClaw reads entire files into memory and Base64-encodes them (1.33× memory overhead). Blufio uses `tokio::io::copy` with a fixed 64KB buffer regardless of file size. A 10GB file transfer uses 64KB of RAM.

### 8.6 Runtime Health Monitoring

A built-in health monitor runs every 60 seconds, tracking:

- **RSS** — Warning at 256MB, critical at 512MB
- **Cache utilization** — Warning at 80%, critical at 95%
- **Database size** — Critical at 1GB
- **Session sizes** — Alert on sessions exceeding configured row limits

```
[health] RSS=24MB allocated=18MB | caches: auth=120/1000 sessions=45/500 | db=4.2MB
```

**Emergency action:** On critical health status, caches are evicted to 50% capacity automatically.

### 8.7 Memory Profile Comparison

| Metric | OpenClaw (Node.js) | Blufio (Rust) |
|--------|-------------------|---------------|
| Idle memory (no active sessions) | 150–200 MB | 50–80 MB |
| Peak RSS after 24h (heavy use) | 300–500 MB, growing | 80–120 MB, flat |
| Memory behavior over time | Monotonic growth → OOM | Flat curve within configured bounds |
| GC pauses | 50–200ms under pressure | None (deterministic deallocation) |
| File transfer memory | `file_size × 1.33` | 64 KB (constant) |
| Cache growth | Unbounded | Bounded by configured maximums |
| Health monitoring | None | Built-in, every 60s |

> **Note:** Idle memory of 50–80 MB includes the loaded embedding model (~80 MB mapped but not fully resident). Active sessions add ~0.5–2 MB each. The embedding model is memory-mapped, so actual RSS depends on access patterns.

**The fundamental difference:** In Node.js/TypeScript, unbounded growth is the default — every `Map.set()` grows the map. In Rust, unbounded growth requires explicit opt-in. Blufio inverts the burden of proof: developers must justify growth, not remember to prevent it.

### 8.8 Allocator

Blufio uses `jemalloc` as the global allocator via `tikv-jemallocator` for:
- Excellent fragmentation resistance for long-running processes
- Precise allocation statistics via `jemalloc_ctl` (allocated, resident, retained)
- No memory returned-to-OS lag that plagues glibc malloc

```rust
#[global_allocator]
static GLOBAL: tikv_jemallocator::Jemalloc = tikv_jemallocator::Jemalloc;
```

---

## Appendix A: Configuration Reference

```toml
# blufio.toml — Memory, Context & Security configuration

[memory]
backend = "sqlite"
max_entries = 10_000
eviction = "lru"
ttl_days = 90

[memory.embeddings]
backend = "local"
model = "all-MiniLM-L6-v2"
provider = "local"
model_path = "$BLUFIO_DATA/models/"
model_sha256 = "<pinned-checksum>"
similarity_threshold = 0.72

[memory.search]
bm25_weight = 0.35
vector_weight = 0.50
recency_weight = 0.15
temporal_decay = 0.95
top_k = 5

[memory.compaction]
l0_max_messages = 20
l1_max_messages = 40
l2_max_messages = 140
min_quality_score = 0.6
flush_max_retries = 3

[memory.archive]
enabled = true
max_age_days = 90
max_rows_per_session = 100_000

[context]
mode = "optimized"
relevance_threshold = 0.25
lazy_tools = true
cache_alignment = true

[context.budget]
total = 100_000
static_max = 3_000
conditional_max = 8_000
reserved_for_output = 9_000

[context.classifier]
decay_rate = 0.95              # Per 100 unused turns
score_floor = 0.1
always_include = []            # Block names to always include
never_include = []             # Block names to always exclude

[security]
bind = "127.0.0.1:18789"
auth = "token"
sandbox_default = "wasm"
injection_defense = "block"
redact_credentials_in_logs = true
loop_detection = true
ssrf_blocking = true

[security.rate_limits]
enabled = true
per_sender_messages_per_minute = 10
per_sender_exec_per_minute = 5
global_tool_calls_per_minute = 60
global_llm_calls_per_minute = 20

[security.budget]
daily_soft_usd = 5.0
daily_hard_usd = 15.0
monthly_hard_usd = 200.0

[security.vault]
algorithm = "aes-256-gcm"
kdf = "argon2id"
key_source = "keychain"       # "keychain" | "env" | "kms"

[security.revocation]
local_list = "$BLUFIO_DATA/revoked-keys.json"
static_file = "https://keys.blufio.dev/revoked.json"    # Phase 3 (daily, static)
# remote_feed = "https://keys.blufio.dev/revoked-live.json"  # Phase 4 (real-time push)

[privacy]
encryption_at_rest = true
pii_redaction = true

[privacy.retention]
sessions_days = 90
media_days = 30
auth_tokens_days = 7
tool_output_days = 60
audit_logs_days = 730
```

---

## Appendix B: RFC vs ADR Decision Matrix

> Cross-reference: Full RFC process in Section 5 (§RFC Process), ADR format in Section 5 (§Architecture Decision Records).

When to use which: RFC (14-day comment, public discussion) — new features visible to operators, breaking API changes, new skill tiers, new channel adapters. ADR (7-day comment, maintainer record) — internal architecture decisions, dependency choices, performance trade-offs, code organization. Rule of thumb: if it affects the user-facing API or operator workflow, it's an RFC. If it's an implementation detail, it's an ADR.

---

## Appendix C: Log Sampling at High Concurrency

> Cross-reference: Structured logging format in Section 4 (§7.2 Structured Logging).

At high concurrency (50+ sessions), log sampling reduces I/O: non-critical events (heartbeat checks, cache hits, routine tool calls) are sampled at 10% by default. Critical events (errors, security events, cost records) are always logged at 100%. Configurable: `[logging.sample_rate] = 0.1` (default for non-critical), `[logging.always_log] = ['error', 'security', 'cost']`. `blufio serve --log-level debug` disables sampling.

---

*End of Section 3. Next: Section 4 — Channel Architecture & Communication Layer.*
