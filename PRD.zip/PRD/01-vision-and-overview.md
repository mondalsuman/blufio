# 01 — Vision & Overview

**Product:** Blufio  
**Document:** PRD Section 1 of 5  
**Version:** 2.0  
**Date:** 2026-02-28  
**Status:** Draft v2.0  

---

## 1. Executive Summary

Blufio is a ground-up Rust + Shell replacement for OpenClaw — a multi-channel AI agent platform that ships as a single static binary (core: ~25MB minimal; ~50MB with all official plugins), uses SQLite for all persistence, enforces security by default, and aims to achieve 68-84% token reduction depending on OpenClaw configuration through smart context injection, cache-aligned prompts, and model routing. It keeps everything that makes OpenClaw valuable (multi-channel messaging, persistent memory, skill ecosystem, multi-agent routing, always-on operation) while addressing structural problems (unbounded memory growth, token waste, credential exposure, npm supply chain risk, cost blindness, silent error swallowing).

> **Important caveat:** This PRD describes a product that does not yet exist. All performance numbers are projections based on architectural analysis, not benchmarks. Claims will be validated during implementation and adjusted as real data becomes available.

### What Blufio Enables That Others Can't

**(a)** True single-binary deployment — no runtime, no package manager, no dependency tree. Copy one file, run it. **(b)** Compiler-verified safety — entire classes of bugs (memory leaks, data races, use-after-free) eliminated at compile time, not discovered in production. **(c)** Predictable resource usage — bounded memory, no GC pauses, no surprise OOM kills. Run on a $5 VPS indefinitely. **(d)** WASM-sandboxed skills — untrusted code runs in a capability-limited sandbox, not with full agent privileges. **(e)** Offline-first — works without internet after initial setup, embeds its own search.

**(f)** Plugin-composed architecture — the core is a thin agent loop. Channels, providers, storage backends, embedding models, and observability exporters are all plugins. Install only what you need. A minimal Blufio (Telegram + Anthropic) is ~25MB. A full install with all adapters is ~50MB.

This is not "OpenClaw but better" — it's a different architectural philosophy built from scratch.

---

## 2. Vision & Mission

**Vision:** An always-on personal AI agent that is secure enough to trust, efficient enough to afford, and simple enough to deploy by copying one file.

**Mission:** Replace the OpenClaw TypeScript stack with a Rust core gateway and shell automation layer that eliminates entire categories of bugs at compile time, bounds all resource consumption by design, and makes the secure path the default path.

**North star metric:** A Blufio instance running unattended on a $4/month VPS for 6+ months without restart, OOM, or security incident — while costing ~$130-145/month in LLM API spend for a medium-usage operator (50 messages/day) at realistic 55% cache hit rates. This target assumes effective model routing; see cost sensitivity analysis in Section 6.1.

---

## 3. Problem Statement

OpenClaw is one of the most popular open-source personal AI agent platforms, with 15+ messaging channels and thousands of community skills. It works. But production operation reveals structural problems that are difficult to fix without significant architectural changes:

### 3.1 Memory Leaks & Unbounded Growth

OpenClaw's Node.js process grows monotonically. In-memory caches (tool outputs, parsed transcripts, provider responses) have no eviction policy. After 24 hours of heavy use, memory reaches 300–800MB. Multiple GitHub issues document OOM crashes. The garbage collector reclaims unreachable memory but cannot enforce policy on reachable memory held in Maps and arrays.

> *Note: Some of these issues could be incrementally addressed in OpenClaw via bounded caches and eviction policies, but the single-threaded GC architecture makes it harder to guarantee bounded memory under all conditions.*

### 3.2 Token Waste & Cost Blindness

Every API turn injects ~35,000 tokens of overhead: workspace files (AGENTS.md, SOUL.md, USER.md, TOOLS.md, MEMORY.md, TEAM-ROLES.md, TEAM-COMMS.md), all 15 tool schemas, conversation history — regardless of query complexity. The user's actual message is a tiny fraction of the payload. "What's the weather?" costs the same as "Analyze this codebase."

Heartbeats (every 10 minutes) use the same full-context injection. With Opus at full context, this costs ~$0.178/heartbeat — $769/month on heartbeats alone, 95% of which return `HEARTBEAT_OK`. **Caveat:** This $769 figure assumes Opus for every heartbeat at full context window. Operators using cheaper models (Haiku, Sonnet) for heartbeats see dramatically lower costs. Structural overhead remains regardless of model, but absolute costs vary significantly with model choice.

No unified cost ledger exists. Ten-plus features consume tokens (messages, heartbeats, compaction, embeddings, subagents, cron, tool calls) but none are tracked. Users discover unexpected bills after the fact. Loop bugs can burn unlimited money with no kill switch.

**Monthly cost for a medium user (50 msgs/day) on Opus everywhere:** $560 messages + $790 heartbeats = **$1,350/month.** With model routing (e.g., Haiku for heartbeats), this drops substantially — the structural overhead of injecting everything every turn is the real problem, not the model choice alone.

### 3.3 Security Defaults

OpenClaw binds to `0.0.0.0` by default. Authentication is optional. API keys are stored as plaintext JSON. Skills from the community run with full process access. CVEs have enabled token theft and RCE.

Three overlapping security layers (sandbox, tool policy, elevated mode) interact non-obviously — a debugging tool (`sandbox explain`) exists because the security model is too complex to reason about.

> *Note: Security defaults could be tightened in OpenClaw incrementally. The deeper issue is that the security model evolved organically rather than being designed holistically.*

### 3.4 Persistence Fragility

Sessions are stored as JSONL files with PID-based file locks (vulnerable to PID reuse race conditions). The message queue is in-memory — crashes lose queued messages. No ACID transactions. Concurrent writes can corrupt session files.

### 3.5 Silent Error Swallowing

Dozens of empty `catch {}` blocks in critical paths (session locking, cleanup, file I/O). When lock cleanup fails, stale locks accumulate. When file handles leak, the process hits fd limits. No logs, no metrics, no alerts.

### 3.6 Technical Debt & npm Supply Chain

Hundreds of transitive npm dependencies. Each is an attack surface. Channel connectors import from core internals — any core refactor can break any connector. Unknown config keys are silently ignored.

### 3.7 GC Pauses & Single-Threaded Bottleneck

Node.js single-threaded event loop means CPU-intensive operations (embedding computation, context assembly, large JSON serialization) block all other work. GC pauses cause unpredictable latency spikes.

---

## 4. Product Overview

Blufio is a multi-channel AI agent platform with two layers:

**Rust Core Gateway (`blufio`):** A single statically-linked binary (core: ~25MB minimal; ~50MB with all official plugins) containing:
- HTTP/WebSocket gateway server (axum + tokio)
- Agent loop with LLM provider abstraction (Anthropic, OpenAI, Ollama)
- SQLite-backed persistence for sessions, queue, cron, cost tracking, memory (ACID, WAL mode)
- AES-256-GCM encrypted credential vault
- WASM skill sandbox (wasmtime) with capability manifests
- Official skill registry with verified signatures, automated security scanning, compatibility testing, and one-command install. Direct GitHub installation is always supported but lacks these guarantees. The registry wins by being trustworthy and convenient, not by locking users in.
- Three-zone context engine with cache alignment and relevance classification
- Unified cost ledger with budget caps and kill switches
- Multi-channel adapters (Telegram at launch; Discord, WhatsApp, Signal in later phases)
- Multi-agent routing with Ed25519 signed inter-session messages
- Prometheus metrics export

**Shell Automation Layer:** Operator-facing scripts for lifecycle management:
- systemd service units and timers
- Health checks, log rotation, backup scripts
- Lifecycle hooks (pre-send, post-receive)
- Cron job management via `crontab`-style configuration
- One-line deployment: `scp blufio user@server:~/blufio && ssh user@server './blufio serve'`

**Deployment model:** Copy one binary + one TOML config file. No Node.js, no Python, no Docker required, no package manager. Runs on a 512MB/$4-per-month VPS.

> **macOS builds use dynamic system linking and are suitable for development only.** Production deployments target Linux (static musl binary). This is stated upfront in the README and download page: "macOS: development. Linux: production."

---

### 4.5 Architectural Philosophy: Everything Is a Plugin

Blufio's core is deliberately thin. The binary ships with a minimal agent loop (context assembly, session management, SQLite persistence) and a plugin host. Everything else is an adapter:

**Plugin categories:**
| Category | Trait | Examples | Ships with core? |
|----------|-------|----------|------------------|
| Channels | `ChannelAdapter` | Telegram, Discord, WhatsApp, Signal, IRC, Slack, Matrix | Telegram only; others via `blufio plugin install` |
| LLM Providers | `ProviderAdapter` | Anthropic, OpenAI, Ollama, Google, Groq | Anthropic only; others via plugin |
| Storage | `StorageAdapter` | SQLite (built-in), PostgreSQL, TiKV | SQLite built-in; others via plugin |
| Embedding | `EmbeddingAdapter` | Local ONNX (built-in), OpenAI, Cohere, Voyage | Local built-in; others via plugin |
| Observability | `ObservabilityAdapter` | Prometheus (built-in), Grafana, Datadog, OpenTelemetry | Prometheus built-in; others via plugin |
| Auth | `AuthAdapter` | Device keypair (built-in), OIDC, LDAP, SAML | Keypair built-in; others via plugin |
| Skill Runtime | `SkillRuntimeAdapter` | WASM, Script (subprocess), OpenClaw shim | WASM + Script built-in |

**Plugin lifecycle:**
- `blufio plugin list` — show installed plugins
- `blufio plugin search <query>` — search the registry
- `blufio plugin install <name>` — download, verify signature, install
- `blufio plugin remove <name>` — uninstall cleanly
- `blufio plugin update [--all]` — update plugins

**Plugin loading:** Plugins are shared libraries (`.so`/`.dylib`) loaded via `libloading` at startup. Each plugin implements one or more adapter traits. The plugin manifest (`plugin.toml`) declares: name, version, adapter type, capabilities, and minimum Blufio version.

**Why plugins, not compile-time features?** Feature flags (`--features discord`) require recompilation. Plugins allow operators to customize their install without a Rust toolchain. The trade-off is slightly more runtime complexity and ~2-5% overhead on plugin calls vs static dispatch. For channel adapters (I/O-bound, not CPU-bound), this is negligible.

**Default install:** `blufio` ships with: Telegram adapter, Anthropic provider, SQLite storage, local ONNX embedding, Prometheus metrics, device keypair auth. This covers the primary use case out of the box. Everything else is one `plugin install` away.

---

## 5. Key Design Principles

### 5.1 Rust for Core, Shell for Glue

Rust provides memory safety without GC, fearless concurrency via tokio, compile-time type safety (newtypes for IDs, exhaustive pattern matching, `Result<T,E>` everywhere), and single-binary deployment. Shell scripts provide operator-friendly automation, Unix composability, and customization without recompilation.

> *Trade-off acknowledged: Rust development is 2–3× slower than TypeScript for equivalent features. We accept this cost for the runtime safety and performance guarantees.*

### 5.2 Secure by Default

- Binds to `127.0.0.1` (localhost only) by default
- Authentication required (device keypair, not optional tokens)
- Credentials encrypted at rest (AES-256-GCM vault)
- Skills sandboxed in WASM with explicit capability manifests
- SSRF prevention (private IP blocking) enabled by default
- Full-stack secret redaction before persistence (not just display)
- Single security model: one `ExecPolicy` enum with three variants, not three overlapping layers
- TLS required for all remote connections

### 5.3 Bounded Everything

- All caches have hard capacity limits (LRU eviction)
- All channels are bounded (backpressure via tokio mpsc)
- All locks have timeouts (no indefinite blocking)
- All network requests have timeouts
- Memory usage is 50–80MB idle (including embedding model weights), scaling to 100–200MB under load with bounded growth
- Budget system with daily/monthly hard caps and per-message limits

### 5.4 ACID Storage

SQLite WAL mode for all persistence. Sessions, queue, cron jobs, cost events, memory embeddings, credential vault — one database file. ACID transactions. Crash-safe queue (messages survive restarts). Backup is `cp agent.db agent.db.bak`. No external processes, no network dependencies.

### 5.5 Every Token is a Cost Decision

Three-zone context engine (static/conditional/dynamic) with cache-aligned prompt assembly. Relevance classifier filters conditional blocks per-turn. Lazy tool schema loading (200 tokens vs 10,000). Smart heartbeats on Haiku with skip-when-unchanged. Model routing (Haiku for simple, Sonnet for standard, Opus for complex). Unified cost ledger tracking all spending features.

### 5.6 Compiler-Enforced Architecture

`Result<T,E>` with `#[must_use]` — no silent error swallowing. Newtype IDs prevent session/agent/channel ID confusion at compile time. `pub(crate)` visibility enforces module boundaries. `deny_unknown_fields` on all config structs catches typos at startup. Exhaustive pattern matching means adding an enum variant forces handling everywhere. `Send + Sync` enforcement ensures thread safety.

### 5.7 No Legacy Baggage

One config format (TOML), versioned, strict from day one. One protocol (WebSocket with role-scoped connections). One security model. No auto-migrations, no silent defaults, no backward compatibility constraints.

### 5.8 License Compatibility

All dependencies must pass license audit before inclusion. `cargo-deny.toml` enforces MIT/Apache-2.0/BSD compatibility.

Decision: dual-license MIT + Apache-2.0 from the first commit. Apache-2.0's patent protection matters for enterprise contributors. Retroactively adding Apache-2.0 after public contributions is legally messy. Both licenses are permissive and compatible. Every source file includes the dual-license SPDX header: `// SPDX-License-Identifier: MIT OR Apache-2.0`.

| Dependency | License | Notes |
|------------|---------|-------|
| SQLCipher | BSD | Links against OpenSSL — requires attribution in distribution. Consider BoringSSL or application-level encryption via `rusqlite` + AES-GCM as alternative to reduce license complexity. |
| wasmtime | Apache 2.0 | Compatible; requires attribution in binary distribution. |
| tikv-jemallocator | Apache 2.0 + BSD-2 | Compatible; listed for tracking. |
| presage | AGPL | **Isolated in separate binary**, excluded from `workspace.members` and crates.io publication. `cargo build --all-features` MUST NOT link AGPL code — enforced via feature-flag gate. |

**CI enforcement:** `cargo deny --check licenses` runs in every PR to prevent future license contamination. No dependency may be added without passing the license audit.

### 5.9 Reproducible Builds

Release integrity is maintained through multiple layers:

- **cargo-auditable** for embedding dependency info into compiled binaries
- **SLSA provenance** via GitHub Actions for verifiable build attestations
- **SBOM generation** via `cargo-cyclonedx` for supply chain transparency
- **Sigstore/cosign** for release signing (complements Minisign for users who prefer Sigstore's transparency log model)

### 5.10 Progressive Disclosure

Complexity is revealed incrementally, not dumped upfront. This applies at every level:

**For operators:** `blufio serve` works with zero config (defaults to Telegram + Anthropic + SQLite). Adding channels, providers, or plugins happens when needed, not during initial setup. `blufio setup` asks only: Telegram bot token, Anthropic API key. Everything else has sensible defaults.

**For the agent (skill discovery):** Skills use progressive disclosure identical to Claude Code's pattern. At session start, the agent sees only skill names and one-line descriptions (minimal token cost). When a task matches a skill's description, the agent loads that skill's full SKILL.md (detailed instructions, examples, workflows). This means:
- 50 installed skills cost ~500 tokens in the system prompt (names + descriptions only)
- The agent loads 0-2 full skill files per session (~2,000-5,000 tokens each) based on relevance
- vs the alternative: injecting all 50 skill definitions = ~100,000+ tokens every turn

The skill discovery prompt is injected as:
```xml
<available_skills>
  <skill>
    <name>web-search</name>
    <description>Search the web and extract content from URLs.</description>
    <location>~/.blufio/skills/web-search/SKILL.md</location>
  </skill>
  <!-- ... more skills ... -->
</available_skills>
```

The agent's instruction: "Before replying, scan skill descriptions. If a skill matches, read its SKILL.md, then follow it. Never read more than one skill upfront."

**For skill authors:** `blufio skill init` creates a working skill in 3 commands. Advanced features (WASM compilation, registry publishing, capability manifests) are documented but not required for local skills.

**For contributors:** README shows build + test in 2 commands. Architecture docs, ADRs, and governance are discoverable but not prerequisites for a first PR.

---

## 6. Competitive Positioning

### 6.1 vs OpenClaw

> **Framing note:** These tables document architectural differences for engineering evaluation. They are not marketing claims. Both projects serve valid use cases. Metrics marked with '†' are projections pending real-world validation.

| Dimension | OpenClaw | Blufio (projected) |
|-----------|----------|---------------------|
| Binary/install size | ~150–200MB node_modules | Core binary: ~25MB (minimal). With all official plugins: ~50MB. Operators choose their footprint. † |
| Memory (24h heavy use) | 300–800MB (growing) | 50–80MB idle, 100–200MB under load (bounded) † |
| Dependencies | Hundreds of npm packages | <80 direct crates † |
| Startup time | 2–5 seconds | 2–5 seconds (SQLCipher KDF + model loading + channel TLS) † *(Cold start is comparable — Blufio's advantage is in steady-state resource usage, not startup time)* |
| Session storage | JSONL files (corruptible) | SQLite ACID |
| Queue | In-memory (lost on crash) | SQLite-backed (crash-safe) |
| Credentials | Plaintext JSON | AES-256-GCM encrypted |
| Skill isolation | None (full process access) | WASM sandbox |
| Default security | Open (0.0.0.0, no auth) | Locked down (localhost, keypair auth) |
| Token overhead/turn | ~16,000-35,000 (inject everything; 16K with model routing, 35K unoptimized) | ~2,600-4,800 (smart injection, projected) † |
| Token reduction vs OpenClaw | — | 68-84% depending on OpenClaw configuration † |
| Heartbeat cost/month | $769 (Opus, full context)† | ~$6 (Haiku, minimal, skip-unchanged) † |
| Prompt cache hit rate | N/A | 50-65% typical (55% base case for cost projections) † |
| Monthly cost (medium user) | $180-400/mo (depending on model routing) | ~$130-145/mo at 55% cache (realistic); ~$91/mo at 85% cache † |
| Min infrastructure | $12/mo (2GB RAM) | $4/mo (512MB RAM) † |
| Error handling | Silent `catch {}` blocks | `Result<T,E>` everywhere |
| Config validation | Silent drops unknown keys | Strict errors at startup |

†Heartbeat costs are highly model-dependent. OpenClaw operators using Haiku for heartbeats spend far less than $769. The structural difference is context injection size, not just model choice.

\***Cost projections: ~$91/mo at 85% cache → ~$130-145/mo at 55% cache (realistic estimate). The 55% base case reflects typical personal assistant usage (messages every 10-30 minutes with idle gaps). The 85% rate requires sustained conversation with <5min gaps (Anthropic's cache TTL). Still significantly below OpenClaw's ~$180-400/mo range. Actual costs will depend on usage patterns, model choices, and cache effectiveness — to be validated with real deployments.**

> *This comparison documents factual architectural differences. Both projects serve the AI agent community and may evolve differently. Entries marked '—' indicate a feature not present at time of writing, not a permanent limitation.*

**Blufio is not a port of OpenClaw.** It preserves the capabilities (multi-channel, memory, skills, multi-agent) while replacing the architecture entirely.

> *Honest assessment: Several of OpenClaw's weaknesses (unbounded caches, error handling, cost tracking) could be incrementally improved without a rewrite. Blufio's bet is that the accumulation of architectural issues — GC-managed memory, single-threaded runtime, JSONL persistence, optional security — is better addressed holistically than incrementally. This bet may be wrong.*

### 6.2 vs Other Agent Frameworks

| Dimension | Blufio | AutoGPT | CrewAI | LangGraph | Botpress | n8n | Dify |
|-----------|--------|---------|--------|-----------|----------|-----|------|
| Always-on daemon | ✅ | ❌ | ❌ | ❌ | ✅ Cloud | ✅ Cloud | ✅ Cloud |
| Multi-channel messaging | ✅ (1 at launch) | ❌ | ❌ | ❌ | ✅ (5+) | ⚠️ | ❌ |
| Single binary deploy | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Memory (idle) | 50–80MB | 200–500MB | 100–300MB | 100–300MB | 200–400MB | 200–400MB | 300–600MB |
| Skill sandboxing | ✅ WASM | ❌ | ❌ | ❌ | Partial | ❌ | Partial |
| Device pairing | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Visual builder | ❌ | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ |
| Ecosystem maturity | **New (zero)** | Medium | Medium | High | High | High | High |

### 6.3 Where Blufio Wins (Projected)

- **Edge/IoT:** Designed to run on a Raspberry Pi (~50–80MB RAM, single binary)
- **Security-sensitive environments:** WASM-sandboxed skills and secure-by-default posture
- **Cost efficiency:** Projected 68-84% token reduction depending on OpenClaw configuration, lowest infrastructure requirements
- **Long-running stability:** Bounded memory, designed to run for months without restart
- **Deployment simplicity:** Copy one file

### 6.4 Where Blufio Loses

- **Ecosystem:** Zero skills at launch vs OpenClaw's thousands (requires 1–2 years to build)
- **Channel coverage:** 1 channel at launch (Telegram) vs OpenClaw's 15+
- **Visual builder:** CLI/config only — not targeting non-technical users
- **RAG/Knowledge base:** Basic vs Dify's native RAG pipelines
- **Multi-agent orchestration:** Sub-agents only, not agent debate/negotiation patterns
- **Maturity & community:** New and unproven vs established, battle-tested incumbent
- **Development velocity:** Rust's slower iteration speed means features arrive slower

**The bet:** Operational excellence is a durable advantage. Features can be added; architecture cannot be easily retrofitted. But this bet requires sustained development effort and may take longer to pay off than projected.

---

## 7. Target Users

### 7.1 Primary: Developers & Operators Running Always-On AI Agents

- Self-host personal AI assistants on VPS/homelab
- Need multi-channel messaging (Telegram initially, expanding to Discord, WhatsApp)
- Comfortable with CLI, config files, and systemd
- Care about security, cost, and reliability
- Currently frustrated by OpenClaw's memory leaks, cost, or security posture

### 7.2 Secondary: Teams & Organizations

- Run multi-agent teams (research, operations, customer support)
- Need audit trails, encrypted credentials, budget controls
- Regulated industries that cannot accept plaintext credential storage or unsandboxed code execution
- DevOps teams managing agent fleets across edge devices

### 7.3 Tertiary: Edge & IoT Deployments

- Home automation controllers with AI capability
- Raspberry Pi / NAS-based personal assistants
- Air-gapped environments requiring offline-capable deployment
- Resource-constrained devices where 512MB total RAM is the ceiling

### 7.4 Not Target Users

- Non-technical users wanting a visual builder (use Botpress or Dify)
- Enterprise teams needing complex multi-agent orchestration (use LangGraph)
- Teams that need 15+ messaging channels today (use OpenClaw, migrate later)
- Anyone needing a production-ready solution within 6 months (OpenClaw works today)

---

## 8. Success Metrics

> **Note:** All targets below are projections to be validated during development. Metrics will be adjusted based on real benchmarks as implementation progresses.

### 8.1 Performance & Efficiency

| Metric | Target | Rationale |
|--------|--------|-----------|
| Steady-state memory (idle) | 50–80MB (including embedding model) | Proves bounded memory design works |
| Steady-state memory (under load) | 100–200MB (bounded) | Scales with sessions but doesn't grow unbounded |
| Startup time | 2–5 seconds (cold start) | Comparable to OpenClaw — Blufio's advantage is steady-state resource usage, not startup time |
| Binary size | Core: ~25MB (minimal). With all official plugins: ~50MB. | Single-file deployment; operators choose their footprint |

### 8.2 Token & Cost Efficiency

| Metric | Target | Rationale |
|--------|--------|-----------|
| Context tokens/turn (simple query) | ≤3,000 | vs OpenClaw's ~35,000 |
| Context tokens/turn (weighted avg) | ≤5,000 | vs OpenClaw's ~35,000 |
| Prompt cache hit rate | 50-65% typical (55% base case) | Effective cache hit rate: 50-65% for typical personal assistant usage (messages every 10-30 minutes with idle gaps). The 85% rate requires sustained conversation with <5min gaps (Anthropic's cache TTL). Cost projections use 55% as the base case. Operators with high-frequency usage patterns may see higher rates. |
| Heartbeat cost/month | ≤$10 | vs worst-case OpenClaw Opus heartbeats |
| Monthly cost (medium user, 50 msg/day) | ~$130-145/mo at 55% cache (realistic); ≤$100 at 85% cache* | Projected; requires validation |

\**~$91/mo at 85% cache → ~$130-145/mo at 55% cache (realistic estimate). Cost projections use 55% as the base case. Still significantly below OpenClaw's ~$180-400/mo range. Sensitivity to cache hit rates, model routing effectiveness, and usage patterns will be documented and tracked.*

### 8.3 Security

| Metric | Target | Rationale |
|--------|--------|-----------|
| Default exposure | Zero open ports | Localhost-only binding |
| Credential encryption | 100% at rest | AES-256-GCM vault for all secrets |
| Skill isolation | 100% sandboxed (WASM skills) | WASM for all third-party code |
| CVE posture | Minimize CVE exposure through Rust memory safety, dependency auditing, and proactive security practices | Rust prevents memory safety bugs; logic bugs and crypto misuse remain possible |

### 8.4 Reliability

| Metric | Target | Rationale |
|--------|--------|-----------|
| Uptime without restart | ≥6 months | Bounded memory, no GC pressure |
| Queue message loss on crash | 0 | SQLite-backed crash-safe queue |
| Config typo detection rate | 100% | `deny_unknown_fields` on all structs |

### 8.5 Deployment & Adoption

| Metric | Target | Rationale |
|--------|--------|-----------|
| Time to first running agent | <5 minutes | Copy binary + write config + run |
| Minimum VPS cost | $4/month (512MB) | Lower memory than competitors |
| Dependencies at install time | 0 | Single static binary |
| Direct crate dependencies | <80 | Tractable audit surface |
| Concurrent sessions per instance | 10–50 | Limited primarily by provider API rate limits, not local compute |

---

## 9. Risks & Assumptions

This section acknowledges key risks and assumptions underlying this PRD.

### 9.1 Projection-Based Claims

All performance, cost, and memory numbers are projections based on architectural analysis and estimates. None have been benchmarked against a working implementation. Numbers will be validated during development and adjusted. Some projections may prove significantly wrong.

### 9.2 Rust Development Speed

Rust development is 2–3× slower than TypeScript for equivalent feature scope. Borrow checker complexity, longer compile times, a smaller library ecosystem, and async Rust's learning curve all slow iteration. This is a known trade-off for runtime safety and performance.

### 9.3 Timeline

**Default timeline: 36-48 months (volunteer pace).** This is the realistic expectation for an unfunded MIT open-source project. Maintainers contribute part-time; scope is focused on the core (gateway + Telegram + Anthropic + SQLite + CLI). All phase durations in this document show both timelines.

**Funded alternative: 18-24 months** if sustained funding ($300-500K/year) materializes, enabling 2-3 full-time experienced Rust developers. This timeline activates only when funding is secured — it is not the default assumption.

Phase 1 (basic Telegram bot with SQLite) is the realistic minimum — everything beyond Phase 1 should be considered tentative until Phase 1 is validated. WASM sandboxing, embedding pipeline, and channel adapters are each multi-month efforts. The scope may be reduced based on available resources — the Phase 1 core (gateway + Telegram + CLI) is the minimum viable product regardless of funding level.

**Phase 1 scope (volunteer pace):**
- **Phase 1a (months 1-5 volunteer / months 1-3 funded):** Cargo workspace, build pipeline, config system, SQLite, Telegram adapter, Anthropic provider, context engine, basic CLI (serve/status/config/shell). Minimum viable agent.
- **Phase 1b (months 6-9 volunteer / months 4-5 funded):** systemd integration, SQLCipher, install script, backup/restore, health endpoint, `blufio doctor`. Production hardening.

### 9.4 OpenClaw Is a Moving Target

OpenClaw is actively developed. By the time Blufio reaches beta, OpenClaw will have months of improvements. Several of Blufio's advantages (bounded caches, better error handling, cost tracking) could be incrementally fixed in OpenClaw. Blufio's bet is on holistic architectural improvement, but this bet may not pay off if OpenClaw addresses its worst issues first.

If OpenClaw ships bounded caches, SQLite storage, and better security in the next 12 months, Blufio's differentiated story is: (a) Rust's compile-time guarantees vs runtime patches, (b) WASM sandboxing (not achievable in Node.js without major rearchitecture), (c) single static binary vs npm ecosystem, (d) predictable memory without GC tuning. These are architectural advantages that cannot be incrementally added to a Node.js codebase. The lead messaging should emphasize these structural differentiators, not fixable issues like token waste.

### 9.5 Cache Hit Rate Sensitivity

The cost projections use 55% cache hit rate as the base case (realistic for typical personal assistant usage with 10-30 minute message gaps). Anthropic's cache TTL is currently ~5 minutes. Any non-determinism in prompt assembly (timestamps, varying tool schemas, random ordering) breaks caching. Achieving and maintaining high cache hit rates requires extreme discipline and is inherently fragile.

### 9.6 WASM Sandbox Complexity

Building a capability-based WASM sandbox with the right granularity of permissions is a hard problem that many teams have struggled with. This may take significantly longer than estimated and may need to be simplified for v1.0.

### 9.7 Channel Adapter Effort

Each channel adapter (Telegram, Discord, WhatsApp, Signal) is a substantial mini-project. WhatsApp Business API requires Meta business verification. Signal's unofficial client libraries may break. Channel adapters alone could consume months of development time.

### 9.8 Recruitment Risk

The talent pool for experienced Rust + async + systems programmers is narrow. Recruitment is a real risk — the 18-24 month timeline assumes these developers are already available. Hiring delays extend the timeline proportionally.

### 9.9 Timeline Prioritization Framework

No prioritization framework exists for scope cuts when reality diverges from plan. If Phase 2 runs 50% over schedule, the project lead decides which Phase 3 features are cut or deferred. Decision criteria: (a) does it block the core agent loop? (b) do existing users need it? (c) can it ship as a plugin later? Features failing all three criteria are cut first.

### 9.10 GDPR & International Data Transfers

Every LLM API call to a US-based provider (Anthropic, OpenAI) constitutes a GDPR Chapter V international data transfer. Operators in the EU must ensure Standard Contractual Clauses (SCCs) or an adequacy decision covers their provider relationship. Blufio's documentation includes a 'GDPR & LLM Providers' guide listing: which providers offer EU endpoints, zero-retention API tiers (e.g., Anthropic's), and DPA template links. This is an operator responsibility — Blufio facilitates but cannot enforce compliance.

### 9.11 Funding & Sustainability

Blufio is fully MIT-licensed with no freemium gates. Funding relies on support and sponsorship, not software restrictions. Sustaining 2-3 full-time developers requires approximately $300-500K/year.

**Funding sources ranked by viability:**

1. **Corporate sponsorship tiers:** Bronze $500/mo (logo, priority issues), Silver $2K/mo (+ quarterly roadmap input), Gold $5K/mo (+ dedicated support channel).
2. **Blufio Cloud** — managed hosting (post-v1.0, recurring revenue).
3. **Premium skill marketplace** — revenue share on paid skills.
4. **Certification/training programs.**
5. **GitHub Sponsors + Open Collective** for community funding.

Sponsorship tiers activate post-alpha (after Phase 1 ships working software). Pre-launch, the only funding mechanism is GitHub Sponsors for individual maintainers. Selling "quarterly roadmap input" before code exists lacks credibility.

Until the project has real funding: responsible disclosure only, public credit, and project swag as thanks. No cash bounties are promised until a reserve fund exists. The $50K gate and payout ranges are removed from the PRD until funding materializes — promising payouts without money is reputationally damaging.

The software itself remains fully open and free. Revenue sustains development velocity, not feature access.

Historically, MIT-licensed infrastructure tools rarely sustain full-time development through sponsorship alone. Blufio's sustainability plan has three tiers: (a) **Volunteer pace** (unfunded) — community-driven, slower timeline (~36-48 months to v1.0), maintainers contribute part-time. (b) **Seed funded** ($100-200K/year) — 1-2 part-time devs, 24-30 month timeline. (c) **Fully funded** ($300-500K/year) — 2-3 full-time devs, 18-24 month timeline. The project launches at volunteer pace and transitions as funding materializes. If sustained funding does not materialize within 12 months, the scope is reduced to a focused core (gateway + Telegram + Anthropic + SQLite) maintained indefinitely at volunteer pace. Decision authority: the project lead (BDFL) decides scope cuts, communicated via a public blog post and GitHub Discussion with 30-day notice. Trigger: no sustained funding after 12 months AND Phase 1 incomplete. Reduced scope: gateway + Telegram + Anthropic + SQLite + CLI — maintained indefinitely at volunteer pace. Features beyond the core are community-contributed or dormant.

### 9.12 Open Source Infrastructure

The following community infrastructure ships with **Phase 1**:

- `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, issue/PR templates
- DCO (Developer Certificate of Origin) enforcement via commit sign-off. Contributors who cannot sign-off (e.g., employer-owned code) must obtain written permission from their employer or submit via an employer-level CLA. The CONTRIBUTING.md includes a template letter for employer authorization.
- GOVERNANCE.md defines: maintainer responsibilities (review PRs within 72h, triage issues weekly), merge policy (1 maintainer approval + CI green), conflict resolution (maintainer vote, BDFL tiebreak by project lead), new maintainer election (nominated after 3+ months of sustained contribution, approved by existing maintainers). Published in repo root from day 1.
- `cargo-deny.toml` for license and advisory enforcement
- `cargo-audit` in CI for vulnerability scanning
- Dependabot or Renovate for automated dependency updates
- SECURITY.md ships in the repo root from day 1. Contents: security@blufio.dev email for private disclosure, GitHub Security Advisories enabled, 72-hour acknowledgment SLA for reported vulnerabilities, 90-day coordinated disclosure window. No vulnerability should require the bug bounty to exist — responsible disclosure is infrastructure, not a reward program.

### 9.13 Contributor Onboarding

Contributor onboarding: (a) 'Good first issue' labels on 10+ starter issues at launch, curated for newcomers. (b) Architecture Decision Records (ADRs) in `docs/adr/` documenting all major design choices with context and alternatives considered. (c) Monthly community calls (recorded, posted to YouTube) for roadmap discussion and contributor Q&A. (d) A mentorship pairing program matching new contributors with experienced maintainers for their first 3 PRs. (e) Dedicated #contributors channel on Discord/Matrix.

### 9.14 Public Beta Milestone

Phase 2 concludes with a public beta announcement. Early adopters get a dedicated feedback channel (Discord/Matrix), direct access to maintainers, and their issues prioritized. The beta milestone is the primary mechanism for attracting initial contributors.

### 9.15 Telemetry

Opt-in anonymous usage telemetry (disabled by default) collects: install count, Blufio version, OS/arch, active channel count, session count range (buckets: 1-5, 5-20, 20+), and crash reports. No message content, credentials, or PII is ever collected. Telemetry data is published quarterly in a transparency report. This data is essential for prioritizing features and demonstrating traction to sponsors. Operators opt in via `[telemetry] enabled = true`.

Telemetry details: (a) Privacy policy published at `blufio.dev/privacy`. (b) `blufio telemetry status` shows exactly what would be sent. (c) `BLUFIO_TELEMETRY_DRY_RUN=1` logs telemetry data locally without sending. (d) Telemetry endpoint is configurable (`[telemetry.endpoint]`) — forks must change this. (e) Default endpoint includes the project name in the URL so operators know who receives data. Documentation warns fork users to verify the endpoint.

### 9.16 Release Policy

Release policy: (a) Minor releases (0.x) every 6-8 weeks during development. (b) Patch releases for security fixes within 72 hours of disclosure. (c) Post-v1.0: supported version window of current + previous minor (e.g., 1.3 and 1.2 receive security backports). (d) Breaking changes only in minor versions with 6-month deprecation notice. (e) No LTS designation until the project reaches v2.0 and has sustained funding.

### 9.17 Competitive Framing

Blufio is positioned as a next-generation alternative, not a hostile fork. The project respects OpenClaw's contributions and welcomes collaboration where interests align. Competitive framing serves technical differentiation, not community antagonism.

---

## 10. Scope Limitations

Blufio v1.0 explicitly does **not** include:

- **Visual builder / GUI** — CLI and config files only
- **More than 2–4 channels** — Telegram at launch, expand cautiously
- **SOC 2 / HIPAA compliance tooling** — May be explored post-v1.0; compliance requires organizational controls, not just CLI commands
- **DAG workflow engine** — Deferred to post-v1.0
- **Client SDKs** (Python, TypeScript, Go) — Post-v1.0
- **Multi-node sharding** — Single-instance only for v1.0
- **MCP server/client** — Post-v1.0
- **Cross-channel message bridging** — Post-v1.0
- **Native plugin system** (`libloading`) — WASM-only for v1.0 to maintain sandbox guarantees
- **Shadow mode / gradual migration tooling** — Design TBD
- **OpenClaw skill migration:** OpenClaw's skill ecosystem is TypeScript/JavaScript. Blufio provides no binary compatibility. Migration path: (a) A `blufio-openclaw-shim` subprocess adapter wraps existing OpenClaw JS skills via Node.js subprocess + JSON-RPC — skills run unmodified but without WASM sandboxing. (b) A migration guide documents the porting process from JS to Blufio's Script tier (Python/TS subprocess) or WASM. (c) The shim ships in Phase 4 alongside the migration tool. This is the biggest practical adoption blocker — operators with custom skills face real porting effort.
- **OpenAI-compatible API** (full spec) — Basic subset only in v1.0; full compatibility is ongoing work
- **Bug bounty program** — Requires funding model; not feasible for an unfunded open-source project at launch
- **Windows native builds** — Windows is not a primary target at launch. WSL2 is the recommended path for Windows users. Native `x86_64-pc-windows-msvc` builds are a future consideration based on community demand.
- **International PII detection** — PII detection at launch uses regex patterns optimized for US formats (SSN, US phone numbers, US addresses). International formats — Swedish personnummer (YYYYMMDD-XXXX), EU IBAN numbers, international phone formats (+46...) — require community-contributed pattern packs via `[privacy.pii_patterns]` config extension. A 'Nordic PII' and 'EU PII' pattern pack ship in Phase 2. This is a significant gap for non-US operators at launch.
- **i18n/Accessibility** — CLI output is English-only at launch. Locale-aware formatting, RTL support for channel adapters, and multilingual skill descriptions are acknowledged gaps deferred to post-v1.0. Community contributions for localization are welcome.

---

## Version History

> Version numbers (1.0, 1.1, etc.) are PRD revision numbers, not product release versions. The Blufio product will use its own semver versioning starting from 0.1.0.

| Version | Date | Changes |
|---------|------|---------|
| 1.4 | 2026-02-28 | Added funding realism tiers, timeline honesty, contributor onboarding, i18n scope limitation, telemetry section, competitive framing note, PRD version numbering note |
| 1.5 | 2026-02-28 | Added comparison table framing note with † markers, timeline prioritization framework (9.9), GDPR international transfer guidance (9.10), US-centric PII detection scope limitation |
| 1.6 | 2026-02-28 | Added SECURITY.md disclosure policy, OpenClaw skill migration path, dual licensing consideration, release cadence policy, telemetry privacy details, fixed cold start time notation |
| 1.7 | 2026-02-28 | Dual-license MIT+Apache-2.0 from first commit, volunteer pace callout, sponsorship timing post-alpha, sustainability cliff specifics, bug bounty realism, positive vision section, OpenClaw contingency differentiators, cost claim assumptions inline, macOS dev-only guidance |
| 1.8 | 2026-02-28 | Volunteer pace (36-48mo) as PRIMARY timeline, Phase 1 split into 1a/1b, honest token comparison (68-84%), realistic cache hit rate (55% base case), cold start reframed as non-differentiator, cost projections updated to ~$130-145/mo at realistic cache rates |
| 2.0 | 2026-02-28 | Plugin architecture & progressive disclosure: everything-is-a-plugin philosophy (Section 4.5), plugin categories/lifecycle/loading, progressive disclosure principle (Section 5.10), updated binary size to ~25MB core / ~50MB full, skill discovery pattern |

---

*Next: [02 — Core Architecture](./02-core-architecture.md)*
