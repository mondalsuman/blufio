# 2. Core Architecture

> Blufio Product Requirements Document — Section 2 of 5  
> Status: Draft v2.0 | Date: 2026-02-28

---

## 2.1 System Architecture Overview

Blufio is a single-process AI agent platform composed of five primary subsystems connected through typed Rust interfaces:

```
┌──────────────────────────────────────────────────────────────┐
│                        Blufio Process                         │
│                                                               │
│  ┌──────────────┐    ┌──────────────┐                        │
│  │   Gateway     │◄──►│  Agent Loop   │                       │
│  │  (axum HTTP   │    │  (FSM per     │                       │
│  │   + WebSocket)│    │   session)    │                       │
│  └──────┬───────┘    └──────┬───────┘                        │
│         │                   │                                 │
│         │            ┌──────▼───────┐                        │
│         │            │  Plugin Host  │                        │
│         │            │  (registry,   │                        │
│         │            │   loading)    │                        │
│         │            └──┬───┬───┬──┘                         │
│         │               │   │   │                             │
│         │     ┌─────────┘   │   └─────────┐                  │
│         │     ▼             ▼             ▼                   │
│         │  ┌────────┐ ┌──────────┐ ┌──────────┐             │
│         │  │Channels│ │Providers │ │Embedding │              │
│         │  │(plugin)│ │ (plugin) │ │ (plugin) │              │
│         │  └────────┘ └──────────┘ └──────────┘             │
│         │                                                     │
│  ┌──────▼───────┐    ┌──────────────┐                        │
│  │  Command      │    │  Session      │                       │
│  │  Queue        │◄──►│  Store        │                       │
│  │  (SQLite)     │    │  (plugin)     │                       │
│  └──────────────┘    └──────────────┘                        │
└──────────────────────────────────────────────────────────────┘
```

**Gateway** — The sole network entry point. Serves HTTP REST, WebSocket, and health endpoints on a single port via `axum`. All clients (CLI, web UI, mobile apps, paired nodes, channel webhooks) connect through it.

**Agent Loop** — An enum-based finite state machine that drives inference. Each inbound message spawns a loop instance that transitions through: Queued → ContextBuild → Inference → (ToolExec ↔ Inference)* → Streaming → Complete. Cancellation is checked between every state transition.

**Session Store** — SQLite in WAL mode providing ACID-guaranteed persistence for conversation transcripts, session metadata, and attachments. Replaces OpenClaw's mutable `sessions.json` + append-only JSONL files.

**Command Queue** — SQLite-backed persistent message queue with priority lanes, per-session serialization, dead-letter queue, and crash recovery. Replaces OpenClaw's in-memory promise-based queue.

**Provider Layer** — Multi-provider abstraction over LLM APIs (Anthropic, OpenAI, Ollama, etc.) with streaming, failover chains, API key rotation, and exponential backoff retry.

---

## 2.2 Binary & Crate Structure

### Single-Binary Philosophy

Blufio compiles into a single statically-linked binary (40-60 MB on Linux musl) with zero runtime dependencies. No Node.js, no package manager, no container required. Copy the binary to a server and run it.

```
$ file blufio
blufio: ELF 64-bit LSB executable, x86-64, statically linked, stripped
$ ls -lh blufio
-rwxr-xr-x 1 root root 45M Feb 28 14:00 blufio
```

Binary size: 40-50MB (Linux x86_64 musl, release build with LTO). The exact size depends on enabled features and link-time optimization level.

**Rationale**: OpenClaw requires Node.js 22+, npm, and 500+ transitive dependencies. This creates supply-chain risk, deployment complexity, and version conflicts. A static binary eliminates all of these.

### Subcommand Interface

The binary uses `clap` derive API for a git-style CLI:

```
blufio serve                  # Start the gateway daemon
blufio status                 # Show daemon status
blufio stop                   # Graceful shutdown
blufio config lint            # Validate config without starting
blufio sessions list          # List active sessions
blufio queue status           # Queue depth, dead letters, throughput
blufio vault set <key>        # Store encrypted credential
blufio agents list            # List configured agents
blufio agents create <id>     # Create a new agent
blufio migrate                # Run SQLite schema migrations
blufio completions <shell>    # Generate shell completions
blufio db inspect             # Render MessagePack fields as JSON for debugging
```

### Rust Crate Layout

Blufio uses a Cargo workspace from day 1. 7 crates: `blufio-core` (agent loop, context, memory), `blufio-gateway` (HTTP/WS server, API), `blufio-channels` (channel trait + adapters), `blufio-plugin-host` (plugin loading, registry, trait definitions, health monitoring), `blufio-sandbox` (WASM runtime), `blufio-cli` (binary entry point), `blufio-sdk` (public skill development API). This structure provides independent compilation, clear dependency boundaries, and faster incremental builds. The binary crate (`blufio-cli`) links all workspace crates into the final single binary.

Internal organization uses modules:

```
src/
├── main.rs                # CLI entry point (clap derive)
├── lib.rs                 # Crate root, re-exports
├── gateway/               # HTTP + WebSocket server (axum)
│   ├── ws.rs              # WebSocket frame handling
│   ├── http.rs            # REST API endpoints
│   ├── auth.rs            # Token validation, challenge-response
│   └── middleware.rs       # Rate limiting, tracing
├── agent/                 # Agent loop and orchestration
│   ├── loop.rs            # Core FSM inference loop
│   ├── inference.rs       # LLM call with retries/fallback
│   ├── tool_exec.rs       # Parallel tool dispatch via JoinSet
│   └── subagent.rs        # Sub-agent lifecycle
├── session/               # Session management
│   ├── store.rs           # SQLite persistence layer
│   ├── message.rs         # Message types
│   └── compaction.rs      # Summarize + prune in ACID transaction
├── provider/              # LLM provider abstraction
│   ├── anthropic.rs       # Anthropic Claude API
│   ├── openai.rs          # OpenAI-compatible API
│   ├── ollama.rs          # Local Ollama
│   └── streaming.rs       # SSE stream parsing
├── queue/                 # Command queue
│   ├── sqlite.rs          # SQLite-backed persistent queue
│   ├── lane.rs            # Per-session lane serialization
│   └── dead_letter.rs     # Failed message handling
├── channel/               # Messaging channel adapters
├── tool/                  # Tool trait + builtins
├── security/              # Vault, SSRF prevention, redaction
├── config/                # TOML config + hot-reload
├── db/                    # SQLite connection, migrations
└── metrics/               # Prometheus metrics, cost ledger
```

### Cross-Compilation Targets

| Target | OS | Arch | Linking | Notes |
|--------|-----|------|---------|-------|
| `x86_64-unknown-linux-musl` | Linux | x86_64 | Static (musl) | Primary server target, fully self-contained |
| `aarch64-unknown-linux-musl` | Linux | aarch64 | Static (musl) | ARM servers, Raspberry Pi |
| `x86_64-apple-darwin` | macOS | x86_64 | Dynamic (system) | Intel Macs |
| `aarch64-apple-darwin` | macOS | aarch64 | Dynamic (system) | Apple Silicon |

> **Note:** macOS builds use dynamic linking to system libraries and are **not fully portable** like Linux musl builds. They depend on the macOS SDK version and system dylibs at runtime. Do not copy macOS binaries between machines with different OS versions without testing.

### Plugin Host Architecture

Blufio's plugin system uses Rust's trait-based polymorphism with dynamic dispatch for runtime extensibility.

**Core adapter traits:**

```rust
/// All adapters implement this base trait
#[async_trait]
pub trait PluginAdapter: Send + Sync + 'static {
    fn name(&self) -> &str;
    fn version(&self) -> semver::Version;
    fn adapter_type(&self) -> AdapterType;
    async fn health_check(&self) -> Result<HealthStatus>;
    async fn shutdown(&self) -> Result<()>;
}

/// Channel adapters handle messaging I/O
#[async_trait]
pub trait ChannelAdapter: PluginAdapter {
    fn capabilities(&self) -> ChannelCapabilities;
    async fn connect(&mut self, config: &ChannelConfig) -> Result<()>;
    async fn send(&self, msg: OutboundMessage) -> Result<MessageId>;
    async fn receive(&self) -> Result<InboundMessage>;
    async fn edit(&self, id: MessageId, msg: OutboundMessage) -> Result<()>;
    async fn delete(&self, id: MessageId) -> Result<()>;
    async fn react(&self, id: MessageId, emoji: &str) -> Result<()>;
    fn format_adapter(&self) -> &dyn FormatAdapter;
}

/// LLM provider adapters handle model interaction
#[async_trait]
pub trait ProviderAdapter: PluginAdapter {
    fn supported_models(&self) -> &[ModelInfo];
    async fn complete(&self, req: CompletionRequest) -> Result<CompletionResponse>;
    async fn stream(&self, req: CompletionRequest) -> Result<Pin<Box<dyn Stream<Item = Result<StreamChunk>>>>>;
    fn supports_cache(&self) -> bool;
    fn supports_tools(&self) -> bool;
    fn token_counter(&self) -> &dyn TokenCounter;
}

/// Storage adapters handle persistence
#[async_trait]
pub trait StorageAdapter: PluginAdapter {
    async fn get_session(&self, key: &SessionKey) -> Result<Option<Session>>;
    async fn save_message(&self, session: &SessionKey, msg: &Message) -> Result<()>;
    async fn query_messages(&self, filter: MessageFilter) -> Result<Vec<Message>>;
    async fn transaction<F, T>(&self, f: F) -> Result<T>
    where F: FnOnce(&dyn StorageTxn) -> Result<T> + Send;
    // ... more CRUD operations
}

/// Embedding adapters handle vector operations
#[async_trait]
pub trait EmbeddingAdapter: PluginAdapter {
    fn dimensions(&self) -> usize;
    async fn embed(&self, texts: &[&str]) -> Result<Vec<Vec<f32>>>;
    async fn embed_query(&self, query: &str) -> Result<Vec<f32>>;
}

/// Observability adapters handle metrics/tracing export
#[async_trait]
pub trait ObservabilityAdapter: PluginAdapter {
    async fn record_metric(&self, metric: Metric) -> Result<()>;
    async fn export_traces(&self, spans: &[Span]) -> Result<()>;
    fn metrics_endpoint(&self) -> Option<&str>;
}
```

**Plugin registry and loading:**

```rust
pub struct PluginRegistry {
    channels: HashMap<String, Box<dyn ChannelAdapter>>,
    providers: HashMap<String, Box<dyn ProviderAdapter>>,
    storage: Box<dyn StorageAdapter>,       // exactly one active
    embedding: Box<dyn EmbeddingAdapter>,    // exactly one active
    observability: Vec<Box<dyn ObservabilityAdapter>>, // zero or more
}
```

Plugins are loaded at startup from `~/.blufio/plugins/`. Each plugin is a shared library exporting a `blufio_plugin_init` function:

```rust
#[no_mangle]
pub extern "C" fn blufio_plugin_init(registry: &mut PluginRegistrar) {
    registry.register_channel(Box::new(DiscordAdapter::new()));
}
```

**Plugin isolation:** Channel and provider plugins are I/O-bound and run in their own tokio tasks. A crashing plugin is caught via `catch_unwind` + task isolation — the gateway logs the failure and disables the plugin without taking down the process. `blufio doctor` reports plugin health.

**Plugin configuration:** Each plugin reads its config from a namespaced TOML section:

```toml
[plugins.discord]
enabled = true
bot_token = "vault:discord_bot_token"
guild_id = "123456789"

[plugins.openai]
enabled = true
api_key = "vault:openai_key"
```

**Plugin versioning:** Plugins declare their minimum compatible Blufio version in `plugin.toml`. The plugin host refuses to load incompatible plugins. Plugin API stability: the adapter traits are versioned. Breaking trait changes increment the plugin API version and require plugin recompilation. The goal: plugins compiled against API v1 work with any Blufio version that supports API v1.

---

## 2.3 Async Runtime

### Tokio Multi-Threaded Runtime

Blufio runs on Tokio's multi-threaded work-stealing scheduler:

```rust
#[tokio::main]
async fn main() -> Result<(), BlufioError> {
    let runtime = tokio::runtime::Builder::new_multi_thread()
        .worker_threads(
            std::thread::available_parallelism()
                .map_or(4, |n| n.get())  // defaults to available CPU cores; override via BLUFIO_WORKER_THREADS
        )
        .max_blocking_threads(
            std::thread::available_parallelism()
                .map_or(4, |n| n.get().min(4))  // min(available_parallelism(), 4)
        )                                        // CPU-intensive work
        .enable_all()
        .build()?;

    runtime.block_on(run_gateway()).await
}
```

`max_blocking_threads` is set to `min(available_parallelism(), 4)` — enough for concurrent embedding computations and image resizing without starving async tasks. The original value of 2 was too low for multi-session workloads. Default Tokio (512) is wasteful for the expected workload.

Worker thread count defaults to the number of available CPU cores via `available_parallelism()`, falling back to 4 if detection fails. Override with `BLUFIO_WORKER_THREADS` environment variable or `--worker-threads` CLI flag for constrained environments (e.g., 1-vCPU VPS).

On cgroup-constrained environments (fly.io shared CPUs, Hetzner shared VPS, Kubernetes with CPU limits), `available_parallelism()` may report the host CPU count rather than the cgroup limit. Operators on shared infrastructure should set `BLUFIO_WORKER_THREADS` explicitly to match their allocated CPU cores. The docs include a troubleshooting entry for this.

The install script auto-detects cgroup CPU limits on Linux: reads `/sys/fs/cgroup/cpu.max` (cgroup v2) or `/sys/fs/cgroup/cpu/cpu.cfs_quota_us` (cgroup v1) and sets `BLUFIO_WORKER_THREADS` in the systemd unit accordingly. On non-cgroup systems, `available_parallelism()` is used. The auto-detected value is logged at startup.

**Why not single-threaded?** OpenClaw's Node.js event loop is single-threaded. CPU-intensive operations (image processing via `sharp`, JSONL parsing, transcript hygiene) block the entire process — all sessions freeze. With Tokio's multi-threaded runtime:

- Async I/O tasks (HTTP, WebSocket, LLM API calls) are distributed across worker threads via work-stealing
- CPU-intensive operations are offloaded to blocking threads via `tokio::task::spawn_blocking` — they never block I/O threads
- Multiple agent loops run truly concurrently, not just concurrently-scheduled on one thread

### Task Spawning Strategy

| Work Type | Mechanism | Example |
|-----------|-----------|---------|
| Network I/O | `tokio::spawn` | LLM API calls, WebSocket handling |
| Per-session agent loop | `tokio::spawn` | One task per active agent loop |
| CPU-intensive | `spawn_blocking` | Image resize, embedding computation, large JSON serialization |
| Tool execution | `JoinSet` within agent task | Parallel tool calls with per-tool cancellation |
| Background maintenance | `tokio::spawn` with `CancellationToken` | Session pruning, queue cleanup, cert reload |

### Cancellation Architecture

A tree of `CancellationToken`s propagates shutdown signals from the gateway to individual tool calls:

```
Gateway CancellationToken (SIGTERM/SIGINT)
  └── Queue Worker token
       └── Agent Loop token (per-run)
            ├── Inference token (per-inference call)
            └── Tool tokens (per-tool, via child_token())
```

User-initiated abort (via `Abort` WebSocket frame) cancels the agent loop token. SIGTERM cancels the gateway token, which cascades to all children.

---

## 2.4 Gateway Server

### Architecture

The gateway is built on `axum` 0.8 + `hyper` 1.x + `tokio-rustls`. A single `Router` serves all endpoints on one port (default: `18789`, configurable via `--port` or `BLUFIO_GATEWAY_PORT`).

### Central State

```rust
pub struct GatewayState {
    pub sessions: SessionStore,
    pub queue: QueueManager,
    pub providers: ProviderRegistry,
    pub rate_limiter: RateLimiter,
    pub ws_manager: WsConnectionManager,
    pub auth_store: AuthStore,
    pub cancel: CancellationToken,
    pub config: ArcSwap<GatewayConfig>,   // Lock-free hot-reload
    pub start_time: Instant,
}
```

Configuration is stored behind `ArcSwap<GatewayConfig>`, enabling atomic pointer swaps without locking on the read path. Handlers read config via `state.config.load()` — zero-cost reads.

### API Endpoints

| Endpoint | Method | Auth | Description |
|----------|--------|------|-------------|
| `/health` | GET | No | Structured health check (database, providers, queue) |
| `/version` | GET | No | Binary version |
| `/metrics` | GET | No | Prometheus-format metrics |
| `/v1/chat/completions` | POST | Yes | OpenAI-compatible chat API |
| `/v1/responses` | POST | Yes | OpenAI Responses API |
| `/v1/models` | GET | Yes | List available models |
| `/ws` | GET | Yes | WebSocket upgrade |
| `/pair/init` | POST | No | Node pairing initiation |
| `/pair/complete` | POST | No | Node pairing completion |
| `/queue/status` | GET | Yes | Queue depth and lane utilization |
| `/queue/dlq` | GET | Yes | Dead-letter queue inspection |

### Authentication

Two mechanisms:

1. **Challenge-Response Pairing** — New nodes pair with the gateway through a challenge-response flow using Ed25519 signatures. The operator approves pending pairings. On completion, a 256-bit bearer token is issued.

2. **Bearer Token Auth** — All subsequent connections authenticate via `Authorization: Bearer <token>`. Token comparison uses constant-time comparison from the `ring` crate to prevent timing side-channel attacks.

**Token lifecycle:**
- Tokens should be rotated periodically via `blufio auth rotate-token <node_id>`. The old token remains valid for a configurable grace period (default: 1 hour) to allow clients to update.
- **Future:** Token expiry with configurable TTL, scope limitations (read-only, specific endpoints), and automatic rotation schedules are planned for v1.1.

### IPv6 Dual-Stack Support

The gateway supports IPv6 dual-stack: `[gateway.bind] = '[::]:18789'` listens on both IPv4 and IPv6. Default remains `127.0.0.1:18789` (IPv4 localhost only) for security. `[::1]:18789` for IPv6 localhost. Operators on IPv6-only infrastructure configure the bind address accordingly.

### Security Invariant

Binding to a non-loopback address **requires** authentication to be configured. Blufio refuses to start without it:

```rust
if !bind_addr.is_loopback() && auth_token.is_none() {
    return Err(ConfigError::InsecurePublicBind);
}
```

### TLS

Blufio uses `rustls` exclusively — a pure-Rust TLS implementation with no C dependencies (no OpenSSL, no heartbleed-class vulnerabilities). Certificates are hot-reloaded via file watcher + `ArcSwap` — new connections use the new cert, existing connections continue with the old one.

### Connection Lifecycle

WebSocket connections follow a strict four-phase lifecycle:

1. **Authentication** — First frame MUST be `Auth { token, encoding, protocol_version }`. Any other frame triggers immediate disconnect. 5-second timeout.
2. **Subscription** — Optional session resume/list
3. **Interaction** — Bidirectional message exchange (user messages, streaming responses, tool calls)
4. **Keepalive** — Client pings every 30s. Connections idle >90s are evicted.

### WebSocket Protocol Specification

**(a) Ping/pong:** Server sends ping every 30s, client must respond within 10s or connection is closed.

**(b) Reconnection:** Clients use exponential backoff (1s, 2s, 4s, 8s, max 60s) with jitter. On reconnect, client sends Auth frame; server replays any queued messages since disconnection.

**(c) Message ordering:** Messages within a session are ordered by server-assigned sequence numbers. Out-of-order delivery is detected and buffered client-side.

**(d) Backpressure:** If the send buffer exceeds 1MB, the server drops non-critical frames (typing indicators) and eventually closes with code 1008 (policy violation).

**(e) Binary format:** All frames are UTF-8 JSON. MessagePack encoding is opt-in via `Accept: application/msgpack` in the Auth frame.

**(f) Compression:** Per-message deflate (`permessage-deflate`) is supported and enabled by default for connections identified as high-bandwidth (mobile nodes, high-throughput channels). Compression reduces bandwidth by 60-80% for JSON text frames. Disabled for local connections (localhost) where bandwidth is not a concern. Configurable via `[gateway.ws_compression] = true|false`.

### Heartbeat Polling & Race Condition

The polling-based heartbeat has an inherent race condition: messages arriving between the pre-check and the next cycle wait for the full interval. Mitigation: the gateway pushes a wakeup notification to the heartbeat scheduler when a message arrives during idle. This event-driven wake supplements (not replaces) the periodic polling, ensuring messages are processed within seconds even during quiet periods.

Check 4 (`/api/events/pending`) is optimized via an in-memory dirty bit: the gateway sets a flag when any event arrives that would need heartbeat attention. The pre-check reads this flag (O(1) memory read) instead of querying SQLite. The flag is reset after each heartbeat cycle. The HTTP endpoint still exists for external monitoring but the shell script uses a lightweight `/api/heartbeat/dirty` endpoint that returns a single boolean.

### Rate Limiting

Token-bucket rate limiting at two levels:

| Bucket | Rate | Burst | Purpose |
|--------|------|-------|---------|
| Per-IP | 10 req/s | 50 | Abuse prevention before auth |
| Per-Sender | 5 req/s | 20 | Fair resource allocation |
| WS messages | 30 msg/s | 100 | Per-connection flood protection |

### Hot-Reloadable Settings

| Setting | Hot-Reload? |
|---------|-------------|
| Agent config, models, routing | ✅ Yes |
| Channel configs | ✅ Yes |
| Session settings, hooks, cron | ✅ Yes |
| Rate limit parameters | ✅ Yes |
| TLS certificates | ✅ Yes |
| **Bind address / port** | ❌ Restart required |
| **Auth tokens** | ⚡ Via CLI (see below) |

`blufio auth rotate-token --instance <name>` generates a new bearer token, updates the config, and gracefully restarts the specific instance without dropping active sessions. Pending messages are drained before the restart.

Config changes are detected via `notify` file watcher with 300ms debounce. Safe changes are applied via `ArcSwap`; restart-requiring changes log a warning.

**Hot-reload safe (SIGHUP):** `log_level`, `rate_limits`, `hooks`, `cost_budgets`, `context.zone1_budget`, `providers.fallback_chain`.

**Restart required:** `database.path`, `channels.*` (adapter reconnection), `security.*`, `embedding.model`, `bind_address`, `tls.*`.

Attempting to hot-reload a restart-required key logs a warning and is ignored. `blufio config diff` shows which pending changes require restart.

### Graceful Shutdown

1. OS signal (SIGTERM/SIGINT) triggers root `CancellationToken`
2. Gateway stops accepting new connections
3. `Shutdown` frame sent to all WebSocket clients
4. Active agent loops check cancellation between state transitions
5. 10-second grace period for in-flight operations
6. Process exits

---

## 2.5 Gateway Protocol

### Wire Format

All WebSocket communication uses typed JSON frames wrapped in a compact envelope:

```rust
pub struct WsFrame {
    pub msg_type: FrameType,      // "t" — type discriminator
    pub id: Option<String>,        // "id" — unique message ID
    pub reply_to: Option<String>,  // "re" — correlates response with request
    pub data: serde_json::Value,   // "d" — payload
    pub timestamp: u64,            // "ts" — Unix millis
}
```

### Message Types

```rust
pub enum FrameType {
    // Connection control
    Ping, Pong, Auth, AuthOk, AuthFail, Error,
    // Agent interaction
    UserMessage, AssistantChunk, AssistantComplete,
    ToolCall, ToolResult, Abort,
    // Session management
    SessionCreate, SessionResume, SessionList, SessionReset,
    // Node operations
    NodeStatus, NodeCapability, NodeInvoke, NodeResult, CanvasStream,
    // System
    Shutdown, ConfigReload,
}
```

### Encoding Negotiation

Clients negotiate encoding during auth. Two options:

| Encoding | Format | Use Case |
|----------|--------|----------|
| `json` (default) | Text frames | Human-readable, debugging, development |
| `msgpack` | Binary frames | ~30% bandwidth reduction for mobile nodes and high-throughput channels |

> **Why MessagePack?** JSON is the default and recommended encoding for all development and debugging. MessagePack is offered as an opt-in optimization for bandwidth-constrained environments (mobile nodes, metered connections). The `blufio db inspect` command renders all MessagePack-encoded fields as JSON for debugging. MessagePack is never required — JSON is always supported.

After `AuthOk`, all subsequent frames use the negotiated encoding.

### Wire Protocol Versioning

The Auth frame includes a `protocol_version: u16` field. The server responds with AuthOk containing the negotiated version. Unsupported versions receive an error frame with upgrade instructions. This prevents silent breakage when the wire format evolves between Blufio versions.

### Request-Response Correlation

Frames carry optional `id` and `reply_to` fields. A request with `id: "abc123"` receives a response with `reply_to: "abc123"`. This enables multiplexed bidirectional communication without head-of-line blocking.

### Streaming Pattern

LLM responses stream as a sequence of `AssistantChunk` frames (each containing a text delta), terminated by `AssistantComplete`. If the LLM returns tool calls, a `ToolCall` frame is emitted instead of `AssistantComplete`, followed by `ToolResult` frames, then a new inference cycle begins.

### Backpressure

Per-connection send channels are bounded (256 frames). If a slow client's channel fills, frames are dropped and the connection is closed. This prevents a single slow client from consuming unbounded server memory.

---

## 2.6 Agent Loop

### State Machine

The agent loop is modeled as an explicit enum-based finite state machine. Every state and transition is a `match` arm — no hidden states, no implicit transitions.

```rust
pub enum AgentState {
    Idle,
    Queued { queue_id: i64, enqueued_at: Instant },
    ContextBuild { session_key: String, started_at: Instant },
    Inference { provider: String, model: String, started_at: Instant },
    ToolExec { tools: Vec<PendingToolCall>, started_at: Instant },
    Streaming { chunks_sent: usize, bytes_sent: usize, started_at: Instant },
    Complete { tokens_in: usize, tokens_out: usize, cost_usd: f64,
              duration: Duration, tool_rounds: usize },
    Failed { error: AgentError, state_at_failure: String },
}
```

### State Transition Diagram

```
Idle → Queued → ContextBuild → Inference → Streaming → Complete
                                    ↓            ↑
                                 ToolExec ────────┘
Any state ──(cancellation)──→ Failed
```

### Execution Flow

1. **Queued** — Message received from queue, awaiting execution slot
2. **ContextBuild** — Load session history from SQLite, assemble system prompt, inject workspace files, format tool schemas. Timeout: 5s.
3. **Inference** — Send completion request to LLM provider via streaming API. Timeout: 120s. On rate limit or provider failure, attempt failover.
4. **Streaming** — Forward text deltas to client in real-time. Accumulate tool call deltas if present.
5. **ToolExec** — Execute tool calls. **Parallel by default** via `JoinSet` (OpenClaw executes sequentially). Each tool gets its own child `CancellationToken` and timeout (default: 60s). After execution, loop back to Inference with tool results.
6. **Complete** — Persist final state, emit usage metrics.

### Per-Phase Timeouts

| Phase | Default | Rationale |
|-------|---------|-----------|
| Context build | 5s | File I/O should be fast |
| Inference | 120s | LLM API calls with long outputs |
| Tool execution | 60s per tool | Individual tool calls |
| Overall run | 600s | Hard cap matching OpenClaw |
| Hook execution | 30s | Configurable per-hook via `timeout_secs`. Hooks exceeding the timeout are killed with SIGTERM, then SIGKILL after 5 seconds. |
| Max tool rounds | 25 | Prevent infinite tool loops |

### Error Recovery

Every operation returns `Result<T, AgentError>`. Lint policy: `deny(clippy::unwrap_used)`. `allow(clippy::expect_used)` — `expect()` with descriptive messages is the standard error handling pattern. The message serves as documentation for invariant violations. `unwrap()` is banned; `expect("reason")` is required. Prefer proper error propagation via `?` where possible; `expect()` is for provably-infallible paths (e.g., after a guard clause that guarantees `Some`). Error variants include:

- `Provider(ProviderError)` — LLM API errors (rate limited, auth failed, unavailable)
- `Tool { tool, error }` — Tool execution failures
- `Session(String)` — Session persistence errors
- `Timeout(String)` — Per-phase timeouts
- `Cancelled` — User or system abort
- `ContentFiltered` — Provider content policy rejection
- `MaxToolRounds(usize)` — Safety limit exceeded

Errors are mapped to user-friendly messages at the gateway layer. Provider errors trigger failover when appropriate.

### Observability

Every state transition emits a `tracing` span with structured fields (session key, provider, model, tool count, round number). Agent events (state changes, chunks, tool starts/ends, usage) are pushed to observers via `mpsc` channels.

### Event Bus Backpressure

The event bus uses `tokio::sync::broadcast` with a buffer of 4,096 events. Buffer size rationale: at 50 concurrent sessions generating ~10 events/second each = 500 events/sec peak. 4096 provides ~8 seconds of headroom. Overflow (`Lagged(n)`) triggers: consumer catches up by skipping n events, logged as a warning. Configurable via `[gateway.event_bus_capacity]` for high-throughput deployments. When a slow subscriber (e.g., webhook with backoff) falls behind, it receives a `Lagged(n)` error indicating missed events. Missed events are recoverable from the SQLite event log for webhook delivery. Critical events (cost alerts, security events) use a separate dedicated channel that never drops.

---

## 2.7 Provider Abstraction

### Core Trait

```rust
#[async_trait]
pub trait LlmProvider: Send + Sync + 'static {
    async fn complete(&self, req: CompletionRequest) -> Result<CompletionStream, ProviderError>;
    fn supports_tools(&self) -> bool;
    fn model_info(&self) -> &ModelInfo;
    async fn health_check(&self) -> ComponentStatus;
}
```

`CompletionStream` is a `BoxStream<'static, Result<CompletionChunk, ProviderError>>` — a typed async stream of response chunks containing text deltas, tool call deltas, finish reasons, and usage statistics.

### Provider Registry with Failover Chain

The `ProviderRegistry` maps model IDs to ordered lists of providers (primary + fallbacks). Two-stage failover:

1. **API Key Rotation** (within provider) — When a provider returns a retryable error (429, 5xx, timeout), the current API key is placed in cooldown and the next key in rotation is tried. Cooldown uses exponential backoff (1min → 2min → 4min → ... → 16min cap).

2. **Model Fallback** (across providers) — If all API keys for a provider are exhausted, the agent loop advances to the next model in the configured fallback chain.

### Retry Policy

```rust
pub struct RetryPolicy {
    pub max_retries: u32,        // default: 3
    pub base_delay: Duration,    // default: 1s
    pub max_delay: Duration,     // default: 30s
    pub jitter: f64,             // default: 0.1 (±10%)
}
```

Retryable errors: `RateLimited`, `Unavailable`, `Request` (network). Non-retryable: `AuthFailed`, `ModelNotFound`, `ContextLengthExceeded`, `ContentFilter`.

Provider-specific `retry-after` headers are respected.

### Provider Circuit Breaker

Provider circuit breaker: after 3 consecutive failures within 60 seconds, the circuit opens for that provider. While open, requests are routed to the fallback provider chain: `[providers.fallback_chain] = ['anthropic', 'openai', 'local']`. If all providers in the chain fail, the agent returns a configurable error message to the user ('I'm temporarily unable to process requests. Please try again shortly.') and emits `blufio_provider_circuit_open` metric. The circuit half-opens after 30s, allowing a single probe request. Configurable via `[providers.circuit_breaker]`.

### Tool Schema Fallback Cost

When a tool is called without its full schema loaded, the runtime intercepts and re-prompts with the schema (one extra round-trip). This costs ~500-1,500 additional tokens on first use per session per tool. The cost projections account for an average of 3 tool schema loads per session (~2,000 extra tokens), which is included in the 5-10K/turn overhead estimate.

### Model Deprecation Handling

Providers deprecate models regularly. Blufio handles this via: (a) Model alias resolution — config uses aliases (`default`, `fast`, `strong`) that map to specific model IDs. When a model is deprecated, updating the alias config is a single-line change. (b) Deprecation detection — if a provider returns a deprecation warning header, Blufio logs a prominent warning and emits a `blufio_model_deprecated` Prometheus metric. (c) Automatic fallback — if a configured model returns a 404/gone response, Blufio falls back to the next model in the priority list and alerts the operator. No silent failures.

If a model alias is updated between turns (e.g., `claude-sonnet` remapped), the cache prefix changes and all cached context is invalidated. The provider abstraction handles this gracefully: the next turn pays full prompt cost (no cache hit), and subsequent turns build a new cache. `blufio doctor` warns when model alias changes are detected. No operator action is needed — it's a temporary cost spike, not data loss.

### MCP Client Specification (Phase 1)

**Phase 1 deliverable:** Basic MCP client (stdio + HTTP transport, tool discovery, tool invocation).

MCP client specification: (a) Transport: stdio (for local MCP servers) and SSE/HTTP (for remote). (b) Discovery: MCP server URLs configured in `[mcp.servers]` TOML table with per-server auth (`bearer`, `api-key`, or `none`). (c) Tool injection: MCP tool schemas are fetched on startup and registered in the tool index alongside native tools. The context engine treats MCP tools identically to built-in tools (lazy schema loading applies). (d) Invocation: MCP tool calls are proxied through the MCP client with timeout and retry. (e) Phase 1 scope: connect to MCP servers, list tools, invoke tools. Resource and prompt primitives are Phase 3.

### Structured Output / JSON Mode

JSON mode / structured output enforcement varies by provider: Anthropic uses tool_use with a schema as a workaround (no native JSON mode), OpenAI uses `response_format: {type: 'json_object'}`, Google uses `response_mime_type`. The provider abstraction normalizes this — callers request structured output and the provider adapter translates to the appropriate mechanism. When native JSON mode is unavailable, Blufio wraps the request in a tool_use call and extracts the structured response.

### Rate Limit Coordination Across Instances

Multiple Blufio instances sharing the same provider API key independently track rate limits. For coordinated rate limiting across instances, operators can configure a shared rate limit backend via `[providers.rate_limit_backend]`: (a) `local` (default) — per-instance tracking, suitable for single-instance. (b) `file` — SQLite file lock, suitable for multi-instance on same host. (c) `redis` — shared Redis counter, suitable for distributed deployments. At launch, only `local` is implemented. `file` and `redis` are Phase 3.

### Supported Providers

Providers are plugins implementing the `ProviderAdapter` trait. The core ships with Anthropic. OpenAI, Ollama, Google, and Groq are official plugins installed separately. Custom providers (e.g., corporate proxy, fine-tuned models) implement the same trait.

| Provider | Streaming | Tool Calling | Cache Support | Bundled |
|----------|-----------|-------------|---------------|---------|
| Anthropic Claude | ✅ SSE | ✅ Native | ✅ Prompt cache | ✅ Core |
| OpenAI-compatible | ✅ SSE | ✅ Native | ✅ Via prefix | Official plugin |
| Ollama (local) | ✅ SSE | ✅ Native | ❌ | Official plugin |
| Google Gemini | ✅ SSE | ✅ Native | ✅ Context cache | Official plugin |
| Groq | ✅ SSE | ✅ Native | ❌ | Official plugin |

### Prompt Cache Alignment

Blufio structures prompts for maximum cache hit rates:

```
[STABLE PREFIX — cached across all requests]     ~17,000 tokens
├── Core system prompt (safety, capabilities)
├── Tool schemas (pre-serialized, deterministic)
├── Skill metadata
└── Workspace files (AGENTS.md, SOUL.md, etc.)

  Zone 1 (static context): 5,000–8,000 tokens depending on workspace
  complexity. SOUL.md (~800 tokens), AGENTS.md (~2,000 tokens), and
  core behavioral rules (~1,000 tokens) already consume ~4,000 tokens.
  The budget is configurable via [context.zone1_budget]. When Zone 1
  overflows, lowest-priority static files are demoted to Zone 2
  (conditional) with a warning in the operator log.

[SEMI-STABLE — cached within a session]          ~700 tokens
├── Agent-specific instructions
└── Session context

[DYNAMIC — changes every turn]                    variable
├── Conversation history
├── Runtime metadata (moved to END, not beginning)
└── Active context
```

**Key design decision**: Runtime metadata (timestamp, model name) is placed at the END of the prompt, not the beginning. This prevents timestamp changes from invalidating the stable prefix cache.

**Expected cache hit rate:** ~85% within active conversations (cache warm). After idle gaps exceeding provider TTL (typically 5 minutes for Anthropic), the first turn is uncached and must re-fill the cache. Cross-session cache sharing depends on stable prefix overlap. Actual savings depend heavily on conversation patterns and idle time distribution.

---

## 2.8 Session Management

### Storage: SQLite with WAL Mode

All session data is stored in a single SQLite database with WAL (Write-Ahead Logging) mode:

```sql
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA foreign_keys = ON;
PRAGMA busy_timeout = 5000;
```

> **Durability note:** `synchronous = NORMAL` in WAL mode protects against process crashes but trades durability against **power loss** for performance. Committed transactions can be lost if the machine loses power (not just if the process crashes). For maximum durability, set `synchronous = FULL` at the cost of ~2× slower writes. The `command_queue` table uses `PRAGMA synchronous = FULL` by default. Message loss in the queue is unacceptable — durability takes priority over write throughput for queued commands. Other tables (sessions, messages, memory) default to NORMAL, which is safe against process crashes but not power loss. Operators on battery-backed or redundant storage may override via `[database.queue_synchronous]`.

**SQLite Single-Writer Considerations:**

SQLite WAL allows concurrent reads but enforces single-writer. Under high write contention (50+ concurrent sessions generating cost events, memory writes, queue operations simultaneously), this becomes a bottleneck. Mitigations: (a) Write batching — aggregate cost events and memory writes into periodic bulk inserts (every 100ms). (b) WAL checkpointing — configure `wal_autocheckpoint` to prevent unbounded WAL growth (default: 1000 pages). (c) Write-ahead buffering — non-critical writes (metrics, cost events) buffer in memory and flush asynchronously. (d) For deployments exceeding ~100 concurrent sessions, the PRD recommends evaluating PostgreSQL via the `StorageBackend` trait (Phase 4 consideration, not Phase 1).

When write contention becomes a bottleneck (~50+ concurrent active sessions), the upgrade path is: (a) Phase 1-3: optimize with write batching and async flush (already specified). (b) Phase 4: `StorageBackend` trait abstraction allows swapping SQLite for PostgreSQL. Migration tool: `blufio db export --format pg-dump` generates a PostgreSQL-compatible dump. `blufio serve --storage postgres://...` switches the backend. Schema compatibility is maintained — the same tables, same queries, different engine. This is a deliberate architectural boundary, not an afterthought.

**Why SQLite over JSONL files?**

| Property | OpenClaw (JSONL) | Blufio (SQLite WAL) |
|----------|-----------------|---------------------|
| Atomicity | None — crash mid-write corrupts | ACID transactions |
| Concurrent access | Lock files, possible races | WAL mode (concurrent reads during writes) |
| Compaction | Full file rewrite | DELETE + INSERT in single transaction |
| Querying | Read entire file, filter in memory | SQL queries with indexes |
| Pruning | Not built-in | `DELETE` with `CASCADE` |

### Schema

```sql
CREATE TABLE sessions (
    key TEXT PRIMARY KEY,              -- Colon-delimited session key
    agent_id TEXT NOT NULL,
    session_id TEXT NOT NULL,          -- Changes on reset
    chat_type TEXT NOT NULL DEFAULT 'direct',
    channel TEXT,
    dm_scope TEXT NOT NULL DEFAULT 'per-peer',
    state TEXT NOT NULL DEFAULT 'active',
    total_input_tokens INTEGER DEFAULT 0,
    total_output_tokens INTEGER DEFAULT 0,
    total_cost_usd REAL DEFAULT 0.0,
    compaction_count INTEGER DEFAULT 0,
    encryption_key BLOB,               -- Optional AES-256-GCM key
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    metadata BLOB                      -- MessagePack-encoded structured metadata (see §2.5 for MessagePack rationale). Use `blufio db inspect` to render as JSON for debugging.
) STRICT;

CREATE TABLE messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_key TEXT NOT NULL REFERENCES sessions(key) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system', 'tool')),
    content TEXT,
    tool_calls BLOB,                   -- MessagePack: Vec<ToolCall>
    tool_call_id TEXT,
    tokens_in INTEGER,
    tokens_out INTEGER,
    cost_usd REAL,
    created_at TEXT NOT NULL,
    is_summary INTEGER DEFAULT 0,
    tool_names TEXT                     -- Comma-separated tool names (e.g., 'exec,web_fetch')
) STRICT;

-- Covering index for tool usage analytics
CREATE INDEX idx_messages_tool_names ON messages(session_key, tool_names);
```

A `tool_names TEXT` column stores a comma-separated list of tool names used in each message (e.g., `'exec,web_fetch'`). This enables efficient queries like `SELECT * FROM messages WHERE tool_names LIKE '%exec%'` without deserializing the MessagePack BLOB. The column is populated on insert from the tool_calls data. A covering index on `(session_id, tool_names)` supports tool usage analytics.

```sql
CREATE TABLE message_attachments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id INTEGER NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
    filename TEXT,
    mime_type TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    data BLOB,                         -- Inline storage for small attachments only
    external_path TEXT,                -- Path to external storage for large attachments
    created_at TEXT NOT NULL
) STRICT;
```

> **Attachment storage policy:** Attachments ≤1 MB (configurable via `[storage] inline_attachment_max_bytes`) are stored inline in the `data` BLOB column. Attachments exceeding this threshold are written to external storage (filesystem directory or S3-compatible object store) and referenced via `external_path`. This prevents database bloat from large media files. The `blufio storage gc` command cleans orphaned external files.

### Session Keys

Session keys are typed enums, not raw strings:

```rust
pub enum SessionKey {
    DirectMain { agent_id, main_key },
    DirectPeer { agent_id, peer_id },
    DirectChannelPeer { agent_id, channel, peer_id },
    Group { agent_id, channel, group_id },
    Room { agent_id, channel, channel_id },
    Topic { agent_id, channel, group_id, thread_id },
    Cron { job_id },
    Hook { hook_id },
    Subagent { agent_id, subagent_id },
}
```

Keys serialize to colon-delimited strings (e.g., `agent:main:telegram:dm:123456789`) for database storage and parse back with validation.

### OutboundMessage

```rust
pub struct OutboundMessage {
    pub session_id: SessionId,
    pub channel: ChannelId,
    pub content: MessageContent,      // text, media, or rich (buttons, embeds)
    pub reply_to: Option<MessageRef>, // platform message ID to reply to
    pub format_hints: FormatHints,    // markdown, plain, html preference
    pub metadata: HashMap<String, Value>,
}
```

The `FormatAdapter` transforms `OutboundMessage` into channel-specific payloads based on the target channel's capabilities.

### DM Scope — Secure by Default

**Critical difference from OpenClaw**: Blufio defaults to `per-peer` DM scope (each sender gets an isolated session). OpenClaw defaults to `main` (all DMs share one session — a privacy risk in multi-user deployments).

| Scope | Key Format | Use Case |
|-------|-----------|----------|
| `main` | `agent:<id>:<main_key>` | Single-user only |
| `per-peer` (default) | `agent:<id>:dm:<peer_id>` | Multi-user safe |
| `per-channel-peer` | `agent:<id>:<channel>:dm:<peer_id>` | Multi-channel |
| `per-account-channel-peer` | Full qualification | Multi-bot-account |

### Session Lifecycle

```
create → active → idle → archived → deleted
            ↑       │
            └───────┘  (new message reactivates)
```

Reset policies are configurable per channel and per chat type: `daily` (reset at configured hour), `idle` (reset after N minutes of inactivity), or `manual` (only via `/new` or `/reset`).

### Compaction

When message count exceeds the trigger threshold (default: 200), Blufio performs atomic compaction:

1. **Optional memory flush** — Ask the LLM to extract important facts from old messages and write them to workspace files
2. **Summarize** — Generate a summary of messages to be removed
3. **Atomic transaction** — DELETE old messages + INSERT summary as system message + UPDATE compaction counter — all in one ACID transaction

If the process crashes mid-compaction, the transaction rolls back and no data is lost. OpenClaw's JSONL compaction requires a full file rewrite, risking corruption on crash.

Compaction quality scoring includes a `tool_action` dimension — scores messages containing tool invocations with side effects (file creation, exec commands, API calls). Preserves what the agent DID, not just what was discussed. Tool name, key parameters, and outcome summary survive compaction.

Session resets (`/new`) create a compaction boundary — the pre-reset conversation is summarized and stored as a compaction artifact. The new session starts with a clean context but retains access to the summary via memory search. Sub-agent sessions maintain independent context with a parent reference — the parent session's compaction summaries are searchable but not injected by default. Tool references in compaction summaries that point to tools no longer in the active session are annotated with `[tool no longer available]` during context assembly.

### Encryption

Optional per-session AES-256-GCM encryption using the `ring` crate. When enabled, message content is encrypted before INSERT and decrypted on SELECT. The per-session encryption key is stored in the `sessions.encryption_key` column, protected by filesystem permissions.

Per-session encryption keys protect session data when exported or backed up independently of the main database. With SQLCipher enabled (recommended), the per-session key is redundant for at-rest protection but provides defense-in-depth for data-in-transit scenarios (session export, cross-instance migration, backup to untrusted storage). Without SQLCipher, per-session keys are the sole encryption layer — in this mode, the keys are stored alongside the data they protect, which is acknowledged as weaker. `blufio doctor` warns when SQLCipher is disabled and per-session encryption is the only layer.

### Migration from OpenClaw

A built-in migration tool reads OpenClaw's `sessions.json` + `*.jsonl` files and imports them into the SQLite database, preserving all conversation history.

---

## 2.9 Multi-Agent Routing

### Agent as Isolation Unit

Each agent is a fully isolated "brain" with its own:

- **Workspace** — Separate directory (`~/.blufio/workspaces/<agent_id>/`) containing SOUL.md, MEMORY.md, memory/, skills/
- **State** — Separate config, auth profiles, sessions (`~/.blufio/agents/<agent_id>/`)
- **Database** — Separate SQLite memory database per agent
- **Encryption** — Per-agent Ed25519 keypair + AES-256-GCM vault key

Isolation is enforced at filesystem, database, credential, and policy levels. For stronger guarantees, per-agent container sandboxing can be enabled.

### Binding System

Bindings are config-driven rules that deterministically route inbound messages to agents. No AI decision-making — pure pattern matching:

```toml
[[bindings]]
agent_id = "work"
[bindings.match_rule]
channel = "slack"
team_id = "T123ABC"

[[bindings]]
agent_id = "family"
[bindings.match_rule]
channel = "whatsapp"
peer = { kind = "group", id = "120363...@g.us" }
```

### Most-Specific-Wins Priority

| Priority | Match Type | Example |
|----------|-----------|---------|
| 1 (highest) | Exact peer ID | This specific DM or group |
| 2 | Parent peer (thread inheritance) | Thread in a matched parent |
| 3 | Guild + roles | Discord server + role |
| 4 | Guild | Discord server |
| 5 | Team | Slack workspace |
| 6 | Account | Channel account |
| 7 | Channel | All Telegram traffic |
| 8 (lowest) | Default agent | Fallback |

### Per-Agent Configuration

Each agent can have independent model, tool restrictions, and sandbox settings:

```toml
[[agents]]
id = "main"
model = "anthropic/claude-opus-4-6"
thinking = "medium"
default = true

[[agents]]
id = "family"
model = "anthropic/claude-haiku-3"
[agents.tools]
allow = ["read", "web_search", "web_fetch"]  # Read-only
[agents.sandbox]
mode = "all"
[agents.sandbox.limits]
memory_mb = 256
network = false
```

### Agent-to-Agent Messaging

Off by default. When enabled, agents communicate via Ed25519-signed messages with replay protection:

```rust
pub struct AgentMessage {
    pub from_agent: String,
    pub to_agent: String,
    pub payload: String,
    pub timestamp: u64,        // Unix millis
    pub nonce: [u8; 16],       // Replay prevention
    pub signature: Vec<u8>,    // Ed25519 signature over payload + timestamp + nonce
}
```

Messages are verified against known peer public keys. Timestamp freshness is checked (configurable max age). The nonce LRU cache is sized to cover the configured `max_age` window. Default: `max_age = 300s` with estimated peak throughput determines cache size. At 100 msg/sec across 10 agents, a 300s window requires ~30,000 entries. The cache auto-sizes at startup based on `[security.replay_prevention.max_age]` and `[security.replay_prevention.estimated_throughput]`. Only explicitly allow-listed agent pairs can communicate.

**Improvement over OpenClaw**: OpenClaw's agent messaging has no authentication — any agent can impersonate another. Blufio's Ed25519 signatures prevent forgery and replay.

### Broadcast Groups

Multiple agents can process the same inbound message independently:

```toml
[broadcast]
strategy = "parallel"  # or "sequential"
[broadcast.groups]
"120363...@g.us" = ["code-reviewer", "security-auditor"]
```

Broadcast overrides bindings for matching peer IDs. Each agent gets its own isolated session. Agents fail independently.

**Response coordination:** When multiple agents in a broadcast group produce responses to the same inbound message, a **first-responder claim** mechanism prevents duplicate replies. The first agent to complete its response claims the reply slot by atomically inserting a `broadcast_reply` record keyed on `(inbound_message_id, peer_id)`. Subsequent agents check this record before sending; if claimed, their response is logged but not delivered. This is configurable — set `broadcast.dedup = false` to allow all agents to reply independently (useful for audit/review scenarios where multiple perspectives are desired).

---

## 2.10 Command Queue

### Design

Every inbound message flows through a SQLite-backed persistent queue before reaching the agent loop. This ensures crash durability — if the process dies, all queued messages survive and are picked up on restart.

**Why not in-memory?** OpenClaw's promise-based queue loses every queued message on crash. For a personal assistant processing a DM while group chat messages queue up, this is unacceptable.

### Schema

```sql
CREATE TABLE command_queue (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_key     TEXT    NOT NULL,
    channel         TEXT    NOT NULL,
    sender_id       TEXT,
    priority        INTEGER NOT NULL DEFAULT 5,
    payload         TEXT    NOT NULL,     -- JSON
    status          TEXT    NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','processing','completed','failed','dead')),
    mode            TEXT    NOT NULL DEFAULT 'collect',
    created_at      TEXT    NOT NULL,
    started_at      TEXT,
    completed_at    TEXT,
    error           TEXT,
    retry_count     INTEGER NOT NULL DEFAULT 0,
    max_retries     INTEGER NOT NULL DEFAULT 3,
    worker_id       TEXT                 -- UUID generated per process start; prevents stale claims after restart
);
```

### Atomic Dequeue

Blufio uses SQLite's `UPDATE ... RETURNING` (3.35+) for race-free dequeue in a single statement:

```sql
UPDATE command_queue
SET    status = 'processing', started_at = now(), worker_id = ?1
WHERE  id = (
    SELECT id FROM command_queue
    WHERE  status = 'pending'
      AND  session_key NOT IN (
          SELECT session_key FROM command_queue WHERE status = 'processing'
      )
    ORDER BY priority DESC, created_at ASC
    LIMIT 1
)
RETURNING *;
```

This atomically: (1) finds the highest-priority pending item whose session has no active run, (2) claims it, (3) returns the full row. No TOCTOU races. No external locks.

### Per-Session Serialization

The subquery `session_key NOT IN (SELECT ... WHERE status = 'processing')` ensures only one message processes per session at a time. This is non-negotiable — concurrent runs on the same session would corrupt conversation state.

### Priority Lanes

| Source | Priority | Rationale |
|--------|----------|-----------|
| Owner DM | 10 | The human running the system — always first |
| Allowed sender DM | 8 | Explicitly trusted users |
| Group (owner present) | 7 | Owner is in the conversation |
| Group (general) | 5 | Default |
| Cron job | 3 | Background work |
| Subagent | 1 | Machine-generated, can wait |

### Lane Concurrency

| Lane | Default Max Concurrent | Purpose |
|------|----------------------|---------|
| `main` | 4 | Inbound chat messages |
| `cron` | 2 | Scheduled background jobs |
| `subagent` | 8 | Sub-agent spawned runs |
| **Global cap** | 14 | Total across all lanes |

### Queue Modes

| Mode | Behavior |
|------|----------|
| `collect` (default) | Messages arriving during an active run are coalesced into a single followup turn. Debounce: 1s quiet period, 5s max wait. |
| `steer` | Inject new message into running session at the next tool boundary. Falls back to `followup` if no run active. |
| `followup` | Each message gets its own sequential turn — no coalescing. |

### Retry with Backoff

Failed items return to `pending` with incremented `retry_count`. Backoff delay: `2^retry_count` seconds (2s, 4s, 8s). Items exceeding `max_retries` (default: 3) move to the dead-letter queue.

### Dead-Letter Queue

Messages that exhaust all retries are moved to a separate `dead_letter_queue` table — never silently dropped. Operations:

- **Inspect**: `blufio queue dlq` or `GET /queue/dlq`
- **Retry**: `blufio queue retry <id>` — re-enqueue with reset retry count
- **Purge**: `blufio queue dlq purge --older-than 7d`

**Improvement over OpenClaw**: OpenClaw silently drops failed messages. Blufio preserves them for inspection and manual retry.

### Crash Recovery

On startup, any items stuck in `processing` state with a `worker_id` not matching the current process are reset to `pending`. No messages are lost due to process crashes. The worker ID is a UUID generated fresh on each process start, ensuring stale claims from previous runs are always detected.

### Overflow Handling

When a session accumulates more pending messages than the cap (default: 20):

- **`summarize`** (default) — Oldest messages are summarized via a lightweight LLM call, then replaced with the summary
- **`drop_oldest`** — Remove oldest pending messages
- **`drop_newest`** — Reject new messages at cap

> **Caveat:** The `summarize` strategy triggers an LLM API call during overflow — exactly when load is highest. This adds both cost and latency under pressure. For high-throughput scenarios, prefer `drop_oldest` to avoid cascading LLM calls. Monitor queue overflow events via the `blufio_queue_overflow_total` Prometheus counter and adjust the cap or strategy accordingly.

### Inbound Stream Backpressure

The `inbound_stream` uses a bounded channel (`tokio::sync::mpsc` with capacity 256). When the agent is slow processing, the channel applies backpressure — channel adapters pause polling/accepting new messages until the buffer drains. This prevents unbounded memory growth from message queuing. The buffer size is configurable via `[gateway.inbound_buffer_size]`.

### Backpressure

When queue depth exceeds a threshold (default: 50 pending), the system signals channels to slow down: HTTP 429 with `Retry-After` for webhooks, auto-reply for user-facing channels.

### Typing Indicators

Typing indicators fire **immediately on enqueue**, not when the run starts. This maintains perceived responsiveness even when the message is waiting in queue.

---

## 2.11 Performance Targets

> **Note:** All targets below are projections based on architectural analysis and Rust ecosystem benchmarks. They have not been validated against a running Blufio implementation. Actual numbers will be confirmed during Phase 1 benchmarking.

### Latency

| Metric | Target | Notes |
|--------|--------|-------|
| Cold start (binary ready) | 2–5 seconds | Includes SQLite open, channel connections, TLS setup, optional embedding model load |
| Per-turn overhead (excl. LLM) | 5–20ms | Context assembly + queue ops + serialization |
| Session load from SQLite | 1–5ms | Indexed by session key |
| Context assembly | 2–5ms | Three-zone prompt construction |
| Queue enqueue | ~50μs | SQLite INSERT; ~50× slower than in-memory but negligible vs LLM latency |
| Queue dequeue (atomic) | ~80μs | SQLite UPDATE...RETURNING |

**Key insight**: Queue operations are 50–80× slower than in-memory, but this overhead (~100μs) is completely invisible against LLM API latency (1–30 seconds). The trade-off buys crash durability and ACID guarantees.

### Memory

| Metric | Target |
|--------|--------|
| Idle memory (including embedding model) | 50–80 MB |
| Per active session | ~2–5 MB |
| Memory bound | Configurable cap (default: 512 MB) |

Memory growth is **bounded** — not flat. It scales with active sessions, caches, and loaded context. Memory pressure is managed at four levels:

- **None** (<70% budget): Normal operation
- **Low** (70–85%): Evict cold caches
- **Medium** (85–95%): Clear all caches, close idle sessions
- **High** (>95%): Reject new sessions, alert operator

### Throughput

| Metric | Target | Notes |
|--------|--------|-------|
| Queue throughput (synthetic benchmark) | ~15,000 msg/sec | SQLite enqueue/dequeue cycle. While impressive, the practical bottleneck is LLM API latency (1–5s per turn), not local queue throughput. This metric confirms the queue is never the bottleneck. |
| Concurrent sessions | 10–50 | Practical limit is provider API rate limits, not local compute. Memory scales at ~2–5 MB per active session. On a 2 vCPU / 2 GB machine, budget ~30 active sessions comfortably. |
| Tool execution | Parallel via JoinSet | 40–70% latency reduction vs sequential |

### Scalability Tiers

| Sessions | Hardware | Notes |
|----------|----------|-------|
| 1–30 | 2 vCPU, 2 GB RAM ($12/mo droplet) | Default config, no tuning |
| 30–100 | 4 vCPU, 4 GB RAM | Tune memory budget, increase workers |
| 100–500 | 8 vCPU, 8 GB RAM + Litestream backup | Read-heavy workloads benefit from Litestream snapshots |
| 500+ | Sharded multi-node | Requires architectural extensions (separate design doc) |

### Prompt Cache Economics

| Scenario | Expected Hit Rate |
|----------|------------------|
| Consecutive turns (same session, <5 min apart) | ~85–90% |
| After idle gap (>5 min, cache cold) | ~0% first turn, then ~85% |
| Cross-session (different users, shared stable prefix) | ~70–80% |
| After config change (prefix invalidated) | ~0% first turn |

**Estimated savings**: For 1000 turns/day at 25K cached tokens per turn with ~80% effective hit rate, cache alignment saves ~$80–100/month in provider costs. Actual savings vary with conversation patterns and idle time distribution.

### High Availability (via Litestream)

| Metric | Target |
|--------|--------|
| RPO (Recovery Point Objective) | ~1 second |
| RTO (Recovery Time Objective) | 10–30 seconds |
| Replication mechanism | Litestream → S3 (continuous WAL streaming) |

> **Note:** Litestream provides continuous backup replication, not live read replicas. The replicated database is for disaster recovery — you restore it on a new machine if the primary fails. It cannot be queried concurrently while the primary is running.

---

## 2.12 Node Capabilities

Nodes declare capabilities during the pairing handshake. The following capabilities are recognized:

| Capability | Description | Phase |
|------------|-------------|-------|
| `exec` | Execute shell commands on the node | Phase 1 |
| `camera` | Capture photos/video from node cameras | Phase 1 |
| `screen` | Screen capture and recording | Phase 1 |
| `location` | GPS/location services | Phase 1 |
| `notify` | Push notifications to the node | Phase 1 |
| `canvas` | Render and display visual content (HTML/web views) | Phase 4 |

The `canvas` capability allows nodes to render and display visual content (HTML/web views) on paired devices. Use cases: displaying dashboards, presenting results, rendering diagrams on a tablet or smart display. The node streams canvas content via the WebSocket protocol. Phase 4 feature.

---

## 2.13 Memory Eviction (Temporal Decay Threshold)

Memories with decay score below 0.05 are eligible for automatic eviction during the daily maintenance window — they no longer occupy search index space. This prevents near-zero-weight memories from clogging search results. The threshold is configurable: `[memory.eviction_decay_threshold] = 0.05`. Evicted memories are moved to the archive (subject to the archive row cap).

---

*Section 2 of the Blufio PRD. Version 2.0 — 2026-02-28.*
