# Blufio PRD Changelog

All notable changes to the Blufio Product Requirements Document.

## [2.0] - 2026-02-28

### Architectural Overhaul — Plugin Architecture + Progressive Disclosure

#### 1. Everything Is a Plugin
Core binary is thin. Channels, providers, storage, embedding, auth, observability, and PII detection are all adapter plugins. New `blufio-plugin-host` crate. Plugin loading via `libloading` with crash isolation. `blufio plugin list|search|install|remove|update`. Docker variants: minimal (~25MB), standard (~40MB), full (~55MB). AGPL/Signal isolation via plugin boundary. Phase 1 built-in; plugin host ships Phase 2.

#### 2. Progressive Skill Disclosure (Claude Code Pattern)
Skills inject names + descriptions only (~500 tokens for 50 skills). Agent reads full SKILL.md on demand via file-read tool. 94-99.5% token savings vs full injection. Skill `description` in `skill.toml` is the primary discovery surface.

#### Additional
- Core binary ~25MB minimal, ~50MB with all plugins
- Plugin development scaffolding: `blufio plugin init`
- Adapter traits: ChannelAdapter, ProviderAdapter, StorageAdapter, EmbeddingAdapter, ObservabilityAdapter, AuthAdapter
- Air-gapped bundles include selected plugins
- Config recipes include plugin installation

---

## [1.9] - 2026-02-28

### Jinx Round 3 — 3 Points: Ship It

#### The Point
Stop polishing the PRD. Start writing code.

#### Changes
- **Killer feature defined (README line 1):** "A personal AI agent that runs forever on a $4 VPS without crashing, leaking memory, or draining your wallet." Added Section 0 with honest "why switch / why NOT switch" framing.
- **Phase 1 ruthlessly cut:** Split into 1a/1b/1c. Phase 1a ("It talks") is 4 weeks funded / 2 months volunteer: Telegram + Anthropic + SQLite + `blufio serve`. No WASM, no skills, no MCP, no multi-model, no observability dashboard. Ship the demo.
- **Governance deferred:** GOVERNANCE.md, RFC/ADR processes, CODEOWNERS, community calls, mentorship programs — all moved to "after Phase 1 ships and actual contributors exist." Day 1 infrastructure reduced to: SECURITY.md, CONTRIBUTING.md, CODE_OF_CONDUCT.md, cargo-deny, cargo-audit, DCO, good first issues.

---

## [1.8] - 2026-02-28

### Pixie Round 2 — 35 Points: Realistic Projections, Phase 1 Split, Contradictions Fixed

#### 🔴 Critical
- **Volunteer pace is PRIMARY timeline** — 36-48 months is the default, funded (18-24mo) is the alternative
- **Skill shim moved to Phase 2** — `blufio-openclaw-shim` was Phase 4, now Phase 2 (biggest adoption blocker)
- **WASM vs Script tier reconciled** — registry requires WASM, local skills may use Script; honest tradeoff documented
- **Phase 1 split** — Phase 1a (MVP: binary+Telegram+Anthropic+CLI) and Phase 1b (hardening: systemd, SQLCipher, backup)

#### 🟠 Significant
- **MCP added to Phase 1 checklist** — resolved contradiction (claimed Phase 1 but missing from checklist)
- **Token comparison honesty** — "68-84% reduction" with optimized OpenClaw column added
- **Cache hit rate realistic** — changed from 85% to 50-65% typical, 55% base case; cost recalculated ~$130-145/mo
- **Cold start reframed** — not a differentiator, advantage is steady-state resources
- **expect() vs clippy contradiction fixed** — deny(unwrap), allow(expect) with descriptive messages
- **Hook timeout standardized** — 30 seconds everywhere (was 5s in one place, 30s in another)
- **Binary size consistent** — 40-50MB everywhere (was 22MB in ls output, 40-60MB in text)
- **Embedding download moved to `blufio setup`** — no surprise download on first `serve`

#### 🟡 Moderate
- **PII detection internationalized** — EU patterns (personnummer, IBAN, EU phones) from Phase 1
- **Argon2id adaptive for Pi** — 32MB m_cost on <2GB RAM devices
- **Compaction scores tool_action** — tool invocations survive compaction
- **max_blocking_threads** — increased from 2 to min(parallelism, 4)
- **Event bus 4096 justified** — 500 events/sec peak, 8s headroom, configurable
- **Model deprecation mid-conversation** — graceful cache invalidation, temporary cost spike
- **Skill tier decision tree** — "which tier should I use?" guide for contributors
- **Skill dev hot-reload** — `blufio skill dev <path>` for iterative development
- **IoT/Pi config recipe** — optimized for <512MB RAM
- **Log sampling** — 10% for non-critical events at 50+ sessions
- **RFC vs ADR decision matrix** — user-facing = RFC, internal = ADR
- **Vault key loss recovery** — `vault export-key --encrypted`, no escrow by design
- **Windows CI** — Phase 2, WSL2 recommended for development

#### 🟢 Minor/Polish
- **Backup includes observability.db** — cost history no longer lost
- **blufio uninstall in CLI index** — was missing from top-level commands
- **db subcommands listed** — migrate, backup, restore, inspect, export
- **Docker HEALTHCHECK explanation** — exec form works without shell in FROM scratch
- **WebTransport/HTTP3 flagged** — future consideration
- **ROADMAP.md** — 1-2 page overview for contributors
- **Public chat in README** — Discord/Matrix link in first section
- **GOVERNANCE.md** — BDFL, core maintainer criteria, promotion path
- **Benchmark hardware** — GitHub Actions 4 vCPU/16GB baseline
- **Pricing validation --live** — checks against provider APIs
- **DCO waiver** — single-commit casual PRs exempt
- **Community-reviewed default** — for skill registry at volunteer pace
- **LaTeX capability justified** — single bool, Telegram math rendering
- **Skill registry community-reviewed as default path**
- **Dual timeline table updated** — Phase 1a/1b split reflected

---

## [1.7] - 2026-02-28

### Loonie Round 2 — 36 Points: Licensing, Vision, Sustainability, Skill DX, Timelines

#### 🪪 Licensing & Legal
- **Dual MIT + Apache-2.0 from first commit** — patent protection for enterprise contributors, avoids retroactive licensing mess
- **AGPL_BOUNDARY.md** — root-level file with diagram + CI lint script
- **Employer authorization template** — real file at `docs/employer-authorization-template.md`
- **WhatsApp adapter** — marked maintainer-only due to Meta business verification requirement

#### 💰 Funding & Sustainability
- **Volunteer pace is the lead timeline** — prominent in README and contributor onboarding, not buried in risks
- **Sponsorship tiers post-alpha** — no selling roadmap input before code exists
- **Sustainability cliff plan** — BDFL decides scope cuts with 30-day public notice; reduced core defined
- **Bug bounty simplified** — responsible disclosure + credit/swag only until real funding exists
- **Blufio Cloud value prop defined** — operational convenience, 100% feature parity with self-hosted

#### 🏗️ Architecture
- **IPv6 dual-stack** — `[::]:18789` support, default remains IPv4 localhost
- **WebSocket permessage-deflate** — 60-80% bandwidth reduction for mobile/high-throughput
- **SQLite → PostgreSQL upgrade path** — `blufio db export --format pg-dump`, Phase 4 StorageBackend trait
- **Temporal decay eviction** — auto-evict memories at decay <0.05, configurable threshold
- **Canvas node capability defined** — HTML/web rendering on paired devices, Phase 4
- **WASM skill hot-reload** — file watcher + signature verify, swap on next invocation, no restart

#### 🔐 Security
- **Prompt injection Phase 1-2 warning** — in quickstart, startup output, and README
- **Vault env var production warning** — loud warning when env var + non-localhost bind
- **Audit witness compliance hard gate** — ERROR not warning in compliance mode, blocks startup

#### 📊 Cost & Memory
- **Cost claim inline assumptions** — "~$91/mo (assumes 85% cache, Haiku heartbeats)" in cell
- **External API cost tracking** — `external_api` category with `blufio costs report`
- **Cost diagnostics** — `blufio doctor --check costs` validates ledger integrity

#### 👥 Community & Ecosystem
- **Channel adapter contribution guide** — 6-section walkthrough with Matrix worked example
- **Skill author end-to-end tutorial** — init → test → sign → publish in ~30 minutes
- **Skill SDK breaking changes flow** — 2-minor deprecation window, `skill check` migration hints
- **Skill registry volunteer pace honesty** — aspirational SLA, community-reviewed status, transparent wait times
- **ARM32 prominent warning** — ⚠️ callout on download page for Pi 3 keyword-only search

#### 📝 Documentation & UX
- **Dual timeline roadmap table** — funded vs volunteer pace side-by-side
- **Embedding download in quickstart** — before first `blufio serve` command
- **Rollback backup retention** — 3 backups, `rollback --to <version>`
- **Uninstall levels** — basic / --include-data / --purge with confirmation
- **Air-gapped docs** — `blufio docs serve` from bundled mdBook HTML
- **OpenClaw workspace file migration** — SOUL.md, AGENTS.md, HEARTBEAT.md, etc.
- **Good first issue checklist** — 10+ issues with examples before first public commit

#### 🎯 Product Strategy
- **"What Blufio Enables" section** — 5 structural advantages, not "OpenClaw but better"
- **OpenClaw contingency strengthened** — 4 architectural differentiators that can't be incrementally added to Node.js

---

## [1.6] - 2026-02-28

### Crusher Round 2 — 35 Points: Security Disclosure, Skill Migration, MCP Spec, OSS Infra

#### 🔴 Critical
- **SECURITY.md:** Ships day 1 with security@blufio.dev, 72h acknowledgment SLA, 90-day disclosure window
- **OpenClaw skill migration:** `blufio-openclaw-shim` wraps JS skills via Node.js subprocess (Phase 4). Migration guide with porting tutorial. Biggest adoption blocker acknowledged.
- **Pricing override:** `~/.blufio/pricing.toml` for operator-managed pricing without binary upgrade
- **MCP client spec:** Transports (stdio/SSE/HTTP), tool injection into context engine, per-server auth, Phase 1 scope defined
- **Binary attribution:** `blufio --licenses`, auto-generated NOTICE.txt via cargo-about in every distribution

#### 🟡 Significant
- **Release cadence:** 6-8 week minors, 72h security patches, supported window (current + previous minor)
- **Multilingual embedding:** `paraphrase-multilingual-MiniLM-L12-v2` recommended for non-English, install script auto-selects
- **Embedding download opt-out:** `--no-embedding`, `BLUFIO_SKIP_MODEL_DOWNLOAD`, air-gapped bundle
- **Commit convention:** Conventional Commits, commitlint in CI, git-cliff changelog generation
- **Skill review SLA:** 1h automated, 5 business days manual. 12-month unmaintained flag. Adoption process for orphaned skills.
- **FDE detection:** Linux dm-crypt/LUKS + macOS fdesetup, best-effort with manual fallback
- **NO_COLOR:** Standard support, --color always|auto|never, screen-reader compatible
- **Migration rollback:** 3 migrations (up from 2), backup enforcement before migrate

#### 🟠 Architecture
- **Per-session key threat model:** Clarified use case (export/migration/untrusted backup), doctor warns without SQLCipher
- **tool_calls index:** `tool_names TEXT` column with covering index for efficient tool usage queries
- **Context branch handling:** Session resets create compaction boundary, sub-agent parent references, stale tool annotations
- **Heartbeat dirty bit:** In-memory flag replaces SQLite query for O(1) pre-check
- **Worker thread cgroup auto-detect:** Install script reads cgroup CPU limits, sets BLUFIO_WORKER_THREADS
- **Skill registry CDN:** Cloudflare R2/B2, per-IP rate limits, local mirror support

#### 🟢 OSS Infrastructure
- **Dual licensing considered:** MIT-only for now, Apache-2.0 addition based on enterprise feedback
- **Telemetry privacy:** Privacy policy URL, `telemetry status` command, dry-run mode, configurable endpoint for forks
- **CODEOWNERS:** Security team owns sandbox/vault, channel maintainers own adapters
- **Community health files:** .github/ with SECURITY.md, FUNDING.yml, SUPPORT.md, YAML issue forms
- **ADR template:** docs/adr/NNNN-title.md with status/context/decision/consequences
- **Signed git tags:** GPG-signed by maintainers, CI verifies before building
- **Changelog format:** Keep a Changelog via git-cliff from Conventional Commits
- **cargo install blufio:** Phase 1 + flake.nix for Nix users

#### ⚪ Polish
- **Config recipes specified:** personal vs team vs production differences documented
- **Cold start:** Fixed "<2-5 seconds" → "2–5 seconds"
- **Benchmark output:** p50/p95/p99, hardware tier baselines, JSON/markdown formats
- **External attachment encryption:** AES-256-GCM with HKDF-derived key
- **RUSTSEC response SLA:** Critical 24h patch/48h release, High 72h/1wk
- **Browser extension:** Post-v1.0 roadmap item
- **OpenClaw skill migration guide:** Explicit "skills not auto-migrated" with porting tutorial

---

## [1.5] - 2026-02-28

### Jinx Round 2 — ~55 Points: Security Hardening, Protocol Specs, GDPR, Architecture

#### 🔴 Critical Security
- **Vault key default:** tmpfs/Docker secrets/LoadCredentialEncrypted is now the default. Env var requires explicit opt-in + `blufio doctor` critical warning
- **SQLCipher CBC vs GCM:** Acknowledged cryptographic gap between vault (GCM) and database (CBC+HMAC). Documented alternatives.
- **GDPR international transfer:** Guide for EU operators on SCCs, zero-retention tiers, DPA links. `blufio privacy forget` logs which providers received data.
- **API versioning:** `/v1/` is stable contract. Breaking changes = new prefix. `Sunset` header for deprecation (6mo notice). Changelog at `/v1/changelog`.
- **Install script:** Minisign key published in multiple independent sources. GPG apt repo + Homebrew in Phase 2. curl|sh documented as least-secure method.
- **Database migration versioning:** Sequential numbering, `schema_version` table, compatibility matrix, irreversible migration warnings.
- **Docker:** Non-root user (65534), debug image from distroless, published alongside production.

#### 🟡 Architecture
- **Inbound stream backpressure:** Bounded `mpsc` channel (256), adapters pause when full.
- **OutboundMessage struct:** Fully defined with session_id, channel, content, reply_to, format_hints.
- **WebSocket protocol spec:** Ping/pong, reconnection with backoff+jitter, message ordering via sequence numbers, backpressure, binary format opt-in.
- **Provider circuit breaker:** 3 failures/60s → open → fallback chain → half-open probe after 30s.
- **Config hot-reload scope:** Explicit list of hot-reload-safe vs restart-required keys. `blufio config diff` shows pending.
- **Event bus:** Bounded broadcast (4096), `Lagged(n)` recovery from SQLite event log, dedicated channel for critical events.
- **Memory reindex:** Dual index with atomic swap, no search downtime during model switch.

#### 🟡 Security Improvements
- **Hook sandboxing:** Separate user (`blufio-hooks`), RLIMIT_CPU/AS, `unshare` namespace, no network by default.
- **Management API auth:** Bearer token with `admin.*` scope, rate limited, 127.0.0.1 enforced by default.
- **Vault forward secrecy:** Key versioning, `vault rekey --reencrypt-all`, old key destruction.
- **Audit witness required:** Default `syslog`, `blufio doctor` warns if none configured.
- **Skill signing PKI:** Embedded root key → registry counter-signs author keys. Lightweight trust chain.
- **Revocation list signed:** Ed25519 signature on static file, unsigned lists rejected.
- **WASM network:** TLS required, wildcard expansion validated, private IPs blocked.
- **Native plugin hashes:** SHA-256 verification required, no auto-loading.

#### 🟡 Gaps Filled
- **IRC 512-byte handling:** Sentence-boundary splitting, rate limiting, truncation with /full retrieval.
- **Cost anomaly triple-threshold:** Relative (3× avg) + absolute (hard cap) + trend (3-week increase).
- **SOC 2 renamed:** `evidence-report`, explicit disclaimer it's not a compliance certification.
- **Webhook dead letter:** Max 5 retries, dead-letter table, manual retry CLI.
- **Shadow mode simplified:** `blufio serve --shadow` with same token via long-polling, 10-min setup.
- **`blufio uninstall`:** Removes units/user/config/logs, data only with `--include-data`.
- **OpenAPI spec Phase 1:** Generated from route definitions via utoipa, published at `/v1/openapi.json`.
- **Batch API errors:** Partial-success semantics with per-item status.
- **Benchmark dashboard:** Published to GitHub Pages on every release tag.
- **DAG section reduced:** Removed full TOML config, 3 lines only.

#### ⚪ Memory & Context Fixes
- **Archive cap clarified:** Raw messages = recovery, summaries = permanent. Cap applies to archive only.
- **LRU eviction:** Importance-weighted (0.6 recency + 0.4 importance), `@pin` exempt.
- **Relevance classifier safety net:** Auto-includes falsely excluded blocks on next turn.
- **Temporal decay:** Important memories (≥1.5) use 0.99 decay vs 0.95. `@pin` = zero decay.
- **DPIA template contents:** 5-section structured report with disclaimer.
- **PII redaction logging:** Audit trail entries (pattern type, no actual PII).
- **Tiktoken mismatch:** Per-provider tokenizer override, 10% safety margin.
- **SSD deletion:** Recommends FDE, `blufio doctor` checks encryption.
- **PII US-centric gap:** Nordic/EU pattern packs in Phase 2.

---

## [1.4] - 2026-02-28

### Pixie Review — 25 Points: MCP, Funding, Testing, DX, Ecosystem

#### 🔴 Critical
- **MCP client → Phase 1:** MCP is table stakes in 2026. Basic client support (connect to MCP tool servers) ships Phase 1. Server mode Phase 3.
- **Funding realism:** Three tiers — volunteer pace (36-48mo), seed funded (24-30mo), fully funded (18-24mo). Honest about MIT + sponsorship rarely working.
- **Timeline:** Volunteer-pace variant (36-48mo) added alongside funded timeline. Scope reduction plan if unfunded after 12 months.
- **Contributor onboarding:** Good-first-issue labels, ADRs, monthly community calls, mentorship pairing, #contributors channel.
- **Binary size:** Standardized to 40-60 MB everywhere. Removed all 15-30MB contradictions.

#### 🟡 Significant
- **Script tier for Python/TS:** First-class path with `blufio skill init --lang python/typescript`, JSON-RPC protocol, scaffolding, 5+ examples in Phase 2.
- **Embedding model abstraction:** `EmbeddingProvider` trait, swappable models via config (e5-small, GTE, nomic, remote APIs), `blufio memory reindex`.
- **Structured output / JSON mode:** Provider-specific normalization (Anthropic tool_use workaround, OpenAI native, Google response_mime_type).
- **Testing strategy:** proptest, cargo-fuzz, chaos testing, k6 load testing, snapshot testing — all tagged and independently runnable.
- **i18n/accessibility:** English-only acknowledged as limitation, community localization welcome.
- **SQLite write contention:** Write batching, WAL checkpointing, async flush for non-critical writes, PostgreSQL escalation path Phase 4.
- **Opt-in telemetry:** Anonymous usage data (version, OS, channel count, session bucket), quarterly transparency report, disabled by default.
- **Heartbeat race condition:** Event-driven wake mechanism supplements polling.
- **Model deprecation:** Alias resolution, deprecation detection via provider headers, automatic fallback.
- **Hook data minimization:** Hooks declare required data fields, runtime strips undeclared, `data = ['*']` requires opt-in.

#### 🟢 Minor/Polish
- **`blufio shell` REPL:** Interactive debugging connected to running daemon, tab completion, command history.
- **Migration templates:** OpenClaw, LangChain, AutoGPT, Botpress templates.
- **Rate limit coordination:** local/file/redis backends for multi-instance deployments.
- **Comparison tone softened:** Factual differences, no value judgments.
- **WASM Component Model:** WASI P2 planned Phase 4, SDK aligned for migration.
- **Per-subsystem log levels:** BLUFIO_LOG env var with EnvFilter syntax.
- **Air-gapped deployment:** `blufio bundle` creates ~120MB self-contained package.
- **Archive clarification:** L1-L3 summaries stay in active table, only raw messages archived.
- **Embedding load failure:** Degrades to BM25 keyword-only search, `blufio doctor` flags it.
- **PRD version numbering clarified:** PRD revisions ≠ product versions (product starts at 0.1.0).

---

## [1.3] - 2026-02-28

### Loonie Review — Governance, Funding, Architecture Decisions, DX

#### Open Source / MIT License
- **Concrete governance:** GOVERNANCE.md with maintainer responsibilities, merge policy, conflict resolution, new maintainer election
- **Registry strategy:** Why use the official registry vs raw GitHub (verified sigs, scanning, compat testing, convenience)
- **DCO employer policy:** Template letter for employer authorization when contributors can't sign-off
- **AGPL contributor guidance:** NOTICE file at repo root, dedicated CONTRIBUTING.md section for Signal, CI lint enforcing AGPL boundary
- **Competitive framing:** Positioned as "next-generation alternative," not hostile fork

#### Architecture Decisions (Firm)
- **Cargo workspace from day 1:** 6 crates defined (blufio-core, gateway, channels, sandbox, cli, sdk). No more "evaluate splitting later"
- **SQLite queue FULL by default:** `command_queue` uses `synchronous = FULL`. Not "consider" — firm recommendation
- **Embedding model checksum:** Real pinning with SHA-256 verified on download, refuse to start on mismatch
- **cgroup-aware workers:** Documented that `available_parallelism()` can be misleading on shared VPS, explicit override guidance
- **SSRF scope clarified:** Applies to skill HTTP requests via capability broker, NOT to exec output parsing. Removed overclaim.

#### Funding & Sustainability (Concrete)
- **$300-500K/year target** stated explicitly for 2-3 devs
- **Sponsor tiers with prices:** Bronze $500/mo, Silver $2K/mo, Gold $5K/mo
- **Revenue paths ranked:** Corporate sponsors → Blufio Cloud → Premium skills marketplace → Certification → Community funding
- **Bug bounty gated:** Activates when reserve fund exceeds $50K

#### Scope / Roadmap
- **MCP client → Phase 3** (was post-v1.0). Ecosystem won't wait.
- **Quarterly milestones:** Q1-Q4 Year 1 + Q1-Q4 Year 2 checkpoints
- **Public GitHub Project board** as canonical roadmap tracker
- **Shadow mode fully specified:** Separate bot token, proxy script, comparison log, `blufio migrate compare`
- **Windows tracking issue:** 4 blockers documented, `#[cfg]` gates from day 1
- **Public beta at Phase 2 conclusion** with dedicated feedback channel

#### Security
- **Hook security prominent:** 0750 log permissions, dedicated operator docs page, `blufio doctor` checks
- **Vault rotate --all safety:** Interactive confirmation required ("Type ROTATE-ALL to confirm")
- **Prompt injection Phase 1-2 warning:** Prominent notice that only L1-L2 defenses ship initially
- **Skill revocation → Phase 3:** Static hosted file ships with registry, not deferred to Phase 4

#### Developer Experience
- **`blufio doctor --format json`** for CI/CD integration
- **`blufio db inspect`** added to CLI reference (MessagePack decoding)
- **Auto-generated config reference** as Phase 1 deliverable
- **Integration test infrastructure:** Mock channel servers, in-memory SQLite harness, cost tracking validation
- **Recruitment risk** acknowledged in Risks section

---

## [1.2] - 2026-02-28

### 25-Point Review Applied (Reviewer: Crusher)

#### 🔴 Critical
- **License compatibility audit:** Added systematic dependency license review, cargo-deny CI gate, SQLCipher/OpenSSL attribution, AGPL build isolation details (workspace exclusion, feature-flag gate, separate crates.io publication)
- **Funding & sustainability model:** GitHub Sponsors, Open Collective, corporate tiers, paid support — bug bounty contingent on funding
- **AGPL isolation completed:** blufio-signal excluded from workspace.members, cargo build --all-features cannot link AGPL code

#### 🟡 Significant Gaps Filled
- **OSS developer infrastructure:** CONTRIBUTING.md, CODE_OF_CONDUCT.md, DCO, issue templates, cargo-audit, Dependabot — ships Phase 1
- **Reproducible builds:** cargo-auditable, SLSA Level 2 provenance, SBOM (CycloneDX), Sigstore/cosign
- **CI/CD pipeline:** Full GitHub Actions spec (build, test, clippy, cargo-deny, cross-compile, sign, release, Docker push)
- **Windows:** Documented as non-target with WSL2 recommendation
- **ARM32:** Candle SIMD unverified — ARM32 builds ship without local embeddings, remote API only

#### 🟠 Architectural
- **Wire protocol versioning:** protocol_version field in Auth frame, version negotiation in AuthOk
- **Nonce cache auto-sizing:** Based on max_age × estimated_throughput (was fixed 10K)
- **Zone 1 token budget:** 3K → 5-8K with configurable overflow to Zone 2
- **Tool fallback cost:** Extra round-trip (~500-1,500 tokens) included in cost projections
- **Prometheus cache metrics:** blufio_cache_hit_total, blufio_cache_miss_total, blufio_cache_hit_rate, blufio_cache_write_bytes_total — primary validation metric for cost thesis
- **Compaction archive bounded:** Row cap per session (default 100K) + 90-day TTL

#### 🟢 Ecosystem & Community
- **Skill registry license policy:** Mandatory license declaration, AGPL warning, configurable allowed_licenses
- **Skill namespace squatting:** @author/skill-name format, verified authors, reserved names
- **Plugin SDK publication:** crates.io with semver compat guarantee (2 minor versions), MSRV policy
- **RFC process:** docs/rfcs/ in repo, GitHub PR discussion, 14-day bot-enforced comment period
- **Documentation site:** docs.rs for API, mdBook for operator docs at docs.blufio.dev

#### ⚪ Polish
- **Token rotation CLI:** blufio auth rotate-token with graceful restart
- **migrate preview --format json:** Machine-readable output for CI/CD
- **Heartbeat error handling:** Differentiates API-returned-zero from API-unreachable
- **Multi-instance memory warning:** Prominent callout (3-5 × 80MB model)
- **OpenAI API tool streaming:** stream_options.include_usage + tool call deltas
- **Audit log sealing spec:** SHA-256 hash chain, external witness, verify command

---

## [1.1] - 2026-02-28

### Major Revision — 95-Point Critical Review Applied

Reviewer: Jinx (Devil's Advocate QA). Every section revised for honesty, consistency, and implementability.

#### Corrected Numbers (across all docs)
- **Idle memory:** 20-30MB → 50-80MB (embedding model weights alone are ~80MB)
- **Binary size:** 15-25MB → 40-60MB (wasmtime ~15MB + Candle + SQLite + adapters)
- **Startup time:** <100ms → <2-5 seconds (SQLCipher KDF + model load + channel TLS)
- **Concurrent sessions:** 100+ → 10-50 (bottleneck is provider API rate limits, not local compute)
- **node_modules comparison:** 500MB+ → ~150-200MB (accurate competitor numbers)
- **Dependencies:** <50 crates → <80 direct dependencies
- **Token reduction:** 70-84% → ~50-70% with honest baseline caveats
- **Docker image:** ~20MB → ~50-70MB

#### Timeline (doc 05)
- **9 months → 18-24 months** for 2-3 developers
- Phase 1: 3-4 months (was 2). Core gateway + Telegram + Anthropic + CLI + systemd
- Phase 2: months 5-8. Memory + compaction + vault + cron + cost tracking
- Phase 3: months 9-13. Discord + HTTP API + WASM sandbox + providers
- Phase 4: months 14-18. Nodes + migration + additional channels
- Phase 5: months 19-24. Polish, community, skill registry, docs
- Solo dev extends each phase by ~50%

#### License Fix (doc 04)
- **presage (Signal) is AGPL-3.0** — incompatible with MIT core. Signal support moved to separate optional binary (`blufio-signal`) or via Matrix bridge

#### Channels (doc 04)
- **12 at launch → phased:** Telegram Phase 1, Discord Phase 3, rest incremental post-v1.0
- New adapter estimate: ~1-2 weeks, ~500-1500 lines (was 2 days, 500 lines)
- WhatsApp: added Meta business verification requirement
- iMessage: noted Mac + BlueBubbles hardware requirement
- Bug bounty / Security Response Team: marked aspirational pending funding

#### Security & Compliance (doc 03)
- Vault key in env var: acknowledged limitation, recommended external secret managers for production
- HIPAA CLI: "Does NOT constitute HIPAA compliance" — generates evidence report only
- SOC 2 CLI: same — evidence report, not compliance
- EU AI Act: "starting point, additional organizational measures required"
- Native plugins: explicit ⚠️ warning — full process privileges, bypasses all sandboxing
- Ed25519 key revocation: added local revocation list mechanism
- Prompt injection: L1-L2 ship Phase 1, L3-L5 are Phase 3+

#### Memory & Context (doc 03)
- Contradiction detection: removed (unsolved NLP problem). Replaced with duplicate flagging via cosine similarity
- Search weights: fixed to sum to 1.0 (added w_recency=0.15)
- Self-tuning classifier: added specifics (decay rate, floor, overrides)
- Compaction NER: honest about regex+heuristics, not full NER
- Cache hit rate: removed unverifiable OpenClaw baseline; target within warm TTL only
- PII rehydration: mapping held in memory only, never persisted
- WASM I/O performance: compute ~1.5× native, I/O-heavy 3-5×

#### Architecture (doc 02)
- Worker threads: configurable via `available_parallelism()`, not hardcoded 4
- SQLite synchronous NORMAL: caveat about power-loss durability, FULL recommended for queue
- Queue overflow summarization: caveat about cascading LLM costs under load
- Broadcast groups: added response deduplication via first-responder claim
- Attachments: >1MB external storage, BLOB for thumbnails only
- Bearer tokens: added rotation mechanism, future expiry plans
- Prompt cache: honest about provider TTL (5 min), cold after idle gaps

#### Vision (doc 01)
- Cost comparisons: caveats about worst-case-OpenClaw vs best-case-Blufio rigging
- Added Section 9: Risks & Assumptions (Rust dev speed, timeline, scope, moving target)
- Added Section 10: Scope Limitations (explicit v1.0 exclusions)
- Competitive positioning: acknowledges some advantages could be incrementally fixed in OpenClaw
- CVE target: "minimize exposure" posture instead of "0 CVEs" prayer

#### Deployment (doc 05)
- Litestream: corrected from "read replicas" to "backup replication for disaster recovery"
- DAG workflow: marked v2.0 aspirational, not Phase 1
- OpenAI API: core parameters only, full parity is non-goal
- `curl|sh`: Minisign signature verification, not just checksum
- `/v1/tools/invoke`: exec excluded by default, requires explicit opt-in
- Docker: added `blufio:debug` distroless image for troubleshooting

---

## [1.0] - 2026-02-28

### Initial Release

- 5 sections + index synthesized from 48 architecture research documents (~57K lines)
- Covers: vision, core architecture, memory/context/security, channels/skills/observability, deployment/automation/API
- Total: ~5,400 lines, ~204 KB
- Archived in `versions/v1.0/`
