# Blufio PRD — Document Index

> **v2.0** — Plugin architecture + progressive disclosure. Everything is a plugin: channels, providers, storage, embedding, auth, observability. Skills use Claude Code-style progressive disclosure. See CHANGELOG.md.

**Product:** Blufio — Rust + Shell AI Agent Platform  
**Version:** 2.0  
**Date:** 2026-02-28

## Documents

| Document | Description | Primary Audience |
|----------|-------------|-----------------|
| [01 — Vision & Overview](./01-vision-and-overview.md) | Problem statement, design principles, competitive positioning, risks, scope limitations | Everyone — start here |
| [02 — Core Architecture](./02-core-architecture.md) | Gateway, agent loop, sessions, multi-agent routing, command queue, performance targets | Engineering |
| [03 — Memory, Context & Security](./03-memory-context-security.md) | Memory system, context engine, credential vault, WASM sandbox, privacy, compliance | Engineering + Security |
| [04 — Channels, Skills & Observability](./04-channels-skills-observability.md) | Channel adapters, plugin system, providers, cost tracking, metrics, error resilience | Engineering + Platform |
| [05 — Deployment, Automation & API](./05-deployment-automation-api.md) | Shell automation, systemd, HTTP API, CLI, migration, node system, roadmap | Engineering + Operations |

## How to Use
- **New to Blufio?** Start with 01 — Vision & Overview
- **Building a feature?** Check the relevant technical section (02-05)
- **Reviewing scope/timeline?** See 05 § Roadmap and 01 § Risks & Assumptions

## Version History
See [CHANGELOG.md](./CHANGELOG.md) for full changelog.

## Versions Archive
Previous versions are preserved in `versions/`. Current version is v1.1.
