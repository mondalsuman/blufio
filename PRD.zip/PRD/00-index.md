# Blufio — Product Requirements Document

> **Product:** Blufio  
> **Type:** Ground-up Rust + Shell AI Agent Platform  
> **Version:** 2.0  
> **Status:** Draft  
> **Date:** 2026-02-28  
> **Author:** Sage (Research & Architecture)

---

## What is Blufio?

Blufio is a next-generation AI agent platform built from scratch in Rust with a shell automation layer. It replaces the Node.js/TypeScript architecture used by platforms like OpenClaw with a single static binary that delivers memory safety, predictable resource usage, secure-by-default operation, and single-binary deployment — all while maintaining the multi-channel, always-on agent capabilities that make these platforms useful.

---

## Document Index

| # | Document | Scope |
|---|----------|-------|
| 00 | [This Index](./00-index.md) | Overview and navigation |
| 01 | [Vision & Overview](./01-vision-and-overview.md) | Executive summary, problem statement, design principles, competitive positioning, risks, scope limitations |
| 02 | [Core Architecture](./02-core-architecture.md) | System architecture, gateway, agent loop, sessions, multi-agent routing, command queue, performance targets |
| 03 | [Memory, Context & Security](./03-memory-context-security.md) | Memory system, context engine, compaction, credential vault, WASM sandboxing, privacy, stability |
| 04 | [Channels, Skills & Observability](./04-channels-skills-observability.md) | Channel adapters, skill/plugin system, provider ecosystem, cost tracking, metrics, error resilience |
| 05 | [Deployment, Automation & API](./05-deployment-automation-api.md) | Shell automation, systemd, HTTP API, CLI, backup, migration, node system, roadmap |

---

## How to Read This PRD

Each document is **self-contained** — all specifications, rationale, and technical details are included inline. No external documents are required.

- **Start with 01** for the "why" — problem statement, vision, risks, and what makes Blufio different.
- **Read 02** for the core technical architecture — how the system is structured and how components interact.
- **Read 03** for the intelligence layer — how memory, context, security, and privacy work.
- **Read 04** for the integration layer — channels, skills, providers, observability.
- **Read 05** for operations — how Blufio is deployed, managed, automated, and migrated to.

---

## Key Numbers at a Glance

> ⚠️ All targets are projections pending real-world benchmarking. Actual numbers will be validated during Phase 1.

| Metric | Target | Notes |
|--------|--------|-------|
| Idle memory | 50–80 MB | Including embedding model weights (~80 MB) |
| Context overhead | ~5–10K tokens/turn | Query-dependent; vs ~35K unoptimized baseline |
| Token reduction | ~50–70% | Relative to injecting all context every turn |
| Binary size | ~40–60 MB static | wasmtime + Candle + SQLite + all adapters |
| Docker image | ~50–70 MB | FROM scratch with embedded deps |
| Startup time | < 2–5 seconds | Cold start incl. model load + channel TLS |
| Concurrent sessions | 10–50 per instance | Limited by provider API rate limits |
| Prompt cache hit rate | 80–90% | Within active conversations (warm cache) |
| Timeline | ~18–24 months | For 2–3 full-time developers |

---

## Version History

| Version | Date | Summary |
|---------|------|---------|
| 1.9 | 2026-02-28 | Jinx round 3: killer feature pitch, Phase 1 ruthlessly cut, governance deferred |
| 2.0 | 2026-02-28 | Plugin architecture + progressive disclosure: everything is a plugin, Claude Code-style skill discovery |
| 1.8 | 2026-02-28 | Pixie round 2: volunteer-first timeline, Phase 1 split, realistic cache/cost, 35 total |
| 1.7 | 2026-02-28 | Loonie round 2: dual licensing, positive vision, volunteer pace, WASM hot-reload, 36 total |
| 1.6 | 2026-02-28 | Crusher round 2: security disclosure, skill migration, MCP spec, attribution, 35 total |
| 1.5 | 2026-02-28 | Jinx round 2: ~55 points — security hardening, protocol specs, GDPR, backpressure, API versioning |
| 1.4 | 2026-02-28 | Pixie review: MCP Phase 1, funding tiers, contributor onboarding, testing strategy, REPL, model abstraction, 20 more |
| 1.3 | 2026-02-28 | Loonie review: governance, funding, workspace, MCP, security, DX |
| 1.2 | 2026-02-28 | 25-point review applied: license audit, funding model, CI/CD, Windows, wire protocol versioning, Prometheus cache metrics, and 20 other improvements. |
| 2.0 | 2026-02-28 | Major revision: 95-point critical review applied. Corrected all inflated claims, reconciled contradictory numbers, realistic timeline (18-24mo), AGPL license fix for Signal, added Risks & Scope Limitations sections. |
| 1.0 | 2026-02-28 | Initial PRD. 5 sections synthesized from 48 architecture research documents. |

See [CHANGELOG.md](./CHANGELOG.md) for full details.
