# Section 4 — Channels, Skills & Observability

> **Blufio** Product Requirements Document — Section 4 of 5
> Version 2.0 | 2026-02-28
> Covers the channel system, plugin/skill architecture, provider ecosystem, cost tracking, observability, error resilience, and community ecosystem.

---

## Table of Contents

1. [Channel System](#1-channel-system)
2. [Channel Adapter Architecture](#2-channel-adapter-architecture)
3. [Skill & Plugin System](#3-skill--plugin-system)
4. [Plugin Hooks](#4-plugin-hooks)
5. [Provider Ecosystem](#5-provider-ecosystem)
6. [Cost & Observability](#6-cost--observability)
7. [Metrics & Tracing](#7-metrics--tracing)
8. [Error Resilience](#8-error-resilience)
9. [Community & Ecosystem](#9-community--ecosystem)

---

## 1. Channel System

### Channel Adapters as Plugins

Every channel adapter is a plugin implementing the `ChannelAdapter` trait. The core binary ships with **only Telegram**. All other channels are installed via:

```bash
blufio plugin install channel-discord
blufio plugin install channel-whatsapp  
blufio plugin install channel-signal
blufio plugin install channel-irc
blufio plugin install channel-slack
blufio plugin install channel-matrix
```

**Why plugins, not built-in?** 
- Binary size: each channel adapter adds 2-5MB. Operators who only use Telegram shouldn't carry Discord's weight.
- Dependencies: WhatsApp requires protobuf, Signal requires presage (AGPL — isolated by plugin boundary), Discord requires gateway API client. These dependencies are isolated per-plugin.
- Update cadence: channel APIs change independently. A Discord API update shouldn't require a Blufio core release.
- AGPL isolation: the Signal adapter (using presage) is a separate plugin binary. The AGPL boundary is now the plugin boundary — no shared library linking, no license contamination. This replaces the previous `blufio-signal` separate binary approach with a cleaner plugin model.

**Channel plugin structure:**
```
~/.blufio/plugins/channel-discord/
├── plugin.toml       # Manifest: name, version, adapter_type = "channel", min_blufio_version
├── libchannel_discord.so  # Shared library implementing ChannelAdapter
└── README.md
```

**Channel discovery:** Installed channel plugins are detected at startup. The gateway logs which channels are active. `blufio plugin list --type channel` shows all installed channel adapters and their status.

### 1.1 Design Philosophy

Blufio treats every messaging platform as a **channel adapter** implementing a unified `Channel` trait. The agent core never touches platform-specific APIs — it operates entirely on normalized message types. Channels declare their capabilities at runtime via a structured `ChannelCapabilities` manifest, enabling the core to automatically adapt formatting, media handling, and interaction patterns without per-platform conditionals.

### 1.2 Unified Channel Trait

```rust
#[async_trait]
pub trait Channel: Send + Sync + 'static {
    /// Unique adapter identifier (e.g., "telegram", "whatsapp-business")
    fn id(&self) -> &str;

    /// Structured capability manifest
    fn capabilities(&self) -> ChannelCapabilities;

    /// Establish connection to the platform
    async fn connect(&mut self) -> Result<(), ChannelError>;

    /// Graceful disconnect
    async fn disconnect(&mut self) -> Result<(), ChannelError>;

    /// Send a normalized outbound message, adapted to channel capabilities
    async fn send(&self, target: &ChatTarget, message: &OutboundMessage) -> Result<MessageId, ChannelError>;

    /// Edit a previously sent message (if supported)
    async fn edit(&self, msg_id: &MessageId, message: &OutboundMessage) -> Result<(), ChannelError>;

    /// Delete a message
    async fn delete(&self, msg_id: &MessageId) -> Result<(), ChannelError>;

    /// React to a message with an emoji
    async fn react(&self, msg_id: &MessageId, emoji: &str) -> Result<(), ChannelError>;

    /// Stream of inbound messages
    fn inbound_stream(&self) -> Pin<Box<dyn Stream<Item = InboundMessage> + Send>>;

    /// Current connection health
    fn health(&self) -> ChannelHealth;
}
```

### 1.3 Message Normalization

All inbound messages are normalized to a common `InboundMessage` struct before reaching the agent:

```rust
pub struct InboundMessage {
    pub platform_message_id: String,
    pub sender: Sender,
    pub conversation_id: String,
    pub content: Vec<ContentBlock>,
    pub reply_to: Option<String>,
    pub timestamp_ms: u64,
    pub raw: Option<serde_json::Value>,  // Platform-specific payload preserved
}

pub struct Sender {
    pub id: String,
    pub display_name: Option<String>,
    pub is_bot: bool,
}

pub enum ContentBlock {
    Text(String),
    Image { url: String, mime: String },
    File { url: String, filename: String, mime: String },
    Audio { url: String, duration_secs: Option<f32> },
    Location { lat: f64, lon: f64 },
    Sticker { id: String, emoji: Option<String> },
    Reaction { emoji: String, message_id: String },
}
```

Outbound messages pass through a **normalization pipeline** before reaching the adapter:

```
LLM Response (rich markdown)
  → ContentParser (extract text, code, tables, media refs)
    → FormatAdapter (degrade based on channel capabilities)
      → LengthSplitter (chunk to channel max length)
        → MediaProcessor (resize/convert media to channel limits)
          → Channel.send()
```

### 1.4 Capabilities Manifest

Every channel declares exactly what it supports. The manifest drives all downstream rendering and interaction decisions:

```rust
pub struct ChannelCapabilities {
    // Message limits
    pub max_message_length: usize,       // 4096 Telegram, 2000 Discord, 512 IRC
    pub max_media_size_bytes: u64,       // 50MB Telegram, 25MB Discord

    // Feature flags
    pub streaming: StreamingCapability,   // None | BlockOnly | Preview
    pub media_types: MediaSupport,        // Images, Video, Audio, Documents
    pub reactions: bool,
    pub threads: ThreadSupport,           // None | Native | Topics | QuoteReply
    pub message_editing: bool,
    pub message_deletion: bool,
    pub inline_buttons: bool,
    pub groups: bool,

    // Formatting
    pub formatting: FormattingSupport,    // Plaintext | BasicMarkdown | RichMarkdown | HTML
    pub tables: bool,
    pub headers: bool,
    pub code_blocks: bool,
    pub latex: bool,
    // Note: The `latex` capability is included because Telegram's MarkdownV2 supports
    // LaTeX-style math rendering, which matters for educational/technical agents. The cost
    // is a single bool check during format degradation. If no future channel supports it,
    // the capability can be deprecated.

    // Rate limits
    pub rate_limit: RateLimit,
}

pub enum StreamingCapability {
    None,
    BlockOnly,      // Send chunks, no live editing
    Preview,        // Live edit via message update (Telegram-style)
}

pub enum ThreadSupport {
    None,
    Native,         // Discord threads, Slack threads
    Topics,         // Telegram forum topics
    QuoteReply,     // Signal-style reply chains
}
```

### 1.5 Format Degradation

The `FormatAdapter` automatically transforms content based on the target channel's capabilities:

| Content Type | Full Support | Degraded | Minimal |
|---|---|---|---|
| Markdown table | Rendered table (Telegram, Slack) | Code block (Discord) | Bullet list (WhatsApp, Signal) |
| Headers (`# H1`) | Native headers (Telegram, Discord) | **Bold text** (WhatsApp) | CAPS TEXT (IRC) |
| Inline buttons | Native buttons (Telegram, Discord, Slack) | Numbered list with instructions | Plain text options |
| Code blocks | Syntax-highlighted (Telegram, Discord) | Monospace block | Plain text with indentation |
| LaTeX/math | Rendered (Telegram) | Code block fallback | Plain text formula |
| Images | Inline image | Compressed image (under size limit) | URL link to image |

Format degradation uses `pulldown-cmark` to parse Markdown into an AST. Code blocks are preserved as-is. Nested structures that cannot be cleanly degraded fall back to plain text rather than producing garbled output.

### 1.6 Supported Channels

Blufio ships with a unified channel trait. **Phase 1: Telegram. Phase 3: Discord.** Additional adapters (WhatsApp, Signal, Slack, IRC, Matrix, etc.) are added incrementally post-v1.0. The trait design ensures new adapters can be implemented in **~1–2 weeks, ~500–1500 lines** depending on platform complexity.

Each adapter lives in its own feature-gated crate (`crates/channel-<name>/`):

| Channel | Rust Crate | Protocol | Tier |
|---|---|---|---|
| **Telegram** | `teloxide` | Bot API + webhook | Tier 1 |
| **Discord** | `twilight` | Gateway WebSocket + REST | Tier 1 |
| **WhatsApp** | `reqwest` (Cloud API) | Meta Business API (official) | Tier 2 |

> **⚠️ WhatsApp Business API** requires Meta business verification and a registered business entity. Personal users may not qualify. Individual WhatsApp integration via unofficial libraries (e.g., Baileys) carries ban risk and is not supported.
>
> WhatsApp Business API requires Meta business verification. Community contributors cannot implement or test this adapter without a verified business account. The WhatsApp adapter is maintainer-only — community PRs are welcome but require access to the project's developer sandbox (provided to approved contributors on request).

| **Slack** | `slack-morphism` / HTTP | Web API + Socket Mode | Tier 2 |
| **Signal** | `presage` (AGPL-3.0) | Native Signal protocol | Tier 2 |

> **⚠️ License Note (CRITICAL):** `presage` is licensed under AGPL-3.0, which is **incompatible with Blufio's MIT license**. Signal support is provided as a **separate optional binary** (`blufio-signal`) to isolate the AGPL dependency from the MIT-licensed core. Alternatively, Signal can be supported via a Matrix bridge (e.g., mautrix-signal) without AGPL contamination. The `blufio-signal` binary must not be statically linked into the core.
>
> **Build-Level Isolation:** The `blufio-signal` adapter is excluded from the default workspace members (`[workspace] exclude = ["adapters/signal"]`). It is NOT published to crates.io with the core. `cargo build --all-features` does not compile it — Signal support requires an explicit `cargo build -p blufio-signal`. The CI matrix builds and tests `blufio-signal` separately with AGPL license acknowledgment.
>
> **AGPL Contributor Guidance:** A `NOTICE` file in the repo root documents the AGPL boundary. `CONTRIBUTING.md` includes a dedicated section: "Working on Signal Integration" that explains: (a) all Signal-related code lives exclusively in `adapters/signal/`, (b) this directory carries its own `LICENSE-AGPL` file, (c) PRs touching signal code must acknowledge the AGPL scope in the PR description, (d) no AGPL-licensed code or imports may appear outside `adapters/signal/`. CI enforces this boundary with a lint check.
>
> **NOTICE File:** The repo includes `NOTICE` at root level listing all non-MIT dependencies with their licenses: wasmtime (Apache 2.0), SQLCipher Community (BSD), tikv-jemallocator (Apache 2.0 + BSD-2), and noting that blufio-signal (AGPL-3.0 via presage) is an optional, separately-built component not included in the default binary or crates.io publication.

| **iMessage** | `reqwest` | BlueBubbles REST API | Tier 2 |

> **Note:** Requires a Mac running BlueBubbles server. This is a Tier 2 channel with **significant infrastructure requirements** (always-on Mac hardware, iCloud account, BlueBubbles setup and maintenance).

| **Microsoft Teams** | `reqwest` | Bot Framework REST | Tier 2 |
| **Matrix** | `matrix-sdk` | Matrix client-server | Tier 3 |
| **IRC** | `irc` | RFC 2812 | Tier 3 |

> **IRC 512-Byte Limit:** IRC's 512-byte message limit requires aggressive splitting. LLM responses are split at sentence boundaries into multiple PRIVMSG commands, rate-limited to 1 message per 2 seconds (IRC flood prevention). Responses exceeding 10 messages are truncated with a '... [truncated, use /full to retrieve]' suffix. The full response is stored and retrievable via a command. IRC is a Tier 3 channel — operators should expect degraded experience for long responses.
| **Email** | `async-imap` + `lettre` | IMAP IDLE + SMTP | Tier 2 |
| **SMS/RCS** | `reqwest` | Twilio API | Tier 3 |
| **stdio** | `tokio::io` | stdin/stdout | Built-in |

### 1.7 Per-Channel Feature Matrix

| Channel | Streaming | Reactions | Threads | Edit | Buttons | Max Msg |
|---|---|---|---|---|---|---|
| Telegram | Preview | ✅ | Topics | ✅ | ✅ | 4096 |
| Discord | Block | ✅ | Native | ✅ | ✅ | 2000 |
| WhatsApp | ❌ | ✅ | ❌ | ❌ | List | 4096 |
| Slack | Block | ✅ | Native | ✅ | Blocks | 40K |
| Signal | ❌ | ✅ | Quote | ❌ | ❌ | 2000 |
| iMessage | ❌ | Tapback | ❌ | ❌ | ❌ | 20K |
| Teams | ❌ | ❌ | Native | ✅ | Cards | 28K |
| Matrix | ❌ | ✅ | Native | ✅ | ❌ | 65K |
| IRC | ❌ | ❌ | ❌ | ❌ | ❌ | 512 |
| Email | ❌ | ❌ | Native | ❌ | HTML | ∞ |

---

## 2. Channel Adapter Architecture

### 2.1 Connection Lifecycle

Every channel runs as a supervised `tokio::task` managed by the `ChannelSupervisor`. The lifecycle follows an Erlang/OTP-inspired supervision pattern, **adapted for Tokio's shared-heap model**:

```
Spawn → Connect → Run (message loop) → Disconnect/Error → Reconnect (backoff)
         ↑                                      │
         └──────── supervised retry ────────────┘
```

> **Note on Erlang analogy:** Unlike Erlang's isolated-heap processes where crashes are fully contained, Tokio tasks share memory within the same process. A panic in one task can poison shared `Mutex` state. Blufio mitigates this with `catch_unwind` wrappers around each adapter's message loop and independent state per adapter (no shared mutable state between channel tasks). This provides Erlang-like fault isolation semantics without Erlang's structural guarantees.

```rust
pub struct ChannelSupervisor {
    channels: HashMap<ChannelId, ChannelHandle>,
}

struct ChannelHandle {
    task: tokio::task::JoinHandle<()>,
    health: Arc<ChannelHealth>,
    cancel: tokio_util::sync::CancellationToken,
}

pub struct ChannelHealth {
    pub status: AtomicU8,              // 0=healthy, 1=degraded, 2=disconnected, 3=failed
    pub consecutive_failures: AtomicU32,
    pub last_message_at: AtomicI64,
    pub total_reconnects: AtomicU32,
}
```

### 2.2 Reconnection & Backoff

Three restart policies, configurable per channel:

```rust
pub enum RestartPolicy {
    /// Immediate retry, up to max_retries
    Immediate { max_retries: u32 },
    /// Exponential backoff: base_ms × 2^attempt, capped at max_ms
    ExponentialBackoff { base_ms: u64, max_ms: u64, max_retries: u32 },
    /// Circuit breaker: after N failures in window, stop trying
    CircuitBreaker { failure_threshold: u32, window_secs: u64, cooldown_secs: u64 },
}
```

**TOML configuration:**

```toml
[channels.telegram]
type = "telegram"
token = "${TELEGRAM_BOT_TOKEN}"

[channels.telegram.health]
check_interval = "30s"
restart_policy = "exponential-backoff"
base_delay = "1s"
max_delay = "5m"
max_retries = 100

[channels.whatsapp]
type = "whatsapp-cloud-api"
phone_number_id = "1234567890"
access_token = "${WHATSAPP_ACCESS_TOKEN}"

[channels.whatsapp.health]
check_interval = "60s"
restart_policy = "circuit-breaker"
failure_threshold = 5
cooldown = "10m"
```

### 2.3 Rate Limiting

Each adapter enforces platform-specific rate limits internally. The supervisor tracks rate-limit errors and adjusts send pacing. When a `ChannelError::RateLimit { retry_after }` is returned, messages are queued and delivery is paused for the specified duration.

### 2.4 Health Monitoring

The supervisor runs a health check loop (default: every 30 seconds):

1. **Poll each channel's `health()` method** — returns current connection state
2. **Check liveness** — if no messages sent or received in 5 minutes, send a heartbeat probe
3. **Apply recovery** — reconnect with backoff, alert user, or disable channel based on failure severity
4. **Emit metrics** — `agent_channel_health{channel="telegram"}` gauge (1=up, 0=down)

### 2.5 Graceful Degradation on Channel Failure

When a channel goes down, the supervisor can:
- Queue messages for delivery on reconnection (configurable buffer size)
- Route to a fallback channel if configured
- Notify the user via a healthy channel: *"⚠️ Your WhatsApp channel disconnected. Attempting reconnect..."*

### 2.6 Cross-Channel Bridging (Future Work)

> **Note:** Cross-channel bridging is a complex feature requiring its own design specification. It involves message ordering, edit propagation, identity mapping, duplicate detection, and media format conversion. The config below is a **placeholder for future work** and should not be treated as a committed design.

```toml
[bridges]
[[bridges.rules]]
from = { channel = "telegram", chat = "family-group" }
to = { channel = "discord", chat = "family-server/general" }
bidirectional = true
format = "bridged"  # "[Telegram/Alice] Hey everyone!"
```

---

## 3. Skill & Plugin System

### Skill Discovery via Progressive Disclosure

Skills are NOT injected into the LLM context in full. Instead, Blufio uses progressive disclosure (the same pattern as Claude Code):

1. **At session start:** The system prompt includes a lightweight `<available_skills>` block listing only skill names and one-line descriptions (~10 tokens per skill).
2. **On task match:** The LLM reads the relevant skill's `SKILL.md` file on demand (via file-read tool), getting full instructions, examples, and workflows.
3. **Per session:** At most 1-2 skills are fully loaded per session.

This means 50 installed skills cost ~500 tokens/turn instead of ~100,000. The skill's `description` field in `skill.toml` is the critical discovery surface — it must be optimized for agent matching.

**Skill loading instruction (injected in system prompt):**
"Before replying: scan <available_skills> <description> entries. If exactly one skill clearly applies: read its SKILL.md at <location>, then follow it. If multiple could apply: choose the most specific one, then read/follow it. If none clearly apply: do not read any SKILL.md. Never read more than one skill upfront; only read after selecting."

### 3.1 Plugin Architecture Overview

Blufio's plugin system supports four plugin categories, each with a dedicated sub-trait:

| Type | Purpose | Examples |
|---|---|---|
| **Channel Adapter** | Connect messaging platforms | Telegram, Discord, custom webhooks |
| **Memory Backend** | Store and retrieve agent memory | SQLite (default), PostgreSQL, Redis |
| **Tool Provider** | Expose tools to the LLM | MCP bridge, native Rust tools, REST wrappers |
| **Skill Runtime** | Execute sandboxed skill code | WASM (Wasmtime), Docker, subprocess |

### 3.2 Base Plugin Trait

```rust
#[async_trait]
pub trait Plugin: Send + Sync + 'static {
    fn meta(&self) -> &PluginMeta;
    async fn init(&mut self, config: toml::Value) -> anyhow::Result<()>;
    async fn start(&mut self) -> anyhow::Result<()>;
    async fn stop(&mut self) -> anyhow::Result<()>;
    fn save_state(&self) -> Option<Vec<u8>> { None }
    fn restore_state(&mut self, _state: Vec<u8>) -> anyhow::Result<()> { Ok(()) }
}

#[derive(Debug, Clone)]
pub struct PluginMeta {
    pub name: String,
    pub version: String,
    pub kind: PluginKind,
    pub description: String,
    pub author: String,
    pub hooks: Vec<HookRegistration>,
}

pub enum PluginKind {
    ChannelAdapter,
    MemoryBackend,
    ToolProvider,
    SkillRuntime,
}
```

### 3.3 Three Plugin Tiers

Blufio supports three execution tiers, balancing performance, isolation, and ease of development:

| Tier | Mechanism | Isolation | Performance | Use Case |
|---|---|---|---|---|
| **Native** | `libloading` (.so/.dylib) | Process-level | Native speed | First-party, trusted plugins |
| **WASM** | Wasmtime sandbox | Full capability-based sandbox | ~1.5× native | Community/third-party skills |
| **Script** | Subprocess (shell/Python) | Full process isolation | IPC overhead | Quick custom integrations |

The Script tier is the primary path for non-Rust developers. Skills can be written in any language (Python, TypeScript, Go, etc.) as a subprocess that communicates via JSON-RPC over stdin/stdout. The SDK provides scaffolding: `blufio skill init --lang python` generates a Python project with `skill.toml`, a handler template, `requirements.txt`, and a test harness. TypeScript: `blufio skill init --lang typescript` generates a Node.js project with the same structure. Script skills declare capabilities in `skill.toml` identically to WASM skills — the capability broker enforces permissions regardless of execution tier. Performance: ~5-10ms overhead per invocation (subprocess spawn + JSON serialization). For frequently-called skills, WASM is faster but Script is the "easy path" that 90% of skill authors should start with. Full documentation and 5+ example skills in Python/TypeScript ship with Phase 2.

**Which skill tier should I use?** Decision tree: (a) Is this YOUR skill for YOUR agent? → Script tier (Python/TS subprocess). Fast to build, full I/O, no sandbox needed for trusted code. (b) Are you publishing to the registry? → WASM tier required. Sandboxed, portable, signed. (c) Are you porting an OpenClaw JS skill? → Use blufio-openclaw-shim (Phase 2). No code changes. (d) Are you building a performance-critical native extension? → Native tier (Rust). Compile into the binary.

> **⚠️ Native Plugin Security Warning:** Native plugins run with **full process privileges** and bypass all sandboxing. They have unrestricted access to memory, filesystem, network, and all process resources. **Only load native plugins from trusted, audited sources.** The capability manifest for native plugins is **advisory only — it is not enforced** at runtime. WASM is the only safe tier for untrusted or community-submitted code.
>
> Native plugins (`.so`/`.dylib`) are NOT auto-loaded. They must be explicitly listed in `[plugins.native]` config with their expected SHA-256 hash. Blufio verifies the hash before loading. A plugin whose hash doesn't match is rejected. This prevents tampering but does not sandbox the plugin — native plugins still have full process access. `blufio doctor` warns when any native plugins are configured.

### 3.4 WASM Skill Execution

Third-party skills execute inside a Wasmtime sandbox with declared permissions:

```rust
pub struct WasmSkillRuntime {
    engine: wasmtime::Engine,
    linker: wasmtime::Linker<SkillState>,
}
```

WASM skill hot-reload: when a skill's `.wasm` file is updated on disk, the runtime detects the change via file watcher, verifies the new module's signature, and swaps it on the next invocation. In-flight invocations complete with the old module. No restart required. `blufio skill reload <name>` forces an immediate reload. Unsigned updated modules are rejected.

The `blufio-openclaw-shim` subprocess adapter ships in Phase 2 (not Phase 4). It wraps existing OpenClaw JS skills via Node.js subprocess + JSON-RPC — skills run unmodified but without WASM sandboxing. This is a subprocess wrapper, not a WASM compilation target, so the complexity is low. Moving it to Phase 2 removes the biggest migration blocker within 8-18 months (funded/volunteer) instead of 14-40 months.

The WASM sandbox targets WASI Preview 1 at launch for maximum compatibility. WASI Preview 2 (the Component Model) is the future of WASM interop — it enables richer cross-language types, composable components, and a more ergonomic SDK experience. Migration to the Component Model is planned for Phase 4 once the wasmtime implementation stabilizes. The `blufio_sdk` trait design is intentionally aligned with Component Model interfaces to minimize migration effort.

### 3.5 Skill Manifest Format

Every skill declares its metadata, permissions, and tools in a TOML manifest:

```toml
[package]
name = "web-search"
version = "1.2.0"
author = "verified-author-id"
runtime = "wasm"           # "wasm" | "native" | "script"
entry = "web_search.wasm"

[permissions]
network = ["api.brave.com", "api.google.com"]
filesystem.read = ["~/.config/search/"]
filesystem.write = []
exec = false
env_vars = ["SEARCH_API_KEY"]
conversation.read = false
conversation.write = false
memory.read = false
memory.write = false
max_memory_mb = 128
max_cpu_ms = 5000

[[tools]]
name = "search"
description = "Search the web using Brave Search API"
[tools.parameters]
query = { type = "string", description = "Search query" }
count = { type = "integer", description = "Number of results", default = 5 }
```

### 3.6 Permission Model

Permissions are enforced at two levels:

1. **Compile-time** — Rust's type system ensures WASM skills receive only a `SkillContext` containing capabilities they declared:

```rust
pub struct SkillContext<'a> {
    conversation: Option<&'a ConversationView>,  // Only if conversation.read granted
    memory: Option<&'a MemoryView>,              // Only if memory.read granted
    http: RestrictedHttpClient,                   // Restricted to declared hosts
    fs: RestrictedFs,                             // Restricted to declared paths
}
```

> **Note:** Compile-time enforcement applies only to skills compiled against the Blufio SDK (WASM and Rust native using the SDK). Native plugins loaded via `libloading` can call any function in the process — see the security warning in §3.3.

2. **Runtime** — The `PermissionBroker` intercepts all host function calls from WASM skills and checks them against the manifest:

```rust
impl PermissionBroker {
    fn check_network(&self, host: &str, skill: &SkillManifest) -> Result<(), PermissionDenied> {
        if skill.permissions.network.iter().any(|p| p.matches(host)) {
            Ok(())
        } else {
            Err(PermissionDenied {
                skill: skill.name.clone(),
                action: format!("network access to {}", host),
            })
        }
    }
}
```

**WASM Skill Network Security:** WASM skill network access enforces: (a) TLS required for all outbound connections (no plaintext HTTP), (b) wildcard domains (`*.example.com`) are expanded and validated — `*.local:*` is rejected as overly broad, (c) IP-based restrictions: private IPs blocked by default (same SSRF rules as the core). Skills requesting network access to local services must use explicit IPs/ports, not wildcards.

### 3.7 Code Signing (Ed25519)

Published skills must be cryptographically signed:

```rust
pub struct SignedSkill {
    pub manifest: SkillManifest,
    pub wasm_hash: [u8; 32],          // SHA-256 of the WASM binary
    pub signature: Ed25519Signature,
    pub public_key: Ed25519PublicKey,
}
```

**Verification flow:**
1. Download skill from registry
2. Verify Ed25519 signature against author's registered public key
3. Verify WASM binary hash matches manifest
4. Check permission manifest against user's policy
5. Load into Wasmtime sandbox with declared permissions

### 3.8 Skill Registry / Marketplace Vision

The Blufio skill registry follows a **curated, signed, audited** distribution model — closer to Debian's package model than npm's:

The skill registry serves WASM binaries (up to 64MB) via CDN (Cloudflare R2 or Backblaze B2). Per-IP download rate limit: 100 requests/hour, 10GB/day bandwidth. Operators can mirror the registry locally for air-gapped or high-volume environments. CDN costs are covered by the project's infrastructure budget (sponsor-funded). A paid tier for CI/CD pipelines with higher limits is a future revenue consideration.

- **Mandatory code signing** — Ed25519 signatures required for all published skills
- **Automated security scanning** — static analysis, behavioral sandbox testing, differential analysis on updates. This serves as a **first-pass filter, not a security guarantee**. Manual review is required for skills requesting sensitive capabilities (`exec`, `memory.write`, broad `network` access).
- **Human review** — required for first-time authors and sensitive permissions (`exec`, `memory.write`)
- **Post-publication monitoring** — anonymized usage telemetry, community reports, weekly re-scanning
- **Canary deployments** — new versions served to 5% of users for 48 hours before full rollout

Skill review SLA: automated scanning completes within 1 hour of submission. Manual review (for skills requesting sensitive capabilities) targets 5 business days. At volunteer pace, the 5-business-day SLA is aspirational. Realistically, manual reviews may take 2-3 weeks with part-time maintainers. To mitigate: (a) expand automated scanning to cover more permission patterns, reducing the need for manual review, (b) allow 'community-reviewed' status where 2+ trusted community members can approve a skill, (c) be transparent about review times on the registry submission page. **Community-reviewed is the DEFAULT path for skill publication, not the exception.** Two trusted community members (contributors with 3+ merged PRs) can approve a skill. Maintainer review is reserved for skills requesting sensitive capabilities (filesystem, network, exec). This scales at volunteer pace. Deprecated skills: authors can mark skills as deprecated with a successor recommendation. Skills with no updates for 12 months are flagged as 'unmaintained'. Skills with known security vulnerabilities are delisted immediately. Orphaned skills (author unresponsive for 6+ months) can be adopted by new maintainers via the registry's adoption process.

### 3.9 Plugin Hot Reload

Native plugins support hot reload via `libloading` with state preservation:

1. Save state from old plugin (`save_state()`)
2. Unload old `.so`/`.dylib`
3. Load new binary
4. Restore state into new plugin (`restore_state()`)

File watcher triggers reload automatically on plugin binary change.

---

## 4. Plugin Hooks

### 4.1 Hook Points

Blufio defines lifecycle hooks at well-defined points in the message processing pipeline:

| Hook | Phase | Timing | Can Short-Circuit |
|---|---|---|---|
| `pre_receive` | Guard | Before message enters the queue | ✅ (drop message) |
| `post_receive` | Transform | After normalization, before routing | ✅ (replace message) |
| `pre_inference` | Transform | Before LLM call, after context assembly | ✅ (bypass LLM) |
| `post_inference` | Transform | After LLM response, before tool execution | ✅ (override response) |
| `pre_tool` | Guard | Before each tool call | ✅ (block tool) |
| `post_tool` | Post | After each tool call | ❌ |
| `pre_send` | Transform | Before sending response to channel | ✅ (suppress response) |
| `post_send` | Post | After successful send | ❌ |
| `on_error` | Cleanup | On any error in the pipeline | ❌ |
| `on_session_start` | Lifecycle | When a new session is created | ❌ |
| `on_session_end` | Lifecycle | When a session is closed/rotated | ❌ |

> **⚠️ Security consideration:** Hooks that can short-circuit the pipeline (especially `pre_receive`, `pre_inference`, `post_inference`) are powerful attack vectors if compromised. A malicious hook can silently drop messages, bypass the LLM, or replace responses. Enable hook audit logging (`[hooks] audit = true`) in production to maintain visibility into hook behavior.

### 4.2 Priority-Ordered Execution

Hooks execute in deterministic priority order via `BTreeMap<HookPriority, Vec<HookEntry>>`. Lower numbers execute first:

```rust
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct HookPriority(pub u16);

impl HookPriority {
    // Priority ranges by phase:
    //   0–99:   Guard (rate limit, auth, spam)
    //   100–199: Transform (normalize, translate)
    //   200–299: Handle (AI routing, main logic)
    //   300–399: Post (logging, analytics)
    //   400–499: Cleanup (session cleanup, resources)

    pub const RATE_LIMITER: Self = Self(10);
    pub const SPAM_FILTER: Self = Self(50);
    pub const NORMALIZER: Self = Self(100);
    pub const AI_ROUTER: Self = Self(200);
    pub const LOGGER: Self = Self(300);
    pub const CLEANUP: Self = Self(400);
}
```

### 4.3 Hook Handler Trait

```rust
pub trait HookHandler: Send + Sync + 'static {
    fn handle<'a>(
        &'a self,
        ctx: &'a mut HookContext,
        next: Next<'a>,
    ) -> Pin<Box<dyn Future<Output = HookResult> + Send + 'a>>;
}

pub enum HookResult {
    Continue,               // Pass to next handler
    Handled,                // Short-circuit — this hook consumed the event
    Error(anyhow::Error),   // Stop chain with error
}
```

### 4.4 Event System

Hooks emit structured events that feed into the observability pipeline:

```rust
pub struct HookEvent {
    pub hook_name: String,
    pub plugin_name: String,
    pub priority: HookPriority,
    pub duration: Duration,
    pub result: HookResult,
    pub trace_id: String,
}
```

**Metrics emitted per hook invocation:**
- `blufio_hook_invocations_total{hook, plugin}` — counter
- `blufio_hook_duration_seconds{hook, plugin}` — histogram
- `blufio_hook_errors_total{hook, plugin}` — counter

### 4.5 Hook Chaining

Multiple hooks at the same hook point execute as a middleware chain. Each handler receives a `next` function to invoke the rest of the chain, enabling before/after behavior:

```rust
// A logging hook that wraps the entire chain
impl HookHandler for TimingHook {
    fn handle<'a>(&'a self, ctx: &'a mut HookContext, next: Next<'a>)
        -> Pin<Box<dyn Future<Output = HookResult> + Send + 'a>>
    {
        Box::pin(async move {
            let start = Instant::now();
            let result = next(ctx).await;    // execute remaining chain
            let elapsed = start.elapsed();
            tracing::info!(hook = "timing", elapsed_ms = elapsed.as_millis(), "hook chain complete");
            result
        })
    }
}
```

### 4.6 Hook Sandboxing

Hook processes run with reduced privileges: (a) separate OS user (`blufio-hooks`) with minimal filesystem access if the system supports it, (b) `RLIMIT_CPU` (5s) and `RLIMIT_AS` (256MB) resource limits, (c) on Linux, hooks execute inside a minimal `unshare` namespace (no network by default — hooks that need network declare `network = true` in config). Sync hooks that exceed the timeout are killed immediately. This is defense-in-depth — not equivalent to WASM sandboxing, but significantly reduces blast radius.

### 4.7 Shell-Based Hooks

For quick integrations, hooks can be shell scripts:

```toml
[[hooks.shell]]
event = "pre_receive"
priority = 40
command = "./hooks/spam-filter.sh"
timeout = "30s"

[hooks]
audit = true  # Enable hook audit logging in production
```

The script receives a JSON envelope on stdin and writes JSON to stdout:

**Input schema:**
```json
{
  "event": "pre_receive",
  "session_id": "abc-123",
  "timestamp": "2026-02-28T14:00:00.123Z",
  "payload": {
    "text": "Hello, world!",
    "sender": { "id": "user-1", "display_name": "Alice" },
    "channel": "telegram"
  }
}
```

**Output:** JSON on stdout. Invalid JSON output is logged and ignored (hook treated as `continue`). `stderr` output is captured to the Blufio log. **Timeout: 30 seconds** (configurable per hook). Scripts exceeding the timeout are killed and the hook is treated as `continue`.

```bash
#!/bin/bash
MSG=$(cat)
TEXT=$(echo "$MSG" | jq -r '.payload.text')
if echo "$TEXT" | grep -qi "spam"; then
    echo '{"action": "block", "reason": "Spam detected"}'
else
    echo '{"action": "continue"}'
fi
```

---

## 5. Provider Ecosystem

### 5.1 Provider Trait

LLM providers are plugins implementing the `ProviderAdapter` trait. Anthropic ships built-in. Others are installed via `blufio plugin install provider-openai`, `blufio plugin install provider-ollama`, etc. Provider plugins handle: model listing, completion/streaming, token counting, cache management, and format-specific features (JSON mode, tool calling). Adding a custom provider (e.g., corporate proxy) means implementing the `ProviderAdapter` trait — typically 200-400 lines of Rust.

Every LLM backend implements a single trait:

```rust
#[async_trait]
pub trait Provider: Send + Sync + 'static {
    fn id(&self) -> &str;
    async fn list_models(&self) -> Result<Vec<ModelInfo>, ProviderError>;
    async fn chat(&self, request: &ChatRequest, auth: &AuthProfile) -> Result<ChatResponse, ProviderError>;
    async fn chat_stream(&self, request: &ChatRequest, auth: &AuthProfile)
        -> Result<Pin<Box<dyn Stream<Item = Result<ChatChunk, ProviderError>> + Send>>, ProviderError>;
    fn capabilities(&self) -> ProviderCapabilities;
    fn pricing(&self, model: &str) -> Option<ModelPricing>;
}

pub struct ProviderCapabilities {
    pub streaming: bool,
    pub tool_calling: bool,
    pub vision: bool,
    pub prompt_caching: bool,
    pub max_context_window: usize,
    pub wire_protocol: WireProtocol,
}

pub struct ModelPricing {
    pub input_per_million: f64,
    pub output_per_million: f64,
    pub cache_read_per_million: Option<f64>,
    pub cache_write_per_million: Option<f64>,
}
```

### 5.2 Wire Protocol Adapters

Three wire protocol adapters handle actual HTTP serialization:

```rust
pub enum WireProtocol {
    OpenAI,      // /v1/chat/completions — OpenAI, OpenRouter, Groq, Cerebras, vLLM, etc.
    Anthropic,   // /v1/messages — Anthropic native
    Ollama,      // /api/chat — Ollama native
}
```

**OpenAI Wire Protocol Streaming:** Streaming responses include `stream_options.include_usage` support for real-time cost tracking. Tool call deltas are streamed incrementally (compatible with LangChain and similar frameworks that process tool calls as they arrive).

Any custom provider only needs a base URL, API key, and wire protocol selection:

```toml
[[providers.custom]]
id = "local-vllm"
base_url = "http://localhost:8000/v1"
wire_protocol = "openai"
api_key_env = "VLLM_API_KEY"
models = ["meta-llama/Llama-3.3-70B"]
```

### 5.3 Supported Providers

| Provider | Wire Protocol | Key Features |
|---|---|---|
| **Anthropic** | Anthropic | Prompt caching, extended thinking, 1M context |
| **OpenAI** | OpenAI | Function calling, vision, Codex OAuth (PKCE) |
| **Ollama** | Ollama | Local models, auto-discovery, no auth needed |
| **OpenRouter** | OpenAI | 100+ models, single API key, cost headers |
| **Google (Gemini)** | OpenAI-compat | Long context, multimodal |
| **Custom** | Any | User-configured base URL + wire protocol |

### 5.4 Auth & Token Management

Credentials are stored in an encrypted vault (AES-256-GCM), not plaintext JSON:

```rust
pub struct CredentialVault {
    store: EncryptedStore,    // AES-256-GCM encrypted
    cache: RwLock<HashMap<ProfileId, AuthProfile>>,
}

pub enum AuthProfile {
    ApiKey { key: String, provider: ProviderId },
    OAuth {
        access_token: String,
        refresh_token: Option<String>,
        expires_at: DateTime<Utc>,
        provider: ProviderId,
    },
    ApiKeyRotation {
        keys: Vec<String>,
        current_index: AtomicUsize,
        provider: ProviderId,
    },
}
```

OAuth refresh uses double-checked locking via `RwLock` — no file-lock race conditions:

```rust
async fn get_valid_token(&self) -> Result<String, AuthError> {
    // Fast path: read lock
    { let tokens = self.tokens.read().await;
      if tokens.expires_at > Utc::now() + Duration::minutes(5) { return Ok(tokens.access_token.clone()); } }
    // Slow path: exclusive write lock, double-check, refresh
    let mut tokens = self.tokens.write().await;
    if tokens.expires_at > Utc::now() + Duration::minutes(5) { return Ok(tokens.access_token.clone()); }
    *tokens = self.refresh(&tokens.refresh_token).await?;
    Ok(tokens.access_token.clone())
}
```

### 5.5 Cost-Aware Model Routing

The `ModelRouter` selects models based on rules (message complexity, budget, source):

```rust
pub struct ModelRouter {
    rules: Vec<RoutingRule>,
    default_model: String,
    cost_ledger: Arc<CostLedger>,
    latency_tracker: Arc<LatencyTracker>,
}

pub enum RoutingRule {
    CostOptimize { max_input_tokens: usize, cheap_model: ModelRef },
    CapabilityMatch { requires: Vec<Capability>, model: ModelRef },
    BudgetCap { daily_limit_usd: f64, fallback_model: ModelRef },
    Schedule { hours: Range<u8>, model: ModelRef },
}
```

**TOML configuration:**

```toml
[model_routing]
default_model = "claude-sonnet-4-6"

[[model_routing.rules]]
name = "heartbeat"
match = { type = "Source", source = "heartbeat" }
model = "claude-haiku-4-5"
context = "Minimal"

[[model_routing.rules]]
name = "complex"
match = { type = "Keywords", keywords = ["analyze", "research", "deep dive"], any = true }
model = "claude-opus-4-6"
```

### 5.6 Additional Provider Types

| Provider Type | Examples | Integration |
|---|---|---|
| **TTS** | ElevenLabs, OpenAI TTS | `TtsProvider` trait |
| **Transcription** | Whisper, Deepgram | `TranscriptionProvider` trait |
| **Embedding** | OpenAI, Cohere, Voyage | `EmbeddingProvider` trait |

> ⚠️ **Raspberry Pi 3 (ARM32):** Ships without local embedding model. Memory search is keyword-only (BM25). For semantic search on Pi, use a remote embedding API (`[embedding] provider = 'openai'`). Raspberry Pi 4/5 (ARM64) fully supports local embeddings. This limitation is stated on the download page next to the ARM32 binary.
>
> **Config recipe: `iot`** — single channel (Telegram or MQTT), Anthropic provider, no SQLCipher (performance), no embedding model (keyword search only), reduced Argon2id parameters, minimal logging, no cron. Optimized for Raspberry Pi 3/Zero with <512MB available RAM.
| **Image Analysis** | Claude Vision, GPT-4V | Via main `Provider` trait (vision capability) |
| **Web Search** | Brave, Google | Via `Tool` trait |
| **Browser** | CDP (Chromium) | `BrowserTool` with timeout guards on every call |
| **MCP Servers** | Any MCP-compatible | Native MCP client (no `mcporter` subprocess) |

> **MCP Timeline:** Basic MCP client support (connecting to external MCP tool servers, calling MCP tools from the agent loop) ships in Phase 1. In 2026, MCP is table stakes — every serious AI tool speaks MCP. Launching without it risks ecosystem incompatibility from day one. MCP server mode (exposing Blufio's tools via MCP for external consumers) ships in Phase 3.

### 5.7 Tool Trait

```rust
#[async_trait]
pub trait Tool: Send + Sync + 'static {
    fn name(&self) -> &str;
    fn parameters_schema(&self) -> serde_json::Value;
    fn manifest(&self) -> ToolManifest;
    async fn execute(&self, params: serde_json::Value, context: &ToolContext) -> Result<ToolOutput, ToolError>;
}

pub struct ToolManifest {
    pub description: String,
    pub permissions: Vec<Permission>,
    pub timeout: Duration,
    pub parallel: bool,          // Can run concurrently with other tools
    pub sandbox_required: bool,
    pub cost_estimate: CostEstimate,
}
```

Tools marked `parallel: true` execute concurrently via `join_all`. Every tool call is wrapped in `tokio::time::timeout` — no tool can run forever.

---

## 6. Cost & Observability

### 6.1 Design Principle

Blufio treats **every API-spending operation** as a first-class cost event. Unlike OpenClaw which only tracks model inference, Blufio records costs across all 10+ spending categories with a unified ledger.

### 6.2 Tracked Cost Categories

| Feature | Provider Examples | Cost Basis |
|---|---|---|
| **Inference** | Anthropic, OpenAI, Google | Input/output tokens × per-token price |
| **Embedding** | OpenAI, Cohere, Voyage | Token count × per-token price |
| **TTS** | ElevenLabs, OpenAI | Character count × per-char price |
| **Transcription** | Whisper, Deepgram | Audio duration × per-minute price |
| **Search** | Brave, Google | Per-query flat rate |
| **Compaction** | Anthropic, OpenAI | Tokens in compaction inference call |
| **Media Understanding** | Claude Vision, GPT-4V | Image tokens + text tokens |
| **Skill APIs** | Custom skill HTTP calls | Per-call or metered (skill-reported) |
| **Web Fetch** | Bright Data, direct fetch | Per-request or bandwidth-based |
| **Model Scan** | Anthropic, OpenAI | Prefill tokens for context scanning |

> **Note on skill-reported costs:** Costs self-reported by skills via their manifest or runtime reporting are treated as **estimates only**. The host independently tracks observable costs (HTTP calls routed through the capability broker, token usage from provider responses) as a cross-check against skill-reported values. Discrepancies are logged and flagged.

### 6.3 CostEvent & CostLedger

```rust
pub struct CostEvent {
    pub id: String,
    pub timestamp_ms: u64,
    pub trace_id: Option<String>,
    pub session_id: Option<String>,
    pub provider: String,
    pub feature: String,        // "inference", "tts", "search", "embedding", etc.
    pub operation: String,      // "chat_completion", "tts_generate", "web_search"
    pub model: Option<String>,
    pub input_tokens: Option<u64>,
    pub output_tokens: Option<u64>,
    pub input_chars: Option<u64>,
    pub duration_minutes: Option<f64>,
    pub cost_usd: f64,
    pub metadata: serde_json::Value,
}

pub struct CostLedger {
    db: Mutex<Connection>,      // SQLite (observability.db)
    price_table: PriceTable,    // Embedded, updated per release
}
```

All subsystems call `ledger.record(...)` after each cost-incurring operation. If `cost_usd` is 0, the ledger auto-estimates from the embedded price table.

`blufio doctor --check costs` validates the cost ledger: checks for sessions with zero recorded costs despite message activity, detects pricing file staleness, and verifies provider-reported token counts match local estimates (within 15% tolerance). Discrepancies are reported with diagnostic context.

### 6.4 SQLite Schema

All observability data lives in `observability.db` (separate from main agent DB):

```sql
-- Individual cost events
CREATE TABLE cost_events (
    id              TEXT PRIMARY KEY,
    timestamp_ms    INTEGER NOT NULL,
    trace_id        TEXT,
    session_id      TEXT,
    provider        TEXT NOT NULL,
    feature         TEXT NOT NULL,
    operation       TEXT NOT NULL,
    model           TEXT,
    input_tokens    INTEGER,
    output_tokens   INTEGER,
    cost_usd        REAL NOT NULL,
    metadata        TEXT DEFAULT '{}'
);

-- Pre-aggregated daily totals (updated on every record() call)
CREATE TABLE cost_daily (
    date            TEXT NOT NULL,
    provider        TEXT NOT NULL,
    feature         TEXT NOT NULL,
    requests        INTEGER NOT NULL DEFAULT 0,
    total_cost_usd  REAL NOT NULL DEFAULT 0.0,
    PRIMARY KEY (date, provider, feature)
);

-- Budget configuration
CREATE TABLE budgets (
    id              TEXT PRIMARY KEY,
    scope           TEXT NOT NULL,       -- "global", "provider:anthropic", "feature:tts"
    period          TEXT NOT NULL,       -- "daily", "monthly"
    limit_usd       REAL NOT NULL,
    warning_pct     REAL DEFAULT 0.8,
    hard_stop       INTEGER DEFAULT 1
);
```

### 6.5 Budget System

```rust
pub struct BudgetEnforcer {
    ledger: Arc<CostLedger>,
    config: BudgetConfig,
}

pub enum BudgetCheck {
    Ok,
    Warning { scope: String, spent: f64, limit: f64, pct: f64 },
    Exceeded { scope: String, spent: f64, limit: f64 },
}
```

**Budget enforcement flow:**
1. Before every API-spending operation, call `budget.pre_check(feature, session_id)`
2. `Ok` → proceed normally
3. `Warning` → log warning, notify operator (debounced: max once per hour), proceed
4. `Exceeded` → block the request if `hard_stop = true`

**Configurable actions on budget limits:**

```toml
[budgets]
daily_usd = 10.00
monthly_usd = 100.00
warning_pct = 0.80
hard_stop = true

[budgets.feature.tts]
daily_usd = 2.00

[budgets.feature.search]
daily_usd = 1.00

# Exempt features that must always work
exempt_features = ["compaction"]
exempt_sessions = ["system"]

[budgets.on_soft_limit]
action = "downgrade_model"
target = "claude-haiku-4-5"
```

### 6.6 Cost CLI

```
$ blufio costs today --by feature

╭──────────────────────────────────────────────╮
│         Cost Summary — 2026-02-28            │
├──────────────┬──────────┬────────────────────┤
│ Feature      │ Requests │ Cost (USD)         │
├──────────────┼──────────┼────────────────────┤
│ inference    │       47 │            $3.82   │
│ compaction   │        6 │            $0.91   │
│ tts          │        8 │            $0.64   │
│ search       │       23 │            $0.12   │
│ embedding    │       12 │            $0.01   │
├──────────────┼──────────┼────────────────────┤
│ TOTAL        │       96 │            $5.50   │
╰──────────────┴──────────┴────────────────────╯
Budget: $5.50 / $10.00 daily (55%) ✅
```

**Chat integration:** Users query costs via `/costs` command in any channel, formatted for that channel's capabilities.

### 6.7 Cost Dashboard (Prometheus)

Cost data feeds into Prometheus metrics for Grafana dashboards:
- `blufio_cost_usd_total{provider, feature}` — counter
- `blufio_budget_remaining_usd{scope, period}` — gauge

---

## 7. Metrics & Tracing

### 7.1 Prometheus Metrics

Observability exporters are plugins. Prometheus metrics export is built-in. Additional exporters: `blufio plugin install obs-datadog`, `blufio plugin install obs-opentelemetry`, `blufio plugin install obs-grafana-cloud`. Multiple observability plugins can be active simultaneously (e.g., Prometheus + Datadog). Each implements the `ObservabilityAdapter` trait.

Blufio exposes `GET /metrics` with 20+ metrics:

| Metric | Type | Labels | Purpose |
|---|---|---|---|
| `blufio_cost_usd_total` | Counter | provider, feature | Cost tracking |
| `blufio_cost_requests_total` | Counter | provider, feature | Request volume |
| `blufio_tokens_input_total` | Counter | provider, model | Token consumption |
| `blufio_tokens_output_total` | Counter | provider, model | Token consumption |
| `blufio_llm_latency_seconds` | Histogram | provider, model | LLM latency percentiles |
| `blufio_tts_latency_seconds` | Histogram | — | TTS latency |
| `blufio_tool_latency_seconds` | Histogram | tool_name | Tool execution latency |
| `blufio_skill_latency_seconds` | Histogram | skill_name | Skill execution latency |
| `blufio_messages_received_total` | Counter | channel | Inbound volume |
| `blufio_messages_sent_total` | Counter | channel | Outbound volume |
| `blufio_message_queue_depth` | Gauge | — | Queue health |
| `blufio_active_sessions` | Gauge | — | Concurrency |
| `blufio_errors_total` | Counter | subsystem, error_type | Error rate |
| `blufio_provider_errors_total` | Counter | provider, status_code | API errors |
| `blufio_channel_health` | Gauge | channel | Connection status (1/0) |
| `blufio_budget_remaining_usd` | Gauge | scope, period | Budget status |
| `blufio_hook_invocations_total` | Counter | hook, plugin | Hook usage |
| `blufio_hook_duration_seconds` | Histogram | hook, plugin | Hook performance |
| `blufio_uptime_seconds` | Gauge | — | Process uptime |
| `blufio_memory_bytes` | Gauge | — | Memory usage |
| `blufio_cache_hit_total` | Counter | provider | Prompt cache hits |
| `blufio_cache_miss_total` | Counter | provider | Prompt cache misses |
| `blufio_cache_hit_rate` | Gauge | provider | Rolling cache hit rate |
| `blufio_cache_write_bytes_total` | Counter | provider | Bytes written to cache |

> **Cache Observability Note:** Cache hit rate is the primary metric for validating Blufio's cost-reduction thesis. Without it, operators cannot verify the 80-90% target is being met.

### 7.2 Structured Logging

All logging uses the `tracing` crate with structured JSON output:

```json
{
  "timestamp": "2026-02-28T14:00:00.123Z",
  "level": "INFO",
  "target": "blufio::provider::anthropic",
  "message": "LLM response received",
  "trace_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "span": "handle_message",
  "fields": {
    "provider": "anthropic",
    "model": "claude-sonnet-4-6",
    "input_tokens": 2841,
    "output_tokens": 384,
    "latency_ms": 2341,
    "cost_usd": 0.0143
  }
}
```

**Configuration:**

```toml
[observability]
log_level = "info"
log_format = "json"           # "json" | "pretty" | "compact"

[observability.metrics]
enabled = true
backend = "prometheus"
listen_addr = "127.0.0.1:9090"

[observability.tracing]
enabled = false               # Optional, disabled by default
otlp_endpoint = "http://localhost:4317"
service_name = "blufio"
sample_rate = 1.0
```

> **Note on OpenTelemetry:** OTel distributed tracing is **optional and disabled by default**. Most single-instance deployments need only structured JSON logs (which include trace IDs for correlation). Enable OTel tracing only if you run Jaeger, Grafana Tempo, Datadog, or similar infrastructure and need cross-service span visualization.

CLI respects the `NO_COLOR` environment variable (no-color.org standard). Flags: `--color always|auto|never`. Default: `auto` (detect TTY). All CLI output is screen-reader compatible when `NO_COLOR` is set — no ANSI escape codes, no spinner animations, structured output only.

Log levels are configurable per subsystem via the `BLUFIO_LOG` environment variable, using the `tracing` crate's `EnvFilter` syntax: `BLUFIO_LOG=blufio=info,blufio::provider=debug,blufio::queue=warn`. This allows operators to debug specific subsystems without flooding logs. The config file equivalent: `[logging] filter = 'blufio=info,blufio::provider=debug'`. Default: `blufio=info`.

### 7.3 Distributed Tracing

Every inbound message receives a `trace_id` that propagates through the entire request lifecycle:

```
Telegram message arrives (trace_id = "abc-123")
  → Channel adapter (normalize)
    → Session manager (route)
      → LLM provider call (child span: "llm.chat_completion")
        → Tool execution (child span: "tool.web_search")
          → Cost event (trace_id = "abc-123")
      → Response formatting
    → Channel send (child span: "channel.send")
```

The trace context propagates via `tokio::task_local`:

```rust
tokio::task_local! { static CURRENT_TRACE: SpanContext; }

pub fn current_trace_id() -> Option<String> {
    CURRENT_TRACE.try_with(|ctx| ctx.trace_id.clone()).ok()
}
```

Any subsystem can call `current_trace_id()` to tag cost events and log entries without explicit parameter passing.

### 7.4 OpenTelemetry Export

For production deployments with Jaeger, Grafana Tempo, or Datadog:

```toml
[observability.tracing]
enabled = true
otlp_endpoint = "http://localhost:4317"  # gRPC OTLP endpoint
service_name = "blufio"
```

The `tracing` crate's `#[instrument]` macro automatically creates OpenTelemetry spans:

```rust
#[tracing::instrument(skip(self, request), fields(provider = "anthropic", model = %request.model))]
async fn call_anthropic(&self, request: &LlmRequest) -> Result<LlmResponse> {
    // Automatically creates an OTel span with provider/model attributes
}
```

### 7.5 Shell Script Monitoring

For lightweight deployments without Prometheus/Grafana, Blufio ships with shell scripts that query SQLite directly:

```bash
$ blufio-cost-alert.sh   # Hourly via systemd timer; checks daily/monthly budgets, anomaly detection
$ blufio-cost-status.sh  # One-shot: current cost status for humans
$ blufio backup           # Creates tarball with blufio.db, observability.db, config, and vault key backup
```

The backup script includes both `blufio.db` and `observability.db`. Cost history and metrics would be lost without backing up the observability database. `blufio backup` creates a tarball with both databases, config, and vault key backup (if one exists).

Cost anomaly detection uses both relative and absolute thresholds: (a) Relative: spending exceeds 3× the 7-day moving average. (b) Absolute: spending exceeds a hard cap (`[costs.daily_hard_cap]`, default: $50/day). (c) Trend: spending has increased >20% week-over-week for 3 consecutive weeks. The absolute threshold prevents the 'boiling frog' problem where gradual increases slide the average up without triggering alerts. All three checks run independently.

---

## 8. Error Resilience

### 8.1 Typed Error Hierarchy

Blufio uses Rust's `Result<T, E>` universally. The compiler prevents silent error swallowing — the antithesis of OpenClaw's empty `catch {}` blocks.

```rust
#[derive(Debug, thiserror::Error)]
pub enum AgentError {
    // Provider errors
    #[error("rate limited by {provider}: retry after {retry_after:?}")]
    RateLimited { provider: ProviderId, retry_after: Option<Duration> },

    #[error("auth failed for {provider}: {reason}")]
    ProviderAuthFailed { provider: ProviderId, reason: String },

    #[error("provider {provider} server error: HTTP {status}")]
    ProviderServerError { provider: ProviderId, status: u16, body: Option<String> },

    #[error("provider {provider} timed out after {timeout:?}")]
    ProviderTimeout { provider: ProviderId, timeout: Duration },

    // Channel errors
    #[error("channel {channel} delivery failed")]
    ChannelDeliveryFailed { channel: ChannelId, retryable: bool, #[source] source: Box<dyn std::error::Error + Send + Sync> },

    #[error("channel {channel} disconnected")]
    ChannelDisconnected { channel: ChannelId },

    // Storage errors
    #[error("database error: {0}")]
    Database(#[from] rusqlite::Error),

    #[error("disk full: {detail}")]
    DiskFull { detail: String },

    // Tool errors
    #[error("tool {tool} timed out after {timeout:?}")]
    ToolTimeout { tool: String, timeout: Duration },

    #[error("tool {tool} permission denied: requires {permission}")]
    ToolPermissionDenied { tool: String, permission: String },

    // Budget errors
    #[error("budget exceeded: spent ${spent:.2}, limit ${limit:.2}")]
    BudgetExceeded { agent_id: AgentId, spent: f64, limit: f64 },

    // Configuration errors
    #[error("configuration error: {detail}")]
    ConfigError { detail: String },
}
```

### 8.2 Error Metadata

Every error carries structured metadata for automated handling:

```rust
impl AgentError {
    pub fn is_retryable(&self) -> bool {
        matches!(self,
            Self::RateLimited { .. } |
            Self::ProviderServerError { status, .. } if *status >= 500 |
            Self::ProviderTimeout { .. } |
            Self::ChannelDeliveryFailed { retryable: true, .. } |
            Self::ChannelDisconnected { .. }
        )
    }

    pub fn retry_delay(&self) -> Option<Duration> {
        match self {
            Self::RateLimited { retry_after, .. } => *retry_after,
            Self::ProviderServerError { .. } => Some(Duration::from_secs(5)),
            Self::ProviderTimeout { .. } => Some(Duration::from_secs(10)),
            _ => None,
        }
    }

    pub fn severity(&self) -> Severity {
        match self {
            Self::DiskFull { .. } => Severity::Critical,
            Self::ProviderAuthFailed { .. } | Self::BudgetExceeded { .. } => Severity::High,
            Self::ProviderServerError { .. } => Severity::Medium,
            Self::RateLimited { .. } | Self::ToolTimeout { .. } => Severity::Low,
            _ => Severity::Medium,
        }
    }

    pub fn category(&self) -> ErrorCategory {
        match self {
            Self::RateLimited { provider, .. } | Self::ProviderAuthFailed { provider, .. }
            | Self::ProviderServerError { provider, .. } | Self::ProviderTimeout { provider, .. }
                => ErrorCategory::Provider(provider.clone()),
            Self::ChannelDeliveryFailed { channel, .. } | Self::ChannelDisconnected { channel, .. }
                => ErrorCategory::Channel(channel.clone()),
            Self::Database(_) | Self::DiskFull { .. } => ErrorCategory::Storage,
            Self::ToolTimeout { tool, .. } | Self::ToolPermissionDenied { tool, .. }
                => ErrorCategory::Tool(tool.clone()),
            _ => ErrorCategory::System,
        }
    }
}
```

### 8.3 Circuit Breakers

Each external dependency has a circuit breaker:

```rust
pub struct CircuitBreaker {
    state: AtomicCell<CircuitState>,
    failure_count: AtomicU32,
    config: CircuitBreakerConfig,
}

pub enum CircuitState {
    Closed,    // Normal — requests flow through
    Open,      // Failures exceeded threshold — requests rejected immediately
    HalfOpen,  // Testing recovery — one request allowed through
}

pub struct CircuitBreakerConfig {
    pub failure_threshold: u32,    // Default: 5
    pub reset_timeout: Duration,   // Default: 60s
    pub success_threshold: u32,    // Default: 2 (successes in HalfOpen before closing)
    pub failure_window: Duration,  // Default: 120s
}
```

**State transitions:** `Closed →[failures ≥ threshold]→ Open →[timeout]→ HalfOpen →[success]→ Closed` / `HalfOpen →[failure]→ Open`

**Per-dependency configuration:**

```toml
[resilience.circuit_breakers.anthropic]
failure_threshold = 5
reset_timeout = "60s"

[resilience.circuit_breakers.telegram]
failure_threshold = 10
reset_timeout = "30s"
```

### 8.4 Graceful Degradation Ladder

Five defined degradation levels:

| Level | Name | Trigger | Behavior |
|---|---|---|---|
| 0 | **Fully Operational** | All systems healthy | Normal operation |
| 1 | **Degraded Provider** | Primary LLM circuit open | Fall back to secondary; notify operator |
| 2 | **Limited Tools** | Tool failures or disk pressure | Disable non-essential tools; warn users |
| 3 | **Text Only** | Rich media delivery failing | Text responses only |
| 4 | **Emergency** | Database errors or resource exhaustion | Read-only mode; configurable fallback message; queue outgoing |
| 5 | **Safe Shutdown** | Unrecoverable state | Complete in-flight; persist state; exit with diagnostics |

User communication at each level:
- **Level 1:** *"⚠️ Using backup AI provider. Responses may differ."*
- **Level 2:** *"⚠️ Some tools temporarily unavailable."*
- **Level 3:** *"⚠️ Rich media temporarily unavailable. Text-only mode."*
- **Level 4:** Configurable fallback message (default: *"⚠️ System in emergency mode. Responses may be delayed."*). Configure via `[resilience] emergency_message = "..."` in TOML.

### 8.5 Retry Strategies

Retryable errors use configurable strategies:

```rust
pub struct RetryPolicy {
    pub max_attempts: u32,
    pub initial_delay: Duration,
    pub max_delay: Duration,
    pub backoff: BackoffStrategy,
}

pub enum BackoffStrategy {
    Constant,
    Exponential { factor: f64 },       // delay × factor^attempt
    ExponentialWithJitter { factor: f64 },
}
```

### 8.6 Crash Recovery

SQLite WAL mode ensures zero data loss on unexpected termination:

```rust
conn.pragma_update(None, "journal_mode", "wal")?;
conn.pragma_update(None, "synchronous", "normal")?;
```

**Startup recovery procedure:**
1. SQLite automatically replays uncommitted WAL entries
2. Detect interrupted turns (user message with no following assistant message)
3. Clean stale session locks
4. Report recovery summary

### 8.7 No Panics Policy

Library code never uses `unwrap()`, `expect()`, or `panic!()`. CI enforces this via Clippy:

```rust
#![deny(clippy::unwrap_used, clippy::expect_used)]
```

### 8.8 Integration Test Infrastructure

Integration test infrastructure ships in Phase 1: (a) mock channel servers (fake Telegram API, fake Discord gateway) for end-to-end message flow testing, (b) a test harness that spins up a full Blufio instance against SQLite in-memory, (c) cost tracking validation tests with recorded provider responses. Contributors can run `cargo test --workspace` for unit tests and `cargo test --features integration` for full integration tests. The CI pipeline runs both.

### 8.9 Health Monitoring & Auto-Remediation

Continuous health checks (default: every 30s) with automatic remediation:

| Check Failure | Remediation |
|---|---|
| WAL too large | Force WAL checkpoint |
| Stale session locks | Clean expired locks |
| Disk space low | Run retention enforcement, clean temp files |
| Memory usage high | Evict caches, close idle sessions |
| Provider connectivity failed | Open circuit breaker, update degradation level |

**Health API:**

```
GET /v1/health → { status, degradation_level, checks: { database, disk, memory, providers, channels }, uptime_seconds, version }
```

Returns HTTP 503 when degradation level ≥ 4, enabling load balancer integration.

**Management API Authentication:** The management API (`/api/*`) requires authentication via the same bearer token as the main API, scoped to `admin.*` permissions. Rate limiting: 60 requests/minute for management endpoints. The `127.0.0.1` bind is enforced by default (not just a template) — remote management API access requires explicit `[api.management.bind] = '0.0.0.0'` with a `blufio doctor` security warning.

### 8.10 Alert System

Alerts are deduplicated and routed by severity:

| Severity | Examples | Default Behavior |
|---|---|---|
| Critical | Disk full, all providers down | All channels immediately |
| High | Budget exceeded, auth failures | Primary channel within 1 minute |
| Medium | Provider circuit opened, tool failures | Digest every 15 minutes |
| Low | Rate limits, cache misses | Daily summary |

### 8.11 Webhook Retry & Dead Letter

Webhook retries follow exponential backoff: 5s → 30s → 5m → 30m → 2h. Maximum 5 retry attempts. After exhausting retries, the event is moved to a dead-letter table (`webhook_dead_letters`) and the operator is notified via the configured alert channel. Dead-letter events can be manually retried via `blufio webhook retry --all-dead-letter` or inspected via `blufio webhook dead-letter list`.

```toml
[alerts]
degradation_change = true
budget_threshold_percent = 80
disk_usage_threshold_percent = 90

[alerts.channels]
telegram = { chat_id = "8224079048" }
```

---

## 9. Community & Ecosystem

### 9.1 Guiding Principle

The plugin architecture means Blufio's ecosystem grows in two dimensions: **skills** (what the agent can do) and **plugins** (how the agent connects). A community contributor can add Matrix support without touching core code — they implement `ChannelAdapter` in a standalone crate, publish it to the plugin registry, and any operator can install it. This dramatically lowers the barrier to ecosystem contribution.

Blufio's ecosystem strategy optimizes for **trust over growth**. An ecosystem of 500 verified, audited skills is worth more than 5,700 unvetted ones. Every design decision prioritizes security and reliability over star counts.

### 9.2 Skill Registry

The Blufio skill registry follows a curated distribution model.

**License Policy:** All skills must declare their license in the manifest (`license = "MIT"` in skill.toml). The registry rejects skills without a declared license. AGPL and other copyleft licenses trigger a prominent warning during `blufio skill install`. Operators can configure `[skills.allowed_licenses]` to restrict which licenses are permitted.

**Namespace Policy:** Skills use a namespaced identifier: `@author/skill-name`. Verified authors (via GitHub/email verification) claim their namespace. Unverified authors publish under `community/skill-name`. Popular names (`web-search`, `browser`, `memory`) are reserved for first-party or verified skills. Disputes follow a DMCA-style takedown process.

```
Submit (signed) → Automated Analysis → Human Review (new authors) → Published (signed, versioned)
                                                                        ↓
                                                                 Post-Publication Monitoring
```

**Automated analysis pipeline:**
1. **Static analysis** — malicious patterns, permission/code mismatch, embedded secrets, dependency audit (RustSec)
2. **Behavioral sandbox testing** — execute in isolated Wasmtime sandbox with synthetic context; capture and verify network traffic against declared permissions. This is a **first-pass filter, not a security guarantee**. Automated analysis cannot catch all malicious behavior, especially time-delayed or conditional payloads.
3. **Differential analysis** — for updates, flag new permission requests and behavioral changes
4. **Manual review** — required for skills requesting sensitive capabilities (`exec`, `memory.write`, broad network access) regardless of author reputation

### 9.3 Governance

**Security Response:**

Initial security response is handled by core maintainers. A formal Security Response Team (SRT) with dedicated members, 24-hour response SLAs, and quarterly security reports is aspirational — to be established when the project has sufficient funding and community size to sustain it.

Core maintainers have authority to unpublish skills and revoke author keys in emergencies.

**Bug Bounty Program:**

> **Note:** The bug bounty program is **aspirational for when the project has funding**. Initial security vulnerability reports should be submitted via responsible disclosure to core maintainers. Payouts below are target ranges for a funded program.

| Severity | Scope | Target Payout |
|---|---|---|
| Critical | RCE, sandbox escape, auth bypass | $5,000–$15,000 |
| High | Data exfiltration, privilege escalation | $1,000–$5,000 |
| Medium | Info disclosure, DoS, permission bypass | $250–$1,000 |
| Low | UI issues, non-sensitive leaks | $50–$250 |

### 9.4 Enterprise Features

- **SSO** — SAML 2.0, OIDC, SCIM for automated provisioning
- **RBAC** — Four built-in roles (`admin`, `operator`, `user`, `viewer`) with compile-time permission enforcement via proc macros
- **Audit logging** — Append-only SQLite, immutable records, SIEM export (CEF, JSON Lines, Syslog)
- **Compliance evidence** — The `compliance evidence-report` command generates a technical controls inventory — NOT a SOC 2 report. It documents: encryption status, access logging configuration, credential management practices, and backup status. A SOC 2 audit requires organizational controls (HR policies, access reviews, incident response procedures, vendor management) that are outside Blufio's scope. The output is evidence for an auditor, not a compliance certification. Renamed from `soc2-report` to `evidence-report` to avoid misleading operators.
- **Secure defaults** — Auth required by default, refuses to bind `0.0.0.0` without explicit `--expose` flag

### 9.5 Plugin SDK

**SDK Publication:** `blufio_sdk` is published to crates.io with independent semver versioning. Compatibility guarantee: SDK minor version bumps are backwards-compatible for at least 2 Blufio minor versions. MSRV (minimum supported Rust version) tracks Blufio's MSRV minus one release. Breaking changes require a major version bump with a 60-day deprecation notice.

When an SDK breaking change is unavoidable (major version bump): (a) the old SDK version continues to work for 2 Blufio minor versions (deprecation window), (b) `blufio skill check <path>` validates a skill against the current SDK and reports breaking changes with migration hints, (c) the registry flags skills built against deprecated SDK versions with a warning, (d) after the deprecation window, incompatible skills are delisted (not deleted — authors can update and republish).

When writing a skill, the `description` field in `skill.toml` is the most important line you write. It determines whether the agent discovers your skill. Guidelines: (a) Start with the action verb: 'Search the web...', 'Create GitHub issues...', 'Generate diagrams...'. (b) Include trigger phrases: 'Use when user asks to look something up'. (c) Include NOT-for phrases: 'NOT for: complex web UI interactions'. (d) Keep it under 200 characters. The agent sees this description in every turn — make it count.

For Rust-native skills:

```rust
use blufio_sdk::prelude::*;

#[blufio_skill(
    name = "weather",
    version = "1.0.0",
    permissions = [Network("api.openweathermap.org")]
)]
pub struct WeatherSkill { api_key: Secret<String> }

#[skill_impl]
impl WeatherSkill {
    #[tool(description = "Get current weather for a location")]
    async fn get_weather(&self, #[param(description = "City name")] city: String) -> Result<WeatherResponse> {
        let resp = self.http().get(&format!("https://api.openweathermap.org/...?q={}", city)).send().await?;
        Ok(resp.json().await?)
    }
}
```

For non-Rust skills:
- **WASM** — Compile from Rust, Go, C, Python (via componentize-py)
- **Process** — Any language via JSON-RPC over stdin/stdout (MCP-compatible)
- **Container** — OCI containers for complex dependency requirements

### 9.6 Extension Points

| Extension | Mechanism | Documentation |
|---|---|---|
| New channel | Implement `Channel` trait, add TOML config | Channel Adapter Guide |

A 'How to Contribute a Channel Adapter' guide ships with Phase 1 docs. Contents: (a) implementing the `Channel` trait (8 methods), (b) capabilities manifest, (c) format degradation rules, (d) reconnection + rate limiting, (e) testing with the mock channel harness, (f) a worked example building a Matrix adapter step-by-step. The guide is the primary onboarding path for channel contributors.
| New tool | Implement `Tool` trait or publish as MCP server | Tool Provider Guide |
| New LLM provider | Implement `Provider` trait, select wire protocol | Provider Integration Guide |
| Custom memory backend | Implement `MemoryBackend` trait | Memory Backend Guide |
| Lifecycle hooks | Register shell scripts or Rust hook handlers | Plugin Hooks Guide |
| Custom skill | Publish as WASM, process, or container | Skill Development Kit |

### 9.7 Attribution & Licensing

`blufio --licenses` prints all third-party dependency licenses and attribution notices. A `NOTICE.txt` file is bundled alongside the binary in every distribution (tarball, Docker image, package). The file is auto-generated from `cargo-about` in CI, listing: crate name, version, license, and copyright holders. This satisfies Apache-2.0 and BSD attribution requirements for binary redistribution.

### 9.8 Roadmap: Browser Extension

Browser relay/extension (equivalent to OpenClaw's browser integration) is a post-v1.0 feature tracked in the roadmap. Phase 5 includes a basic browser extension that connects to the Blufio gateway via WebSocket, enabling browser-based tool execution and tab interaction.

### 9.9 Community Growth Strategy

- **Contributor documentation** — architecture guide, dev setup, coding standards, PR checklist
- **Skill author walkthrough** — The operator docs include a 'Your First Skill' tutorial: `blufio skill init --lang python 'my-skill'` → edit handler → `blufio skill test` (local sandbox run) → `blufio skill sign --key ~/.blufio/author.key` → `blufio skill publish`. The tutorial takes ~30 minutes and produces a published, signed skill. Video walkthrough planned for Phase 2 launch.
- **Skill dev hot-reload** — `blufio skill dev <path>` starts a local development server with hot-reload. File changes trigger automatic re-test against the last input. Output is streamed to the terminal. For WASM skills, recompilation happens automatically (requires wasm-pack). For Script skills, the subprocess restarts on file change. This is the primary development loop — `blufio skill test` is for one-shot validation, `blufio skill dev` is for iterative work.
- **Plugin scaffold** — `blufio plugin new my-plugin` generates Cargo project with trait stubs and tests
- **Documentation site** — auto-generated from Rust doc comments, searchable, versioned, available offline
- **RFC process** — major changes require RFC with 14-day comment period
- **Transparent governance** — published meeting notes, quarterly financial reports if funded

---

## Appendix: Key Differences from OpenClaw

| Area | OpenClaw (TypeScript) | Blufio (Rust) |
|---|---|---|
| Channel interface | Ad-hoc per channel | Unified `Channel` trait with typed capabilities |
| Format degradation | None (LLM must remember per-platform rules) | Automatic via capability-aware renderer (pulldown-cmark AST) |
| WhatsApp | Baileys (unofficial, 2–5% ban rate) | Business API (official, requires Meta verification) |
| Plugin execution | Same process, full host access | Three tiers: native (trusted only), WASM sandbox, subprocess |
| Skill security | No vetting, no signing, no sandboxing | Ed25519 signing, capability-based sandbox, automated scanning + manual review |
| Hook ordering | Undefined (filesystem-dependent) | Deterministic via `BTreeMap<HookPriority>` |
| Cost tracking | Model inference only | 10+ categories with independent host-side cross-checking |
| Budget enforcement | None | Daily/monthly caps, per-feature limits, soft/hard limits, model downgrade on budget |
| Error handling | Empty `catch {}` blocks | Typed `Result<T, AgentError>` everywhere; compiler-enforced |
| Circuit breakers | None | Per-dependency with configurable thresholds |
| Crash recovery | JSONL files may corrupt on crash | SQLite WAL — atomic transactions, automatic recovery |
| Metrics export | None | Prometheus `/metrics` with 20+ metrics |
| Distributed tracing | None | OpenTelemetry (optional, disabled by default) with trace_id propagation |
| New channel dev time | ~1 week, ~2000 lines | ~1–2 weeks, ~500–1500 lines (trait-guided, platform-dependent) |
