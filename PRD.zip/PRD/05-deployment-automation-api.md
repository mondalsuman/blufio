# Blufio PRD — Section 5: Deployment, Automation & API

> **Product:** Blufio — Rust + Shell AI Agent Platform  
> **Document:** PRD Section 5 of 5  
> **Version:** 2.0  
> **Date:** 2026-02-28  
> **Status:** Draft  
> **Replaces:** OpenClaw (TypeScript)

---

## Table of Contents

1. [Shell Automation Layer](#1-shell-automation-layer)
2. [systemd Integration](#2-systemd-integration)
3. [Cron & Scheduled Tasks](#3-cron--scheduled-tasks)
4. [Deployment Models](#4-deployment-models)
5. [HTTP API Design](#5-http-api-design)
6. [CLI Interface](#6-cli-interface)
7. [Backup & Recovery](#7-backup--recovery)
8. [Migration from OpenClaw](#8-migration-from-openclaw)
9. [Node System](#9-node-system)
10. [Operational Runbooks](#10-operational-runbooks)
11. [Performance & Scalability](#11-performance--scalability)
12. [Implementation Roadmap](#12-implementation-roadmap)

---

## 1. Shell Automation Layer

### 1.1 Design Philosophy

Blufio enforces strict separation between the binary and its operational environment:

| Layer | Responsibility | Technology |
|-------|---------------|------------|
| **Core binary** | AI inference, messaging, tool execution, database | Rust (`blufio`) |
| **Shell scripts** | Lifecycle, backup, monitoring, updates, hooks | Bash + systemd |
| **Config files** | All tunable behavior | TOML (validated at startup) |

The binary exposes a CLI and an HTTP API. Shell scripts consume both. The binary never manages its own lifecycle — that is systemd's job.

**Unix philosophy principles:**

- **Debuggability** — `bash -x script.sh` beats stepping through async Rust
- **Replaceability** — operators can swap any shell script without touching the binary
- **Survivability** — systemd timers fire even when the binary is crashed
- **Auditability** — every operational script is a file on disk, version-controllable
- **Composability** — pipe JSON, use `jq`, chain scripts — standard Unix tooling

### 1.2 Hook System

Hooks inject custom operator logic at key lifecycle points without modifying the binary.

**Configuration:**

```toml
# /etc/blufio/config.toml
[hooks]
on_message_received = "/etc/blufio/hooks/on-message.sh"
on_tool_call        = "/etc/blufio/hooks/on-tool-call.sh"
on_session_start    = "/etc/blufio/hooks/on-session-start.sh"
on_error            = "/etc/blufio/hooks/on-error.sh"
on_response         = "/etc/blufio/hooks/on-response.sh"

[hooks.settings]
timeout_secs = 5
default_mode = "async"  # async = non-blocking, sync = blocks until complete
```

**Execution model:**

```
Message arrives
    │
    ▼
[on_message_received] ──(exit 1)──► Message dropped
    │ (exit 0)
    ▼
Agent processes message
    │
    ▼
[on_tool_call] ──(exit 1)──► Tool blocked, agent gets error
    │ (exit 0)
    ▼
Tool executes → [on_response] → Response sent
```

Hook contracts:
- **Input:** JSON on stdin (context-specific payload)
- **Output:** stdout/stderr logged to journal
- **Exit code:** 0 = allow/continue, non-zero = block/reject (sync hooks)
- **Timeout:** killed with SIGTERM then SIGKILL after `timeout_secs`
- **Isolation:** separate process, no access to agent memory

**Security note:** Hook scripts receive context data (user messages, tool parameters, session info) on stdin. Operators must ensure hook scripts do not log sensitive data to world-readable locations.

**Example — tool call audit hook:**

```bash
#!/bin/bash
# /etc/blufio/hooks/on-tool-call.sh
set -euo pipefail

INPUT=$(cat)
TOOL=$(echo "$INPUT" | jq -r '.tool')
SESSION=$(echo "$INPUT" | jq -r '.session_id')

# Audit log (ensure /var/log/blufio/ is mode 0750)
echo "$(date -Iseconds) session=${SESSION} tool=${TOOL} params=$(echo "$INPUT" | jq -c '.params')" \
    >> /var/log/blufio/tool-audit.log

# Block dangerous commands
case "$TOOL" in
    exec)
        CMD=$(echo "$INPUT" | jq -r '.params.command // ""')
        if echo "$CMD" | grep -qE '(rm -rf /|mkfs|dd if=)'; then
            echo "BLOCKED: $CMD" >&2
            exit 1
        fi
        ;;
esac
exit 0
```

### 1.3 Secret Management

```bash
# /etc/blufio/env (mode 0600, owned by blufio:blufio)
# Loaded by systemd EnvironmentFile directive
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
TELEGRAM_BOT_TOKEN=123456:ABC-...
```

Secrets live in environment variables, never in `config.toml`. The config file is safe to version-control. For advanced setups, an `ExecStartPre` script can pull secrets from HashiCorp Vault or AWS Secrets Manager before the binary starts.

**Note:** Environment variables are visible via `/proc/<pid>/environ` and container inspection tools. For higher-security deployments, consider systemd's `LoadCredentialEncrypted` or an external secret manager with runtime injection.

The default systemd unit uses `LoadCredentialEncrypted=vault-key:/etc/credstore.encrypted/blufio-vault-key` — NOT `EnvironmentFile`. The env var path exists for development only and triggers a `blufio doctor` critical warning in production. Docker deployments use Docker secrets or tmpfs mounts by default.

---

## 2. systemd Integration

### 2.1 Main Service Unit

```ini
# /etc/systemd/system/blufio.service
[Unit]
Description=Blufio AI Agent
Documentation=https://docs.blufio.dev
After=network-online.target
Wants=network-online.target

[Service]
Type=notify
ExecStart=/usr/local/bin/blufio serve \
    --config /etc/blufio/config.toml
ExecReload=/bin/kill -HUP $MAINPID

Restart=always
RestartSec=5
StartLimitIntervalSec=300
StartLimitBurst=5

WatchdogSec=30

# --- Resource Limits ---
MemoryMax=512M
MemoryHigh=384M
CPUQuota=200%

# --- Security Hardening ---
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/blufio /var/log/blufio
PrivateTmp=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictNamespaces=true
RestrictRealtime=true
SystemCallFilter=@system-service
SystemCallErrorNumber=EPERM

# --- Environment ---
User=blufio
Group=blufio
WorkingDirectory=/var/lib/blufio
EnvironmentFile=-/etc/blufio/env
StandardOutput=journal
StandardError=journal
SyslogIdentifier=blufio

[Install]
WantedBy=multi-user.target
```

### 2.2 Key systemd Features

| Feature | Purpose |
|---------|---------|
| `Type=notify` | Binary calls `sd_notify(READY=1)` after init; systemd waits before marking "active" |
| `WatchdogSec=30` | Binary must ping every 15s or get killed — catches deadlocks, infinite loops |
| `MemoryMax=512M` | Hard cgroup v2 ceiling — OOM-killed if exceeded |
| `CPUQuota=200%` | Max 2 CPU cores — prevents runaway tool execution from starving the host |
| `ExecReload` + SIGHUP | Hot-reload safe config keys (log level, rate limits, hooks) without restart |
| `StartLimitBurst=5` | Circuit breaker: stop retrying after 5 crashes in 5 minutes |
| `ProtectSystem=strict` | Read-only filesystem except explicitly allowed paths |
| `SystemCallFilter` | Seccomp: only allow system-service syscalls |

**Watchdog and long operations:** Long-running operations (database migrations, backups, model loading) use `spawn_blocking` tasks with independent watchdog pings. The main async loop continues pinging the watchdog while blocking work runs on dedicated threads, preventing spurious watchdog kills.

### 2.3 sd_notify Integration (Rust)

```rust
use sd_notify::NotifyState;

async fn main_loop(config: &Config) -> Result<()> {
    init_all(&config).await?;
    sd_notify::notify(true, &[NotifyState::Ready])?;

    loop {
        tokio::select! {
            msg = channel_rx.recv() => handle_message(msg).await?,
            _ = signal::ctrl_c() => break,
            _ = tokio::time::sleep(Duration::from_secs(15)) => {
                sd_notify::notify(false, &[NotifyState::Watchdog])?;
            }
        }
    }

    sd_notify::notify(true, &[NotifyState::Stopping])?;
    shutdown_all().await?;
    Ok(())
}
```

### 2.4 Multi-Instance Template

For running multiple agent personalities on one host:

```ini
# /etc/systemd/system/blufio@.service
[Unit]
Description=Blufio AI Agent (%i)
After=network-online.target

[Service]
Type=notify
ExecStart=/usr/local/bin/blufio serve \
    --config /etc/blufio/%i/config.toml
ExecReload=/bin/kill -HUP $MAINPID
Restart=always
RestartSec=5
WatchdogSec=30
User=blufio
EnvironmentFile=/etc/blufio/%i/env
WorkingDirectory=/var/lib/blufio/%i
MemoryMax=512M
CPUQuota=100%
ProtectSystem=strict
ReadWritePaths=/var/lib/blufio/%i /var/log/blufio/%i
StandardOutput=journal
SyslogIdentifier=blufio-%i

[Install]
WantedBy=multi-user.target
```

```bash
# Run multiple agents — each with isolated config, database, logs, secrets
systemctl start blufio@sage
systemctl start blufio@crusher
systemctl start blufio@pixie

# Memory: 3 × 60-100MB = 180-300MB total
# (OpenClaw: 3 × 300-500MB = 900-1500MB)
```

> ⚠️ **Known Limitation:** Each instance loads its own 80MB embedding model. Running 3-5 agents on one host costs 240-400MB just for model weights. Shared model loading via a local embedding service (single model, HTTP API) is planned for v1.3.

---

## 3. Cron & Scheduled Tasks

### 3.1 systemd Timers Replace In-Process Cron

All recurring tasks use systemd timers instead of in-process scheduling. The binary is **invoked**, never self-scheduling.

| Feature | In-process cron (OpenClaw) | systemd timers (Blufio) |
|---------|---------------------------|-------------------------|
| Survives binary crash | ❌ | ✅ |
| Catches up on missed runs | ❌ | ✅ `Persistent=true` |
| Built-in logging | ❌ Custom | ✅ `journalctl` |
| List all jobs | ❌ Custom API | ✅ `systemctl list-timers` |
| Token cost per tick | ❌ Full prompt (~20K tokens) | ✅ Zero (smart pre-check) |
| Resource limits | ❌ Shares process | ✅ Separate cgroup per oneshot |
| Failure isolation | ❌ Can crash main | ✅ Isolated |

### 3.2 Default Timer Units

**Heartbeat (every 30 minutes):**

```ini
# /etc/systemd/system/blufio-heartbeat.timer
[Unit]
Description=Blufio heartbeat check

[Timer]
OnCalendar=*:0/30
Persistent=true
AccuracySec=1min
RandomizedDelaySec=30

[Install]
WantedBy=timers.target
```

```ini
# /etc/systemd/system/blufio-heartbeat.service
[Unit]
Description=Blufio heartbeat check

[Service]
Type=oneshot
ExecStart=/etc/blufio/scripts/smart-heartbeat.sh
User=blufio
Group=blufio
TimeoutStartSec=180
```

**Backup (daily at 3 AM):**

```ini
# /etc/systemd/system/blufio-backup.timer
[Timer]
OnCalendar=*-*-* 03:00:00
Persistent=true
```

**Cost alert (hourly):**

```ini
# /etc/systemd/system/blufio-cost-alert.timer
[Timer]
OnCalendar=hourly
Persistent=true
```

**Health check (every 5 minutes):**

```ini
# /etc/systemd/system/blufio-health.timer
[Timer]
OnCalendar=*:0/5
Persistent=false
```

**Cleanup (weekly):**

```ini
# /etc/systemd/system/blufio-cleanup.timer
[Timer]
OnCalendar=Sun *-*-* 04:00:00
Persistent=true
```

### 3.3 Smart Heartbeat (Zero-Token Pre-Check)

The key innovation over OpenClaw's heartbeat: a shell-based pre-check that costs zero LLM tokens when nothing needs attention.

```bash
#!/usr/bin/env bash
# /etc/blufio/scripts/smart-heartbeat.sh
set -euo pipefail

BLUFIO_URL="http://localhost:18789"
NEEDS_ATTENTION=false
REASONS=""

# Check 1: Pending messages
PENDING=$(curl -sf "${BLUFIO_URL}/api/pending-messages" | jq '.count // 0') || PENDING=0
[ "$PENDING" -gt 0 ] && NEEDS_ATTENTION=true && REASONS+="pending=$PENDING "

# Check 2: Pending notifications
NOTIF=$(curl -sf "${BLUFIO_URL}/api/notifications/pending" | jq '.count // 0') || NOTIF=0
[ "$NOTIF" -gt 0 ] && NEEDS_ATTENTION=true && REASONS+="notifications=$NOTIF "

# Check 3: HEARTBEAT.md exists with content
[ -s "/var/lib/blufio/workspace/HEARTBEAT.md" ] && NEEDS_ATTENTION=true && REASONS+="heartbeat_file "

# Check 4: Pending events on the event bus
EVENTS=$(curl -sf "${BLUFIO_URL}/api/events/pending" | jq '.count // 0') || EVENTS=0
[ "$EVENTS" -gt 0 ] && NEEDS_ATTENTION=true && REASONS+="events=$EVENTS "

if [ "$NEEDS_ATTENTION" = false ]; then
    echo "[$(date -u +%FT%TZ)] Heartbeat: nothing to do — skipping"
    exit 0
fi

echo "[$(date -u +%FT%TZ)] Heartbeat: ${REASONS}"
blufio send --session main --message "heartbeat check" \
    --metadata "{\"trigger\":\"heartbeat\",\"reasons\":\"${REASONS}\"}"
```

**Token savings:** OpenClaw wastes ~960K tokens/day on idle heartbeats (~$86/month at Sonnet pricing). Blufio's smart pre-check costs $0 when idle.

**Error handling:** The script differentiates between "API returned 0 pending" (normal) and "API unreachable" (error). When `curl` fails, the script writes to `/var/log/blufio/heartbeat-error.log` and optionally triggers a health alert via `blufio notify --channel operator`. Silent skip only occurs on confirmed zero-pending response. Failed `curl` calls default to 0 for the purpose of triggering LLM sessions, preventing false heartbeat triggers — but the failure is still logged separately.

### 3.4 TOML-Based Job Configuration

Jobs are declared in `config.toml`. The initial scheduler supports simple cron jobs only:

```toml
[automation]
enabled = true

[[automation.jobs]]
id = "heartbeat"
schedule = "*:0/30"
command = "/etc/blufio/scripts/smart-heartbeat.sh"
timeout_secs = 180
enabled = true

[[automation.jobs]]
id = "backup"
schedule = "*-*-* 03:00:00"
command = "/etc/blufio/scripts/backup.sh"
timeout_secs = 60

[[automation.jobs]]
id = "morning-briefing"
schedule = "*-*-* 08:00:00"
command = "blufio send --session main --message 'Good morning! Daily briefing time.'"
timeout_secs = 300
```

```bash
$ blufio cron generate
Generated systemd units:
  /etc/systemd/system/blufio-heartbeat.{timer,service}
  /etc/systemd/system/blufio-backup.{timer,service}
  /etc/systemd/system/blufio-morning-briefing.{timer,service}

Run: systemctl daemon-reload && systemctl enable --now blufio-heartbeat.timer ...
```

### 3.5 Job Run History

Every job execution is recorded in SQLite:

```sql
CREATE TABLE job_runs (
    id           TEXT PRIMARY KEY,
    job_id       TEXT NOT NULL,
    started_ms   INTEGER NOT NULL,
    completed_ms INTEGER,
    status       TEXT NOT NULL,      -- running, success, failed, timeout
    exit_code    INTEGER,
    output       TEXT,               -- stdout/stderr (truncated 10KB)
    cost_usd     REAL DEFAULT 0.0,
    duration_ms  INTEGER
);
CREATE INDEX idx_job_runs_job ON job_runs(job_id, started_ms);
```

### 3.6 Event Bus

Internal pub/sub for loose coupling between subsystems:

```rust
#[derive(Debug, Clone)]
pub enum EventKind {
    SessionStarted { session_id: String },
    SessionCompleted { session_id: String, tokens_used: u64, cost_usd: f64 },
    MessageReceived { channel: String, sender: String },
    NodeConnected { node_id: String, node_name: String },
    NodeDisconnected { node_id: String },
    BudgetWarning { scope: String, spent: f64, limit: f64 },
    BudgetExceeded { scope: String, spent: f64, limit: f64 },
    WebhookReceived { event: String, data: serde_json::Value },
    ConfigReloaded,
    HealthCheckFailed { reason: String },
}
```

Events are broadcast via `tokio::sync::broadcast` and persisted to SQLite for history. Subscribers (cost tracker, workflow engine, audit logger) react independently.

### 3.7 DAG Workflow Engine

DAG workflows are a v2.0 feature. The scheduler for v1.0 supports cron-style jobs only. See the roadmap for planned workflow capabilities.

---

## 4. Deployment Models

### 4.1 Single Binary Deployment

**Minimal install (default):**

```bash
curl -fsSL https://blufio.dev/install.sh | sh
# Ships with: Telegram + Anthropic + SQLite + local embedding + Prometheus
```

**Add channels:**

```bash
blufio plugin install channel-discord
blufio plugin install channel-slack
```

**Add providers:**

```bash
blufio plugin install provider-openai
blufio plugin install provider-ollama
```

**Custom config:**

```bash
blufio setup  # Interactive: asks for tokens, picks defaults for everything else
blufio serve  # Starts with installed plugins
```

The install script:
1. Detects OS and architecture
2. Downloads the single static binary (~40–60MB)
3. Downloads the corresponding Minisign signature file
4. Verifies the Ed25519 signature against a **pinned public key** embedded in the install script
5. Creates `blufio` user and directories
6. Generates default `config.toml` and `env` file
7. Installs systemd units and scripts
8. Enables timers

**Signing:** Binary is signed with Minisign (Ed25519). The install script verifies the signature against a pinned public key — not just a checksum downloaded from the same server. This provides supply-chain integrity even if the download server is partially compromised. Package manager distribution (apt, brew) is planned for post-v1.0.

**Install script security:** The install script is fetched over TLS, but TLS alone is insufficient — a compromised CDN could replace both the script and embedded public key. Mitigation: (a) the Minisign public key is published in the GitHub repo, project website, AND the install docs (multiple independent sources), (b) `blufio install --verify-key <key>` allows pinning the key from a trusted source, (c) GPG-signed apt repository ships in Phase 2 (`apt install blufio`), (d) Homebrew tap with formula checksums ships in Phase 2. The curl|sh path remains for convenience but is documented as the least-secure installation method.

**Package manager distribution:** `cargo install blufio` is supported from Phase 1 — the fastest path for Rust developers and early adopters. Additional distribution channels: (a) Phase 1: `curl|sh`, `cargo install`, GitHub Releases. (b) Phase 2: `apt install blufio` (GPG-signed repo), `brew install blufio` (Homebrew tap). (c) Community-maintained: Nix flake, Arch AUR, Fedora COPR. The project provides a `flake.nix` in the repo for Nix users from day 1.

The embedding model is NOT downloaded automatically on `blufio serve`. Instead, `blufio setup` (run after install, before first serve) handles model download with an explicit prompt: 'Download embedding model (~80MB) for semantic search? [Y/n]'. `blufio serve` without the model falls back to BM25 keyword search and logs a one-time notice. This prevents surprise downloads on metered connections and CI pipelines.

**Total footprint:**

```
/usr/local/bin/blufio             40-60MB  (the binary — includes wasmtime ~15MB, Candle, SQLCipher, all adapters, Tokio)
/etc/blufio/config.toml             2KB   (configuration)
/etc/blufio/env                   200B   (secrets)
/var/lib/blufio/blufio.db         varies  (data)
────────────────────────────────────────
Total: ~40-60MB + data
```

Compare: OpenClaw requires Node.js (~100MB) + node_modules (~150–200MB) = ~250–300MB before any data.

### 4.2 Cross-Compilation Targets

| Target | Architecture | Use Case |
|--------|-------------|----------|
| `x86_64-unknown-linux-musl` | x86_64 | Cloud VPS, desktops |
| `aarch64-unknown-linux-musl` | ARM64 | Raspberry Pi 4/5, Graviton, Apple Silicon VMs |
| `armv7-unknown-linux-musleabihf` | ARM32 | Raspberry Pi 3, older ARM SBCs |
| `x86_64-apple-darwin` | macOS Intel | Development (dynamic linking against system libs) |
| `aarch64-apple-darwin` | macOS ARM | Apple Silicon development (dynamic linking against system libs) |

> **⚠️ ARM32 Note:** ARM32 (armv7) builds ship without the local embedding model due to unverified Candle SIMD support on ARM32. These builds fall back to remote API embeddings only. ARM64 (aarch64) fully supports local embeddings.

Linux binaries are statically linked against musl — zero runtime dependencies. macOS binaries use dynamic linking against system libraries (standard for the platform):

```
$ file blufio
blufio: ELF 64-bit LSB executable, x86-64, statically linked, stripped

$ ldd blufio
        not a dynamic executable
```

### 4.3 Docker / OCI Images

```dockerfile
# Multi-stage build — final image FROM scratch
FROM rust:1.82-bookworm AS builder
WORKDIR /build
COPY . .
RUN rustup target add x86_64-unknown-linux-musl && \
    cargo build --release --target x86_64-unknown-linux-musl && \
    strip target/x86_64-unknown-linux-musl/release/blufio

FROM scratch
COPY --from=builder /build/target/x86_64-unknown-linux-musl/release/blufio /blufio
COPY --from=builder /etc/ssl/certs/ca-certificates.crt /etc/ssl/certs/
COPY --from=builder /usr/share/zoneinfo /usr/share/zoneinfo
EXPOSE 18789
VOLUME ["/var/lib/blufio", "/etc/blufio"]
ENTRYPOINT ["/blufio", "serve", "--config", "/etc/blufio/config.toml"]
```

**Image size: ~40–60MB** (FROM scratch — no OS, no shell, minimal attack surface).  
Compare: OpenClaw Docker image ~800MB.

Docker images reflect the plugin architecture:
- `blufio:minimal` — core + Telegram + Anthropic (~25MB)
- `blufio:standard` — core + Telegram + Discord + Anthropic + OpenAI + Ollama (~40MB)
- `blufio:full` — all official plugins (~55MB)
- Custom: `FROM blufio:minimal` + `RUN blufio plugin install channel-discord provider-openai`

The production image runs as a non-root user (`USER 65534:65534`). Health check uses the binary's built-in health endpoint (`HEALTHCHECK CMD ['/blufio', 'health']`). The HEALTHCHECK uses exec form (`["blufio", "status", "--json"]`) which works in FROM scratch because it doesn't invoke a shell — the kernel executes the binary directly. No /bin/sh required. The debug image (`blufio:debug`) is based on `gcr.io/distroless/cc-debian12`, includes CA certificates, timezone data, and is built alongside the production image in CI. Both images are published for every release.

**Multi-arch build:**

```bash
docker buildx build \
    --platform linux/amd64,linux/arm64 \
    -t ghcr.io/blufio/blufio:latest \
    --push .
```

**Docker Compose:**

```yaml
version: "3.9"
services:
  blufio:
    image: ghcr.io/blufio/blufio:latest
    container_name: blufio
    ports:
      - "127.0.0.1:18789:18789"
    volumes:
      - ./config.toml:/etc/blufio/config.toml:ro
      - blufio-data:/var/lib/blufio
    env_file:
      - .env
    deploy:
      resources:
        limits:
          memory: 512M
          cpus: "2.0"
    restart: unless-stopped
    healthcheck:
      test: ["/blufio", "health"]
      interval: 30s
      timeout: 5s
      retries: 3
      start_period: 10s

volumes:
  blufio-data:
```

### 4.4 Cloud Platforms

**fly.io:**

```toml
# fly.toml
app = "my-blufio"
primary_region = "fra"

[build]
  image = "ghcr.io/blufio/blufio:latest"

[mounts]
  source = "blufio_data"
  destination = "/var/lib/blufio"

[[services]]
  internal_port = 18789
  protocol = "tcp"
  [[services.ports]]
    port = 443
    handlers = ["tls", "http"]
  [[services.http_checks]]
    interval = 30000
    timeout = 5000
    path = "/health"

[vm]
  memory = "512mb"
  cpu_kind = "shared"
  cpus = 1
```

```bash
fly deploy
fly secrets set ANTHROPIC_API_KEY=sk-ant-... TELEGRAM_BOT_TOKEN=...
```

Cost: ~$5/month (shared-cpu-1x, 512MB). Blufio is comfortable in this footprint.

**Hetzner VPS (€4/month CX22):**

```bash
ssh root@my-server
curl -fsSL https://releases.blufio.dev/install.sh | sh
vim /etc/blufio/config.toml
vim /etc/blufio/env
systemctl start blufio
```

### 4.5 Raspberry Pi

Cross-compiled ARM64 binary works identically to x86:

```bash
scp blufio-aarch64 pi@raspberrypi:/usr/local/bin/blufio
# Then standard install — same systemd units, same scripts, same everything
```

**Resource usage on Pi 4 (2GB RAM):**

| Metric | Value |
|--------|-------|
| Memory (idle, no model) | ~30MB |
| Memory (with embedding model) | 50-80MB |
| CPU (idle) | <1% |
| Binary size | ~40-60MB |

Compare: OpenClaw uses 300-500MB RAM on Pi, leaving almost nothing for other services.

### 4.6 Offline / Air-Gapped Deployment

For air-gapped environments: `blufio bundle` creates a self-contained deployment package containing: the binary, embedding model weights, default skills, config templates, and systemd units. The bundle is a single `.tar.gz` (~120MB) that can be transferred to isolated networks and installed via `blufio install --from-bundle ./blufio-bundle.tar.gz`. No internet access required after bundle transfer. Model updates and skill installs in air-gapped mode use the bundle mechanism.

`blufio bundle` includes all installed plugins. For air-gapped environments: `blufio bundle --include-plugins channel-discord,provider-openai` creates a tarball with the binary + specified plugins + docs + embedding model. Extract and run — no internet needed.

The `blufio bundle` includes a `docs/` directory with the full operator documentation in HTML (generated from mdBook). Operators in air-gapped environments access docs locally: `blufio docs serve` starts a local HTTP server on port 18790 serving the bundled documentation.

### 4.7 CI/CD Pipeline

GitHub Actions workflows:

- **`ci.yml`**: build + test + clippy + cargo-deny + cargo-audit on every PR
- **`release.yml`**: tag → cross-compile (5 targets) → sign (Minisign + Sigstore/cosign) → GitHub Release → Docker push → SBOM generation
- Matrix builds: `linux-x86_64-musl`, `linux-aarch64-musl`, `macos-x86_64`, `macos-aarch64`, (future: `windows-x86_64-msvc`)

> **Windows native support:** A GitHub issue tracks native Windows support with a checklist of blockers: (a) Unix socket → named pipe for gateway, (b) systemd → Windows Service via `windows-service` crate, (c) file permission model differences, (d) signal handling (SIGTERM → Ctrl+C handler). Contributors interested in Windows support should follow this tracking issue. The codebase uses `#[cfg(unix)]` / `#[cfg(windows)]` gates from day 1 to keep the door open.

Windows is not a production target but contributor accessibility matters. Phase 2 adds CI testing on windows-latest (GitHub Actions) for the core crate and CLI. WSL2 is the recommended development environment — the install script detects WSL and adjusts accordingly. `cargo build` and `cargo test` work on native Windows for non-platform-specific crates. Platform-specific code (#[cfg(unix)]) compiles behind feature flags.
- `sccache` for build caching (CI builds target <10 min)
- Clippy gates: `deny(warnings)`, no `unwrap` on fallible paths (custom lint)
- `cargo-deny.toml`: enforces MIT/Apache-2.0/BSD license compatibility, blocks known advisories
- Dependabot for `Cargo.toml` + GitHub Actions version updates

**Commit convention:** Commit message format: Conventional Commits (`feat:`, `fix:`, `chore:`, `docs:`, `refactor:`, `test:`, `perf:`, `ci:`). Enforced via `commitlint` in CI. Scope is the crate name: `feat(gateway): add WebSocket backpressure`. Automated changelog generation via `git-cliff`. Release notes are auto-generated from commit history. A `pre-commit` hook validates commit format — installed via `blufio dev setup` for contributors.

**Changelog format:** Software release changelog follows Keep a Changelog format, auto-generated via `git-cliff` from Conventional Commits. Published at `CHANGELOG.md` in the repo root and on the GitHub Release page. Each release includes: Added, Changed, Deprecated, Removed, Fixed, Security sections.

**Signed release tags:** Release tags are GPG-signed by a maintainer: `git tag -s v0.1.0`. The CI release pipeline verifies tag signature before building. Maintainer GPG keys are published in the repo (`docs/maintainer-keys/`) and on keyservers. This is the root of trust — a compromised CI cannot forge a signed tag.

**CODEOWNERS:** `.github/CODEOWNERS` assigns review ownership: `crates/blufio-sandbox/**` → security team, `crates/blufio-channels/**` → channel maintainers, `crates/blufio-core/src/vault/**` → security team, `docs/rfcs/**` → all maintainers. Ensures sensitive code paths are reviewed by domain experts.

**Community health files:** GitHub community health files in `.github/`: `SECURITY.md`, `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, `SUPPORT.md` (where to get help), `FUNDING.yml` (GitHub Sponsors link), issue forms (YAML-based: bug report, feature request, security disclosure). These ship before the first public commit.

**Good first issues:** Pre-launch checklist: maintainers create 10+ good-first-issues before the first public commit. Examples: 'Add --format json to blufio status', 'Implement NO_COLOR support in CLI output', 'Add config validation for typo'd channel names', 'Write integration test for message round-trip'. Each issue includes: context, expected behavior, suggested approach, and links to relevant code. Tagged `good first issue` + `help wanted`.

**Architecture Decision Records:** ADRs use the format: `docs/adr/NNNN-title.md` with sections: Status (proposed/accepted/deprecated/superseded), Context, Decision, Consequences, Alternatives Considered. ADRs are public and linked from the relevant code via comments. New ADRs require a PR with 7-day comment period (shorter than RFCs). Maintainers create ADRs; contributors can propose via RFC.

**Testing strategy beyond unit + integration:**

(a) **Property-based testing** via `proptest` — fuzz the wire protocol parser, config deserializer, and context budget allocator with random inputs. (b) **Protocol fuzzing** — `cargo-fuzz` targets for WebSocket frame parsing and JSON-RPC message handling. (c) **Chaos testing** — test reconnection logic by injecting random disconnects, timeouts, and error responses in channel adapters during integration tests. (d) **Load testing** — `k6` or custom harness simulating 50+ concurrent sessions with realistic message patterns. Validates memory bounds, write contention, and queue throughput under pressure. (e) **Snapshot testing** — context engine output snapshots to catch unintended changes in prompt assembly. All test categories are tagged and runnable independently: `cargo test --features proptest`, `cargo test --features chaos`.

### 4.8 Reproducible Builds & Supply Chain Security

- `cargo-auditable` embeds dependency info in binary
- SLSA Level 2 provenance via GitHub Actions (`slsa-framework/slsa-github-generator`)
- SBOM in CycloneDX format via `cargo-cyclonedx`, attached to every GitHub Release
- Sigstore/cosign signatures alongside Minisign for transparency log integration (Rekor)

---

## 5. HTTP API Design

### 5.1 Management API

Base URL: `http://localhost:18789`

**Health & Status:**

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/health` | Health check (JSON) |
| `GET` | `/metrics` | Prometheus-compatible metrics |
| `GET` | `/api/status` | Full system status |

**Health response:**

```json
{
  "healthy": true,
  "uptime_secs": 86421,
  "version": "0.4.2",
  "database": { "status": "ok", "size_bytes": 52428800 },
  "channels": {
    "telegram": "connected",
    "discord": "connected"
  },
  "memory_bytes": 67108864,
  "active_sessions": 3,
  "last_message_secs_ago": 142,
  "budget": {
    "daily_spent": 5.54,
    "daily_limit": 10.00
  }
}
```

**Session Management:**

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/sessions` | List all sessions |
| `GET` | `/api/sessions/:id` | Get session details |
| `POST` | `/api/sessions/:id/send` | Inject message into session |
| `DELETE` | `/api/sessions/:id` | Close/archive session |

**Cron & Automation:**

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/cron/jobs` | List scheduled jobs |
| `POST` | `/api/cron/jobs/:id/trigger` | Manually trigger a job |
| `GET` | `/api/cron/runs` | Job run history |
| `GET` | `/api/events/pending` | Pending event bus events |
| `GET` | `/api/pending-messages` | Unprocessed message count |
| `GET` | `/api/notifications/pending` | Pending notification count |

**Configuration:**

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/config` | Current config (secrets redacted) |
| `POST` | `/api/config/reload` | Hot-reload config (SIGHUP) |
| `GET` | `/api/costs/today` | Today's cost breakdown |
| `GET` | `/api/costs/monthly` | Monthly cost breakdown |

### 5.2 OpenAI-Compatible Chat Completions

```
POST /v1/chat/completions
```

Provides OpenAI Chat Completions compatibility for core parameters:

| Parameter | Supported |
|-----------|-----------|
| `messages` | ✅ |
| `model` | ✅ |
| `temperature` | ✅ |
| `max_tokens` | ✅ |
| `tools` / `tool_choice` | ✅ |
| `stream` | ✅ (SSE) |
| `response_format` (JSON mode) | ✅ |

**Full parity with every OpenAI parameter is a non-goal.** Blufio supports the core parameter set that covers >95% of use cases. Exotic parameters (`logit_bias`, `logprobs`, `seed`, `parallel_tool_calls`, `stream_options`) are accepted but may be silently ignored depending on the backend provider.

| Feature | OpenClaw | Blufio |
|---------|----------|--------|
| SSE streaming | ❌ | ✅ (default) |
| Function calling (client-side) | ❌ | ✅ |
| Tool choice | ❌ | ✅ (`auto`, `none`, `required`, named) |
| JSON mode / structured output | ❌ | ✅ |
| Multi-modal input | ❌ | ✅ |
| Usage in response | ❌ | ✅ (token counts + cost) |

**Session management via headers:**

```
POST /v1/chat/completions
X-Session-Key: my-session-123
X-Session-TTL: 3600
```

**Agent routing via model field:**

- `agent:main` — route to specific agent
- `anthropic/claude-sonnet-4-20250514` — direct model access (requires `direct_model` scope)

### 5.3 OpenResponses Endpoint

```
POST /v1/responses
```

Semantic event streaming for agentic workflows:

```
event: response.created
data: {"id":"resp_abc","status":"in_progress"}

event: response.output_item.added
data: {"output_index":0,"item":{"type":"function_call","name":"web_search"}}

event: response.output_text.delta
data: {"output_index":1,"delta":"Here are the results..."}

event: response.completed
data: {"id":"resp_abc","status":"completed","usage":{...}}
```

**Note:** The OpenResponses API is an evolving specification. Blufio targets a stable subset of the protocol. Full parity with every OpenAI Responses API feature is not guaranteed and will track the upstream spec as it stabilizes.

### 5.4 Tools Invoke API

```
POST /v1/tools/invoke
{
  "tool": "web_search",
  "parameters": { "query": "rust async runtime" }
}
```

Direct tool execution bypassing the LLM. Supports streaming via SSE for long-running tools.

**Security:** The `exec` tool is **excluded from the API by default**. It must be explicitly allowed via configuration:

```toml
[api.dangerous_tools]
# Tools that require explicit opt-in for API access
allow = ["exec"]
# Even when allowed, exec requires an API key with the "tools.invoke:exec" scope
```

Without this configuration, any API call to `/v1/tools/invoke` with `tool: "exec"` returns `403 Forbidden`.

```
GET /v1/tools
```

Returns all available tools with JSON schemas (excluding dangerous tools unless the API key has appropriate scopes).

### 5.5 Webhook Management

```
POST /v1/webhooks
{
  "url": "https://app.example.com/events",
  "events": ["session.completed", "tool.error", "alert.critical"],
  "secret": "whsec_abc123"
}
```

Delivery: at-least-once with exponential backoff retry (5s → 30s → 5m → 30m → 2h). All payloads signed with HMAC-SHA256.

### 5.6 Batch Operations

```
POST /v1/batch
{
  "requests": [
    { "custom_id": "req-1", "method": "POST", "url": "/v1/chat/completions", "body": {...} },
    { "custom_id": "req-2", "method": "POST", "url": "/v1/chat/completions", "body": {...} }
  ]
}
```

Concurrent execution up to configurable limit (default 5). Results stored 24 hours.

**Batch error handling:** Batch responses use partial-success semantics: `{status: 'partial', results: [{id, status: 'ok', data}, {id, status: 'error', error: {code, message}}], summary: {total: 5, ok: 3, failed: 2}}`. Each item has an independent status. The batch endpoint returns HTTP 200 even on partial failure — the per-item status indicates individual outcomes. Failed items include retry-eligible flags.

### 5.7 Authentication & Rate Limiting

**Scoped API keys:**

```
POST /v1/api-keys
{
  "name": "CI Pipeline",
  "scopes": ["chat.completions", "tools.invoke:web_search"],
  "rate_limit": { "requests_per_minute": 60 },
  "expires_at": "2026-06-01T00:00:00Z"
}
```

**Rate limiting tiers:**

| Tier | Scope | Default |
|------|-------|---------|
| Global | All requests | 1000 req/min |
| Per-key | Each API key | Configured per key |
| Per-endpoint | Each endpoint | Varies |
| Per-session | Each session key | 30 req/min |

Rate limit state stored in SQLite (persists across restarts). Standard headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`.

**API Versioning:** The `/v1/` prefix is a stable contract. Breaking changes require a new version prefix (`/v2/`). Non-breaking additions (new optional fields, new endpoints) are added to the current version. Deprecation policy: deprecated endpoints return a `Sunset` header with the removal date (minimum 6 months notice). A `Blufio-API-Version` response header indicates the current version. The API changelog is published at `/v1/changelog` and in the operator docs.

**OpenAPI Specification:** An OpenAPI 3.1 specification is generated from the Rust route definitions (via `utoipa` or `aide`) and published with every release starting Phase 1. Available at `/v1/openapi.json` and in the docs. This enables client SDK generation from day 1, not Phase 5.

### 5.8 WebSocket Upgrade

```
GET /ws → Upgrade: websocket
```

Single WebSocket protocol with role-scoped connections:

```json
{
  "device_id": "abc-123",
  "role": "operator",
  "scopes": ["read", "write", "admin", "approvals"]
}
```

Or:

```json
{
  "device_id": "def-456",
  "role": "node",
  "node_name": "iphone",
  "platform": "iOS",
  "capabilities": ["camera", "location", "screen"]
}
```

A single device can hold both operator and node roles simultaneously via shared `device_id`.

### 5.9 Prometheus Metrics

```
GET /metrics

# HELP blufio_messages_total Total messages processed
# TYPE blufio_messages_total counter
blufio_messages_total{channel="telegram",direction="inbound"} 1423

# HELP blufio_tokens_total Total LLM tokens used
# TYPE blufio_tokens_total counter
blufio_tokens_total{model="claude-sonnet-4-20250514",type="input"} 2841920

# HELP blufio_cost_usd Total cost in USD
# TYPE blufio_cost_usd counter
blufio_cost_usd{model="claude-sonnet-4-20250514"} 4.23

# HELP blufio_tool_calls_total Total tool invocations
# TYPE blufio_tool_calls_total counter
blufio_tool_calls_total{tool="exec"} 312

# HELP blufio_response_duration_seconds LLM response time
# TYPE blufio_response_duration_seconds histogram
blufio_response_duration_seconds_bucket{le="1"} 423
blufio_response_duration_seconds_bucket{le="5"} 891

# HELP blufio_memory_bytes Process memory usage
# TYPE blufio_memory_bytes gauge
blufio_memory_bytes 67108864

# HELP blufio_active_sessions Current active sessions
# TYPE blufio_active_sessions gauge
blufio_active_sessions 3
```

---

## 6. CLI Interface

### 6.1 Top-Level Commands

```
blufio <subcommand> [options]

SUBCOMMANDS:
  serve          Start the agent daemon
  status         Show agent status and health
  health         Quick health check (exit code 0 = healthy)
  config         Configuration management
  sessions       Session management
  send           Send a message to a session
  cron           Scheduled job management
  costs          Cost tracking and budgets
  backup         Create a backup
  restore        Restore from backup
  db             Database management: `db migrate`, `db backup`, `db restore`, `db inspect`, `db export`
  vault          Credential vault management
  migrate        Migrate from OpenClaw
  import         Import data
  export         Export data
  doctor         Run diagnostic checks
  update         Self-update with rollback
  systemd        Generate systemd unit files
  scripts        Install operational scripts
  bench          Run built-in benchmarks
  privacy        Privacy and compliance tools
  plugin         Plugin management
    plugin list    List installed plugins (--type channel|provider|storage|embedding|obs|auth)
    plugin search  Search the plugin registry
    plugin install Install a plugin from registry or local path
    plugin remove  Remove an installed plugin
    plugin update  Update plugins (--all for all, or specific name)
    plugin info    Show plugin details, health, and config
  uninstall      Remove Blufio (binary, config, systemd units; data preserved unless --include-data/--purge)
  version        Print version info
```

### 6.2 Command Details

**`blufio serve`** — Start the daemon:

```bash
blufio serve --config /etc/blufio/config.toml
blufio serve --config /etc/blufio/config.toml --log-level debug
```

**`blufio status`** — System overview:

```
$ blufio status
Blufio v0.4.2 (x86_64-unknown-linux-musl)
Uptime:    3d 14h
Memory:    67MB / 512MB
Sessions:  3 active
Channels:
  telegram: ✅ connected (last msg: 2m ago)
  discord:  ✅ connected (last msg: 15m ago)
Budget:    $5.54 / $10.00 today (55%)
Timers:    5 active, next: heartbeat in 18min
```

**`blufio config`** — Configuration management:

```bash
blufio config init              # Generate default config.toml
blufio config lint              # Validate config
blufio config lint --strict     # Validate + warnings for recommended settings
blufio config dump              # Show resolved config (secrets redacted)
blufio config diff              # Diff current vs defaults
blufio config recipe personal   # Generate personal-use config template
blufio config recipe team       # Generate team config template
blufio config recipe production # Generate production config template
# Recipes now include plugin installation:
#   personal — Telegram + Anthropic (default, no plugins needed)
#   team — `blufio plugin install channel-discord provider-openai` + SQLCipher + cost budgets
#   production — all security plugins + monitoring + backup
#   iot — minimal, no embedding model, no plugins beyond core
blufio config reference         # Show auto-generated configuration reference
```

An auto-generated configuration reference ships with Phase 1. Generated from Rust struct doc comments and serde attributes via a build script, it documents every TOML field with type, default value, description, and example. Available via `blufio config reference` (CLI) and in the operator docs site.

**`blufio sessions`** — Session management:

```bash
blufio sessions list                        # List all sessions
blufio sessions list --format json          # JSON output
blufio sessions show <session-id>           # Session details
blufio sessions close <session-id>          # Close/archive
blufio sessions prune --older-than 30d      # Prune old sessions
```

**`blufio send`** — Inject message into session:

```bash
blufio send --session main --message "heartbeat check"
blufio send --session main --message "hello" --metadata '{"trigger":"manual"}'
```

**`blufio cron`** — Job management:

```bash
blufio cron list                            # List all jobs
blufio cron runs --job heartbeat --limit 10 # Recent runs
blufio cron trigger heartbeat               # Manual trigger
blufio cron add --id weekly-report \
    --schedule "Mon *-*-* 09:00" \
    --command "blufio send --session main --message 'Weekly report time'"
blufio cron remove weekly-report
blufio cron generate                        # Generate systemd units from config
```

**`blufio costs`** — Cost tracking:

```bash
blufio costs today                          # Today's total
blufio costs today --by-model               # Breakdown by model
blufio costs today --by-session             # Breakdown by session
blufio costs monthly                        # Month-to-date
blufio costs validate-pricing               # Validate pricing override file format
blufio costs validate-pricing --live        # Check against live provider pricing APIs (Anthropic, OpenAI); reports stale entries
```

**`blufio backup / restore`:**

```bash
blufio backup                               # Create backup to default location
blufio backup --to s3://bucket/blufio/      # Backup to S3
blufio restore /var/backups/blufio/blufio-20260228.db.gz
```

**`blufio db`** — Database operations:

```bash
blufio db check                             # Verify schema compatibility
blufio db migrate                           # Run pending migrations
blufio db integrity                         # Run PRAGMA integrity_check
blufio db inspect <table> [--row <id>]      # Render rows with decoded MessagePack as JSON
```

`blufio db inspect <table> [--row <id>]` — Renders database rows with decoded MessagePack fields as human-readable JSON. Essential for debugging encoded metadata, tool_calls, and attachment fields.

**`blufio doctor`** — Comprehensive diagnostics:

```
$ blufio doctor

🔍 Blufio Diagnostics
━━━━━━━━━━━━━━━━━━━━━

Binary
  ✅ Version: 0.4.2
  ✅ Architecture: x86_64-unknown-linux-musl
  ✅ Static binary (no dynamic deps)

Configuration
  ✅ /etc/blufio/config.toml: valid
  ✅ /etc/blufio/env: readable (mode 0600)
  ⚠️  OPENAI_API_KEY: not set (some features unavailable)

Database
  ✅ /var/lib/blufio/blufio.db: ok (52MB)
  ✅ PRAGMA integrity_check: ok
  ✅ WAL mode enabled

Channels
  ✅ telegram: token valid, webhook reachable
  ❌ discord: token not set (disabled in config)

Network
  ✅ api.anthropic.com: reachable (142ms)
  ✅ api.openai.com: reachable (89ms)

systemd
  ✅ blufio.service: active (running), PID 1234, uptime 2d 3h
  ✅ blufio-heartbeat.timer: active, next in 18min
  ✅ blufio-backup.timer: active, next in 10h

Disk
  ✅ /var/lib/blufio: 2.1GB free
  ✅ /var/backups/blufio: 12 backups, oldest 30 days

Budgets
  ✅ Daily: $5.54 / $10.00 (55%)
  ✅ Monthly: $48.11 / $100.00 (48%)

Recommendations
  → Set OPENAI_API_KEY for TTS and embedding features
```

`blufio doctor --format json` outputs machine-readable diagnostics for CI/CD integration and automated health monitoring. Schema: `{checks: [{name, status: pass|warn|fail, message, details?}], summary: {pass, warn, fail}}`.

**`blufio update`** — Safe self-update:

```bash
blufio update                    # Check and apply latest
blufio update --version 0.5.0   # Specific version
blufio update rollback           # Revert to previous version
```

Update flow: download → verify Minisign signature → validate config compatibility → check migrations → pre-update backup → swap binary → restart → health check → auto-rollback on failure.

**`blufio migrate`** — Migrate from OpenClaw:

```bash
blufio migrate --from-openclaw ~/.openclaw/
blufio migrate preview --from-openclaw ~/.openclaw/  # Dry run: shows what translates and what needs manual attention
```

**`blufio privacy`** — Privacy and compliance tools:

```bash
blufio privacy evidence-report                       # Generates technical controls evidence report
blufio privacy evidence-report --framework soc2       # SOC 2-focused evidence (does NOT constitute SOC 2 compliance)
blufio privacy evidence-report --framework hipaa      # HIPAA technical controls evidence
```

> **Important:** `blufio privacy evidence-report` generates a report of technical controls and their status. It does **not** constitute SOC 2 compliance, HIPAA compliance, or any regulatory certification. Compliance requires organizational controls, policies, training, and independent auditor review beyond what any CLI tool can provide.

### 6.3 Interactive Shell

**`blufio uninstall`** — Removal levels: (a) `blufio uninstall` — removes binary, systemd units, blufio user, config dir (`/etc/blufio/`), log dir (`/var/log/blufio/`). Database and workspace files are preserved. (b) `blufio uninstall --include-data` — also removes database dir (`/var/lib/blufio/`) and workspace files. (c) `blufio uninstall --purge` — complete wipe including backups, model cache, and skill cache. Each level prints what will be removed and requires confirmation.

`blufio shell` — Interactive REPL that connects to the running daemon via the Unix socket. Supports: sending messages as any session, inspecting session state, querying the cost ledger, triggering compaction, and running diagnostic queries against the SQLite database. Essential for operator debugging. Commands: `session list`, `session inspect <id>`, `cost summary`, `memory search <query>`, `queue status`, `config show`. Tab completion and command history via `rustyline`.

### 6.4 Update & Rollback

Every update preserves the previous binary at `/usr/local/bin/blufio.backup` and takes a pre-update database backup.

```bash
# Rollback to previous version
blufio update rollback
```

The backup binary and database snapshot are retained **until the next successful update**. There is no arbitrary time limit on rollbacks.

Blufio retains the last 3 update backups (binary + database). `blufio backup list` shows available rollback points. If the latest update AND its rollback both fail, the operator can restore from an earlier backup: `blufio update rollback --to <version>`. Manual cleanup: `blufio backup prune --keep 1`.

Database migrations run inside a transaction. On failure, the migration rolls back and the pre-migration backup remains available. Migrations are designed to be backward-compatible for at least one minor version. If a rollback requires schema changes, `blufio db migrate --down` handles it.

**Migration versioning:** Migrations use sequential numbering: `0001_initial.sql`, `0002_add_cost_ledger.sql`, etc. Each migration records its version in a `schema_version` table. Compatibility matrix: each Blufio release documents which schema versions it supports (e.g., v0.6 supports schema 8-12). `blufio db migrate --down` is supported for the last 3 migrations (up from 2) — older rollbacks require restoring from backup. For larger version jumps, the policy is 'backup before upgrade' — enforced: `blufio db migrate` refuses to run without a backup less than 1 hour old (override with `--skip-backup-check`). `blufio db backup` is automatically invoked before migration unless `--no-auto-backup` is set. Irreversible migrations are marked in their SQL (`-- irreversible: true`) and trigger an explicit confirmation prompt.

Manual rollback:

```bash
mv /usr/local/bin/blufio.backup /usr/local/bin/blufio
systemctl restart blufio
```

---

## 7. Backup & Recovery

### 7.1 SQLite Online Backup

SQLite's `.backup` API provides consistent, online backups without stopping the agent:

```bash
#!/bin/bash
# /etc/blufio/scripts/backup.sh
set -euo pipefail

BACKUP_DIR="/var/backups/blufio"
DB_PATH="/var/lib/blufio/blufio.db"
DATE=$(date +%Y%m%d-%H%M%S)
RETENTION_DAYS=30

mkdir -p "$BACKUP_DIR"

# Online backup — safe during concurrent writes
sqlite3 "$DB_PATH" ".backup '${BACKUP_DIR}/blufio-${DATE}.db'"

# Backup config alongside
cp /etc/blufio/config.toml "${BACKUP_DIR}/config-${DATE}.toml"

# Compress
gzip "${BACKUP_DIR}/blufio-${DATE}.db"
gzip "${BACKUP_DIR}/config-${DATE}.toml"

# Integrity check
TEMP=$(mktemp)
gunzip -c "${BACKUP_DIR}/blufio-${DATE}.db.gz" > "$TEMP"
RESULT=$(sqlite3 "$TEMP" "PRAGMA integrity_check;" 2>&1)
rm "$TEMP"

if [ "$RESULT" != "ok" ]; then
    echo "ERROR: Backup integrity check failed: $RESULT" >&2
    rm "${BACKUP_DIR}/blufio-${DATE}.db.gz"
    exit 1
fi

# Rotate old backups
find "$BACKUP_DIR" -name "*.gz" -mtime +${RETENTION_DAYS} -delete

SIZE=$(du -sh "${BACKUP_DIR}/blufio-${DATE}.db.gz" | cut -f1)
COUNT=$(find "$BACKUP_DIR" -name "blufio-*.db.gz" | wc -l)
echo "Backup complete: ${SIZE}, ${COUNT} backups retained"
```

### 7.2 Restore

```bash
#!/bin/bash
# /etc/blufio/scripts/restore.sh
set -euo pipefail

BACKUP_FILE=${1:?"Usage: restore.sh <backup.db.gz>"}
DB_PATH="/var/lib/blufio/blufio.db"

echo "⚠️  This will stop Blufio and replace the database."
read -p "Continue? (y/N) " -n 1 -r
echo
[[ $REPLY =~ ^[Yy]$ ]] || exit 0

systemctl stop blufio
cp "$DB_PATH" "${DB_PATH}.pre-restore"   # Safety net

gunzip -c "$BACKUP_FILE" > "$DB_PATH"
chown blufio:blufio "$DB_PATH"

RESULT=$(sqlite3 "$DB_PATH" "PRAGMA integrity_check;")
if [ "$RESULT" != "ok" ]; then
    echo "ERROR: Integrity check failed. Rolling back."
    mv "${DB_PATH}.pre-restore" "$DB_PATH"
    systemctl start blufio
    exit 1
fi

systemctl start blufio
echo "✅ Restored from $BACKUP_FILE"
```

### 7.3 Continuous Backup with Litestream

For zero-RPO deployments, Litestream provides continuous WAL-based backup replication to object storage:

```yaml
# /etc/litestream.yml
dbs:
  - path: /var/lib/blufio/blufio.db
    replicas:
      - url: s3://my-bucket/blufio/blufio.db
        retention: 720h  # 30 days
```

Replication lag: typically <1 second.

> **Important:** Litestream provides **continuous backup replication**, NOT read replicas. It is used for **disaster recovery** — restoring from the replica requires stopping the primary and copying the data back. It does not support live read scaling or concurrent query access to the replica while the primary is running. For scaling beyond a single instance, see the sharding strategy in Section 11.

### 7.4 Data Export

```bash
blufio export --format json > blufio-export.json
blufio export --sessions --format csv > sessions.csv
blufio export --costs --since 2026-01-01 --format json > costs.json
```

### 7.5 Comparison with OpenClaw

| Aspect | OpenClaw | Blufio |
|--------|----------|--------|
| Backup method | `cp -r ~/.openclaw/` (offline) | `sqlite3 .backup` (online) |
| Consistency | ❌ File-level (possible torn writes) | ✅ Page-level (SQLite guarantees) |
| Integrity verification | ❌ None | ✅ `PRAGMA integrity_check` |
| Backup size | Hundreds of MB (node_modules, logs) | Database only (~5-50MB compressed) |
| Continuous replication | ❌ | ✅ via Litestream (disaster recovery) |

---

## 8. Migration from OpenClaw

### 8.1 Migration Path

```bash
# Step 1: Export from OpenClaw
openclaw export --format json > openclaw-export.json

# Step 2: Install Blufio
curl -fsSL https://releases.blufio.dev/install.sh | sh

# Step 3: Preview migration (dry run)
blufio migrate preview --from-openclaw ~/.openclaw/
# Shows what translates automatically and what needs manual attention

# Step 4: Import data
blufio migrate --from-openclaw ~/.openclaw/

# Step 5: Transfer secrets
grep -E '(API_KEY|TOKEN|SECRET)' ~/.openclaw/.env >> /etc/blufio/env

# Step 6: Translate config
blufio config translate --from ~/.openclaw/config/default.json

# Step 7: Start and verify
systemctl start blufio
curl -s localhost:18789/health | jq

# Step 8 (optional): Run both in parallel
# Keep OpenClaw on a different port, point channels one at a time

# Step 9: Decommission OpenClaw
npm uninstall -g openclaw
```

### 8.2 What `blufio migrate` Does

1. **Session history** — Reads OpenClaw JSONL transcripts, converts to SQLite rows
2. **Cost history** — Imports token/cost records into the cost ledger
3. **Workspace files** — Copies AGENTS.md, SOUL.md, USER.md, memory/ to new workspace. `blufio migrate --from-openclaw` also imports workspace personality files: SOUL.md, AGENTS.md, USER.md, TOOLS.md, HEARTBEAT.md, TEAM-ROLES.md, TEAM-COMMS.md, MEMORY.md. These are copied to the Blufio workspace directory with format adjustments where needed (e.g., Blufio-specific config references). This preserves the agent's personality and operational context — arguably the most important files to carry over.
4. **Cron jobs** — Converts `~/.openclaw/cron/jobs.json` to systemd timer config
5. **Channel config** — Maps OpenClaw channel settings to Blufio TOML format
6. **Node pairings** — Imports paired device registrations

### 8.3 Config Translation

OpenClaw JSON5 → Blufio TOML mapping (automated):

```bash
$ blufio config translate --from ~/.openclaw/config/default.json
Translated configuration:
  channels.telegram.enabled    ← agents.defaults.channels.telegram.enabled
  channels.telegram.allowed_chats ← agents.defaults.channels.telegram.allowedChats
  providers.anthropic.default_model ← agents.defaults.model
  budgets.daily_usd           ← agents.defaults.budgets.daily
  ...

Written to /etc/blufio/config.toml
⚠️  Review and adjust — some settings have no direct equivalent.
```

`blufio migrate preview` provides a detailed report showing:
- Settings that translate directly (with the mapped key names)
- Settings that translate with caveats (semantics differ slightly)
- Settings that have **no equivalent** and require manual attention
- New Blufio settings with no OpenClaw counterpart (using defaults)

`blufio migrate preview --format json` outputs machine-readable results for CI/CD pipeline automation. Fields: `{translated: [...], manual_required: [...], unsupported: [...], warnings: [...]}`

### 8.4 OpenClaw Skill Migration

`blufio migrate --from-openclaw` explicitly does NOT migrate skills. OpenClaw skills are TypeScript/JavaScript and require manual porting. The migration guide includes: (a) a step-by-step 'Porting an OpenClaw Skill to Blufio Script Tier' tutorial, (b) a `blufio-openclaw-shim` that wraps JS skills via Node.js subprocess (Phase 4, no WASM sandbox), (c) a compatibility matrix showing which OpenClaw skill patterns map to which Blufio tier. Skills are called out as the primary migration friction point.

### 8.5 Migration Templates

Migration templates beyond OpenClaw: `blufio migrate from-langchain` (converts LangGraph agent configs), `blufio migrate from-autogpt` (imports AutoGPT settings and memory), `blufio migrate from-botpress` (converts Botpress flow configs to Blufio skills). Each template covers config translation, data import where possible, and a 'what's different' guide. Templates ship incrementally — OpenClaw in Phase 4, others community-contributed post-v1.0.

### 8.6 Gradual Rollover Strategy

For production deployments:

1. **Week 1:** Install Blufio, run import, verify data integrity
2. **Week 2:** Run Blufio in shadow mode alongside OpenClaw
3. **Week 3:** Switch one low-risk channel (e.g., stdio) to Blufio
4. **Week 4:** Switch primary channel (Telegram), keep OpenClaw as fallback
5. **Week 5:** Decommission OpenClaw after confirming stability

**Shadow mode** is simplified in v1.5: `blufio serve --shadow` starts the instance in read-only mode using the same bot token via long-polling (not webhooks). It processes messages in parallel with the production instance but discards responses to `/dev/null` while logging them. No separate bot token, no proxy script. `blufio migrate compare --shadow-log ./shadow.log --production-log ./production.log` produces the diff. This is a 10-minute setup, not a 5-week project.

---

## 9. Node System

### 9.1 Paired Nodes

Nodes are external devices (phones, IoT, Raspberry Pi) that extend the agent with physical capabilities:

| Capability | Description |
|------------|-------------|
| `camera` | Photo/video capture (front/back) |
| `screen` | Screenshot capture |
| `location` | GPS coordinates |
| `exec` | Remote command execution |
| `canvas` | UI rendering |
| `voice` | Audio I/O |

### 9.2 Node Connection Protocol

Single WebSocket protocol with role-based connections:

```json
{
  "device_id": "iphone-abc123",
  "role": "node",
  "node_name": "iphone",
  "platform": "iOS",
  "capabilities": ["camera", "location", "screen"]
}
```

### 9.3 Auto-Reconnection

Blufio's node client includes exponential backoff reconnection (missing from OpenClaw):

```rust
pub async fn maintain_connection(&self) -> ! {
    let mut backoff = Duration::from_secs(1);
    loop {
        match self.connect_and_run().await {
            Ok(()) => { backoff = Duration::from_secs(1); }
            Err(e) => {
                tracing::warn!(error = %e, backoff = ?backoff, "Reconnecting");
                tokio::time::sleep(backoff).await;
                backoff = (backoff * 2).min(self.max_backoff);
            }
        }
    }
}
```

### 9.4 Node Health Monitoring

```rust
pub struct NodeHeartbeat {
    pub battery_percent: Option<u8>,
    pub memory_used_mb: Option<u64>,
    pub memory_total_mb: Option<u64>,
    pub disk_free_mb: Option<u64>,
    pub cpu_load: Option<f32>,
    pub uptime_secs: u64,
}
```

The gateway tracks node health and publishes events:
- Stale connection detection (no heartbeat in 2 minutes)
- Low battery alerts (<10%)
- Disconnection/reconnection events

### 9.5 Node Fleet Management

```bash
# List all nodes
blufio nodes list
# DEVICE      NAME      PLATFORM  CONNECTED  BATTERY  LAST SEEN
# abc123      macbook   macOS     ✅          87%      2s ago
# def456      iphone    iOS       ✅          45%      15s ago
# ghi789      pi-cam    Linux     ❌          N/A      2h ago

# Node groups
blufio nodes group add home --nodes macbook,iphone,pi-cam
blufio nodes group add cameras --nodes iphone,pi-cam

# Multi-node commands
blufio nodes exec --group cameras camera snap --facing both
```

### 9.6 Approval Routing

Because Blufio uses a single WebSocket protocol (no Gateway/Bridge split like OpenClaw), approvals broadcast to all connected operators. First resolution wins. Prompts appear where the user is — macOS app, iOS app, or web dashboard.

---

## 10. Operational Runbooks

### 10.1 Common Tasks

| Task | Command |
|------|---------|
| Start agent | `systemctl start blufio` |
| Stop agent | `systemctl stop blufio` |
| Restart | `systemctl restart blufio` |
| Hot-reload config | `systemctl reload blufio` |
| Live logs | `journalctl -u blufio -f` |
| Errors only | `journalctl -u blufio -p err` |
| Structured JSON logs | `journalctl -u blufio -o json \| jq .` |
| Memory usage | `systemctl show blufio -p MemoryCurrent` |
| List timers | `systemctl list-timers 'blufio-*'` |
| Manual heartbeat | `blufio send --session main --message "heartbeat check"` |
| Health check | `curl -s localhost:18789/health \| jq` |
| Today's cost | `blufio costs today` |
| Backup now | `/etc/blufio/scripts/backup.sh` |
| Restore | `/etc/blufio/scripts/restore.sh <file>` |
| Update | `blufio update` |
| Validate config | `blufio config lint` |
| Diagnostics | `blufio doctor` |

### 10.2 Troubleshooting

```bash
# Agent won't start
journalctl -u blufio --since "5min ago" --no-pager
blufio config lint

# Memory growing
systemctl show blufio -p MemoryCurrent
blufio sessions list --format json | jq '.[].context_tokens'

# Not responding to messages
curl -s localhost:18789/health | jq '.channels'

# Crash loop
systemctl status blufio   # shows restart count
journalctl -u blufio -p err --since "1h ago"
systemctl reset-failed blufio

# High costs
blufio costs today --by-model
blufio costs today --by-session
```

### 10.3 Log Rotation

Primary logs go to journalctl (own rotation via `SystemMaxUse`). Supplementary file logs:

```
# /etc/logrotate.d/blufio
/var/log/blufio/*.log {
    daily
    rotate 14
    compress
    delaycompress
    missingok
    notifempty
    maxsize 100M
    postrotate
        systemctl reload blufio 2>/dev/null || true
    endscript
}
```

```ini
# /etc/systemd/journald.conf.d/blufio.conf
[Journal]
SystemMaxUse=1G
SystemKeepFree=2G
MaxRetentionSec=30day
```

### 10.4 Upgrade Procedure

```bash
# 1. Check current version
blufio version

# 2. Create backup (automatic during `blufio update`, but manual is fine too)
/etc/blufio/scripts/backup.sh

# 3. Update
blufio update --version 0.5.0
# Automatically: download → verify signature → config lint → migration check →
#   pre-update backup → swap → restart → health check

# 4. Verify
blufio status
curl -s localhost:18789/health | jq

# 5. Rollback if needed (backup retained until next successful update)
blufio update rollback
```

---

## 11. Performance & Scalability

### 11.1 Benchmark Targets

| Metric | OpenClaw (Node.js) | Blufio Target | Notes |
|--------|-------------------|---------------|-------|
| Cold start | 3-5s | 2–5 seconds | SQLCipher KDF, model loading, TLS handshakes |
| Hot restart | N/A | <500ms | Database already initialized, connections warm |
| Per-turn overhead (excl. LLM) | 100-800ms | 5-20ms | Local processing only; excludes LLM API latency (1-5s) |
| Memory (idle, no model) | 200-300MB | ~30MB | Before first embedding query if model loading deferred |
| Memory (idle, with model) | 200-300MB | 50-80MB | Embedding model loaded |
| Memory (10 sessions) | 400-500MB | 80-120MB | Scales with active session count |
| Memory bound | Unbounded (GC) | Configurable cap (default 512MB) | systemd `MemoryMax` enforced |
| Concurrent sessions | ~5 (event loop) | 10-50 per instance | Limited by provider API rate limits (typically 50-100 RPM) |
| Tool execution | Sequential | Parallel (40-70% latency reduction) | Via `tokio::spawn` |
| Prompt cache hit rate | 40-60% | 80-90% (target) | Requires stable prompt prefix discipline |
| Docker image | ~800MB | ~40-60MB | FROM scratch |

**On cold start:** The 2–5 seconds target accounts for real-world initialization costs: SQLCipher key derivation (~200ms at default iteration count), embedding model loading (1-2s for all-MiniLM-L6-v2 via Candle on CPU), and TLS handshake to channel APIs. Model loading can be deferred to first embedding query, reducing cold start to <1s at the cost of latency on the first memory search.

**On per-turn overhead:** The 5-20ms target measures **local processing only** — context assembly, memory retrieval, prompt formatting, token counting, and response routing. It explicitly excludes LLM API latency, which dominates total turn time at 1-5 seconds and is outside Blufio's control.

### 11.2 Key Optimizations

**Parallel tool execution:** Independent tool calls execute concurrently via `tokio::spawn`:

```rust
// 3 web searches (2s each): 6s sequential → 2s parallel
let results = futures::future::join_all(
    calls.iter().map(|call| tokio::spawn(execute_tool(call)))
).await;
```

**Worker threads for CPU work:** Image processing, JSON serialization, and compression offloaded to blocking threads — never blocking async I/O:

```rust
let resized = tokio::task::spawn_blocking(move || {
    image::load_from_memory(&data)?.resize(max, max, FilterType::Lanczos3)
}).await?;
```

**Cache-aligned prompt structure:** System prompt, tool schemas, and workspace files form a stable prefix that maximizes provider cache hits. Runtime metadata moves to the end — not the beginning.

**Memory-mapped workspace files:** `mmap` + platform-appropriate file watching (`inotify` on Linux, `FSEvents`/`kqueue` on macOS) for efficient reads with automatic invalidation.

**Pre-formatted transcripts:** Provider-specific formatting computed on write, not on read. No O(n) transcript hygiene pass per turn.

### 11.3 Memory Architecture

Bounded memory budget with pressure response:

```toml
[performance.memory]
max_memory_mb = 100
session_cache_mb = 30
tool_cache_mb = 10
embedding_cache_mb = 10
```

Pressure levels:
- **<70%:** Normal operation
- **70-85%:** Evict cold caches
- **85-95%:** Clear all caches, close idle sessions
- **>95%:** Reject new sessions, alert operator

### 11.4 Scaling Strategy

| Sessions | Strategy |
|----------|----------|
| 1-50 | Single instance, default config. 2 vCPU, 2GB RAM. |
| 50-200 | Tuned memory budget, increased worker threads. 4 vCPU, 4GB. |
| 200-1000 | Sharded multi-instance (separate databases per agent group). |
| 1000+ | Multi-node deployment with load balancing (separate design doc). |

> **Note on Litestream:** Litestream provides continuous backup replication, not read replicas. It cannot be used for live scaling. Scaling beyond a single instance requires sharding — running multiple Blufio instances with separate databases, each handling a subset of sessions/agents.

### 11.5 Built-in Benchmarking

```bash
blufio bench cold-start        # Startup time (full initialization)
blufio bench warm-turn         # Turn latency (excl. LLM)
blufio bench tool-heavy        # Parallel tool execution
blufio bench concurrent        # N concurrent sessions
blufio bench memory-pressure   # Behavior under memory pressure
```

Benchmarks run in CI on every merge. Regressions >10% fail the build. CI benchmarks run on a fixed instance type: GitHub Actions `ubuntu-latest` with 4 vCPU / 16GB RAM. Baseline values are calibrated to this hardware. Local benchmarks (`blufio bench`) auto-detect hardware tier and compare against the appropriate baseline.

`blufio bench` outputs: (a) per-test results with p50/p95/p99 latencies, (b) memory high-water mark, (c) comparison against baseline values for the hardware tier (auto-detected: `vps-2vcpu`, `vps-4vcpu`, `dedicated`). Output formats: `--format table` (default), `--format json`, `--format markdown`. CI uses `--format json` and fails the build if any metric regresses >10% from the previous release tag.

CI publishes benchmark results to a public dashboard (GitHub Pages) on every release tag. Historical trends are tracked. Claims like '5-20ms per-turn overhead' link to the specific benchmark run that validated them.

### 11.6 Blufio Cloud

Blufio Cloud (if pursued) would offer: (a) managed hosting with automatic updates, backups, and monitoring — operators pay for ops burden they'd otherwise handle themselves, (b) multi-region deployment for latency-sensitive use cases, (c) shared skill registry with higher rate limits, (d) team management UI. The value prop is operational convenience, not feature gating — self-hosted Blufio has 100% feature parity. This is a future consideration post-v1.0 and requires its own business plan.

### 11.7 Resource Budgets

| Component | Budget | Enforcement |
|-----------|--------|-------------|
| Total process | 512MB | systemd `MemoryMax` |
| Embedding model | 50-80MB | Loaded once, shared across sessions |
| Session cache | 30MB | LRU eviction |
| Tool result cache | 10MB | LRU eviction |
| HTTP buffers | 20MB | Bounded channels |
| Workspace files | 5MB | mmap (kernel manages) |
| Per-session | 0.5-2MB | Bounded context window |

---

## 12. Implementation Roadmap

A public GitHub Project board tracks the roadmap with issues tagged to phases. Quarterly milestones provide concrete checkpoints for contributors and users. The board is the canonical source of truth for 'what's next' — the PRD provides the design, the board tracks execution.

**Quarterly Milestones:**

| Quarter | Target |
|---------|--------|
| Q1 | Phase 1 complete (core + Telegram + CLI) |
| Q2 | Phase 2 complete (memory + vault + cron) |
| Q3–Q4 | Phase 3 (Discord + API + WASM) |
| Year 2 Q1–Q2 | Phase 4 (nodes + migration) |
| Year 2 Q3–Q4 | Phase 5 (polish + community) |

> **Timeline assumes 2-3 full-time developers.** Solo development extends each phase by ~50%.

> **Volunteer pace (unfunded, part-time contributors):** Each phase extends ~50-100%. Estimated total: 36-48 months. The Phase 1 core (gateway + Telegram + Anthropic + CLI) is achievable in 4-6 months at volunteer pace and represents the minimum viable release.

**Dual Timeline Roadmap:**

| Phase | Funded (2-3 devs) | Volunteer Pace |
|-------|-------------------|----------------|
| Phase 1a (MVP) | Months 1-2 | Months 1-5 |
| Phase 1b (hardening) | Months 3-4 | Months 6-9 |
| Phase 2 | Months 5-8 | Months 10-18 |
| Phase 3 | Months 9-13 | Months 19-30 |
| Phase 4 | Months 14-18 | Months 31-40 |
| Phase 5 | Months 19-24 | Months 41-48 |

### Phase 1: Core Platform (Months 1–4)

**MVP — the agent runs and responds to messages.**

- [ ] Single binary build pipeline (musl static linking, x86_64 + aarch64)
- [ ] TOML config with `deny_unknown_fields` validation
- [ ] SQLite + SQLCipher database with WAL mode
- [ ] systemd service unit with Type=notify, watchdog, security hardening
- [ ] Telegram channel adapter
- [ ] Anthropic provider adapter
- [ ] Basic context assembly (system prompt + conversation history)
- [ ] `blufio serve`, `blufio status`, `blufio config lint`
- [ ] `/health` endpoint
- [ ] Basic CLI: serve, status, config, send, doctor
- [ ] Install script (`curl | sh` with Minisign verification)
- [ ] Backup/restore scripts with integrity verification

**Exit criteria:** Agent receives Telegram message, processes with Claude, responds. Operator manages via systemctl + CLI. Backups run daily.

> **Phase 1 / Phase 2 plugin boundary:** Phase 1 ships with Telegram and Anthropic built into the binary (no plugin loading needed). The plugin host infrastructure (trait definitions, loading, registry client) ships in Phase 2. Phase 2 also extracts Telegram and Anthropic into plugins, proving the architecture works by dogfooding.

### Phase 2: Memory, Automation & Operations (Months 5–8)

**The agent remembers and runs itself.**

- [ ] Memory system with hybrid retrieval (BM25 + vector search)
- [ ] Embedding model integration (Candle, all-MiniLM-L6-v2)
- [ ] Memory compaction (L0→L1 summarization)
- [ ] Credential vault (AES-256-GCM encrypted secrets)
- [ ] systemd timer generation from TOML config
- [ ] Smart heartbeat with zero-token pre-check
- [ ] Cost tracking and alerting
- [ ] Budget enforcement (daily/monthly limits)
- [ ] Hook system (on_message, on_tool_call, on_error)
- [ ] `blufio cron`, `blufio backup`, `blufio costs`, `blufio doctor`
- [ ] `/metrics` Prometheus endpoint
- [ ] Log management (journalctl + logrotate)
- [ ] Safe update with Minisign verification and auto-rollback

**Exit criteria:** Agent has persistent memory across sessions. Heartbeats cost zero tokens when idle. Auto-restarts on crash. Alerts on budget overrun.

### Phase 3: API, Multi-Channel & Sandbox (Months 9–13)

**The agent is programmable and connects everywhere.**

- [ ] OpenAI-compatible `/v1/chat/completions` with SSE streaming
- [ ] OpenResponses `/v1/responses` (stable subset)
- [ ] Tools Invoke API `/v1/tools/invoke` (with dangerous tool restrictions)
- [ ] Scoped API keys with rate limiting
- [ ] Discord channel adapter
- [ ] WebSocket protocol with role-scoped connections
- [ ] Event bus with internal pub/sub
- [ ] WASM skill sandbox (wasmtime + capability manifests)
- [ ] Additional provider adapters (OpenAI, Google, Ollama)
- [ ] Docker image (FROM scratch + debug variant, multi-arch)
- [ ] Docker Compose template with Prometheus + Grafana

**Exit criteria:** External apps consume Blufio via standard OpenAI client libraries. Discord + Telegram active simultaneously. WASM skills execute in sandbox.

### Phase 4: Nodes, Migration & Expansion (Months 14–18)

**The agent controls devices and replaces OpenClaw.**

- [ ] Node WebSocket protocol with capabilities
- [ ] Node auto-reconnection with exponential backoff
- [ ] Node health monitoring and alerting
- [ ] Node fleet management CLI
- [ ] Multi-node commands (group exec)
- [ ] Camera, screen, location capability handlers
- [ ] OpenClaw migration tool (`blufio migrate --from-openclaw`)
- [ ] Config translation with preview (`blufio migrate preview`)
- [ ] Session history import
- [ ] Additional channel adapters (WhatsApp Business, Slack)
- [ ] Batch operations endpoint

**Exit criteria:** Existing OpenClaw users can migrate with preview + import. Phone nodes reconnect reliably. 4+ channels supported.

### Phase 5: Polish, Community & Scale (Months 19–24)

**Production-ready for demanding workloads.**

- [ ] Prompt cache alignment and warmth maintenance
- [ ] Parallel tool execution optimization
- [ ] Memory pressure response system
- [ ] Continuous benchmarking in CI
- [ ] MCP server consumption and serving
- [ ] OpenAPI spec auto-generation + documentation UI
- [ ] Client SDK generation (auto-generated from OpenAPI spec; hand-maintained SDKs based on community demand)
- [ ] Skill registry with code signing

The Blufio registry hosts both skills and plugins. The same signing, scanning, and review infrastructure applies. Plugins follow the same `plugin.toml` manifest format with additional fields: `adapter_type`, `min_blufio_version`, `plugin_api_version`. Registry URL: `registry.blufio.dev/plugins/`. `blufio plugin install` downloads from the registry by default; `blufio plugin install --path ./my-plugin` installs from a local directory for development.
- [ ] Trusted proxy authentication (Cloudflare Access, AWS ALB)
- [ ] Comprehensive test suite with integration tests
- [ ] Operational runbook documentation
- [ ] Community contributor guidelines and governance
- [ ] RFC process tooling (see below)
- [ ] Documentation site (mdBook) launch

**Exit criteria:** 50 concurrent sessions on a 4-vCPU host. Sub-5s cold start. Documented APIs with generated SDKs.

### Milestone Summary

| Milestone | Target | Definition |
|-----------|--------|------------|
| **Alpha** | Month 4 | Telegram bot working, systemd managed, backup/restore, basic CLI |
| **Beta** | Month 10 | Memory system, cost tracking, HTTP API, Discord, Docker images |
| **RC** | Month 16 | Node system, migration tool, 4+ channels, WASM sandbox |
| **v1.0** | Month 20 | Feature-complete, documented, migration-tested, skill registry |
| **v1.x** | Month 24 | Polish, community, scale testing, SDK ecosystem |

### RFC Process

RFCs live in the `docs/rfcs/` directory of the main repository as numbered markdown files (`0001-feature-name.md`). Discussion happens on the associated GitHub Pull Request. The 14-day comment period is enforced by a GitHub Actions bot that blocks merge before the window closes.

### Future Considerations

WebTransport (HTTP/3-based) for mobile node connectivity is a future consideration. HTTP/3's connection migration and 0-RTT would benefit mobile nodes that switch networks. Not in scope for v1.0 — evaluate when the ecosystem matures.

### Community & Contributor Experience

A simplified `ROADMAP.md` ships in the repo root — a 1-2 page overview linking to the full PRD. Contributors shouldn't need to read 12K lines to understand where the project is headed.

The project Discord/Matrix link appears in the first section of README.md, not buried in contributor docs. Community chat is the front door for new contributors.

`GOVERNANCE.md` defines: BDFL (project lead) with final decision authority, 'core maintainer' criteria (6+ months active contribution, 10+ merged PRs, domain expertise in at least one crate), and the path from contributor → committer → core maintainer. RFC/ADR approval requires one core maintainer sign-off (BDFL can override).

For single-commit PRs (typo fixes, doc improvements), the DCO sign-off requirement may be waived by a maintainer. The goal is to not deter casual contributions. For substantive code contributions, DCO remains required.

### Documentation Site Strategy

Documentation is split by audience:

- **(a)** `docs.rs/blufio_sdk` for the Rust API reference (auto-generated)
- **(b)** A dedicated operator docs site built with mdBook, versioned per release, and hosted at `docs.blufio.dev`

Operator docs cover installation, configuration, channel setup, skill development, and troubleshooting.

---

### Plugin Development

Creating a Blufio plugin:

1. `cargo new blufio-plugin-my-channel --lib`
2. Add `blufio-sdk` as a dependency (provides adapter traits)
3. Implement the appropriate trait (e.g., `ChannelAdapter`)
4. Export via `#[no_mangle] pub extern "C" fn blufio_plugin_init`
5. Create `plugin.toml` manifest
6. Test locally: `blufio plugin install --path ./target/release/`
7. Publish: `blufio plugin publish` (signs + uploads to registry)

**Plugin template:** `blufio plugin init --type channel my-channel` scaffolds a complete plugin project with trait implementation stubs, plugin.toml, test harness, and CI configuration.

**Testing:** `blufio plugin test ./my-plugin` loads the plugin in an isolated test harness, runs the health check, and validates the manifest. For channel plugins, a mock message round-trip test is included.

---

## File Layout Reference

```
/usr/local/bin/
└── blufio                            # Single binary (40-60MB)

/etc/blufio/
├── config.toml                       # Configuration (TOML, validated)
├── env                               # Secrets (mode 0600)
├── hooks/
│   ├── on-message.sh                 # Message filter
│   ├── on-tool-call.sh               # Tool audit
│   ├── on-error.sh                   # Error notification
│   ├── pre-job.sh                    # Pre-job hook
│   └── post-job.sh                   # Post-job hook
└── scripts/
    ├── backup.sh                     # Database backup
    ├── restore.sh                    # Restore from backup
    ├── health-check.sh               # Health monitoring
    ├── cost-alert.sh                 # Budget alerting
    ├── smart-heartbeat.sh            # Zero-token heartbeat
    ├── update.sh                     # Safe binary update
    └── cleanup.sh                    # Data rotation

/etc/systemd/system/
├── blufio.service                    # Main service
├── blufio@.service                   # Multi-instance template
├── blufio-heartbeat.{timer,service}  # Heartbeat schedule
├── blufio-backup.{timer,service}     # Backup schedule
├── blufio-cost-alert.{timer,service} # Cost check schedule
├── blufio-health.{timer,service}     # Health check schedule
└── blufio-cleanup.{timer,service}    # Cleanup schedule

/var/lib/blufio/
├── blufio.db                         # Main database (SQLite WAL)
├── observability.db                  # Metrics/traces/cost events
└── workspace/                        # Agent workspace files

/var/log/blufio/                      # Supplementary audit logs
/var/backups/blufio/                  # Database backups
```

---

*End of Section 5 — Version 1.7*
